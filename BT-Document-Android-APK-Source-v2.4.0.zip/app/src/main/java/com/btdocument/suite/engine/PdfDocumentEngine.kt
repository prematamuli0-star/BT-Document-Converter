package com.btdocument.suite.engine

import android.graphics.Bitmap
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File

/**
 * Native Android PDF Engine implementing all 9 BT Document tools via PDFBox-Android & Apache POI.
 */
object PdfDocumentEngine {

    // 1. Text to PDF
    fun createPdfFromText(title: String, body: String, outputFile: File) {
        PDDocument().use { doc ->
            val page = PDPage(PDRectangle.A4)
            doc.addPage(page)
            PDPageContentStream(doc, page).use { stream ->
                stream.beginText()
                stream.setFont(PDType1Font.HELVETICA_BOLD, 16f)
                stream.newLineAtOffset(48f, 780f)
                stream.showText(title)
                stream.setFont(PDType1Font.HELVETICA, 11f)
                var offsetY = -28f
                body.lines().forEach { line ->
                    stream.newLineAtOffset(0f, offsetY)
                    stream.showText(line.take(85))
                    offsetY = -16f
                }
                stream.endText()
            }
            doc.save(outputFile)
        }
    }

    // 3. PDF Photo-Style Crop
    fun cropPdf(inputFile: File, outputFile: File, leftRatio: Float, topRatio: Float, widthRatio: Float, heightRatio: Float) {
        PDDocument.load(inputFile).use { doc ->
            for (page in doc.pages) {
                val media = page.mediaBox
                val x = media.lowerLeftX + media.width * leftRatio
                val w = media.width * widthRatio
                val h = media.height * heightRatio
                val y = media.upperRightY - (media.height * (topRatio + heightRatio))
                page.cropBox = PDRectangle(x, y, w, h)
            }
            doc.save(outputFile)
        }
    }

    // 4. PDF Page Split
    fun splitPdfPage(inputFile: File, pageIndexOneBased: Int, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            val splitter = Splitter()
            splitter.setStartPage(pageIndexOneBased)
            splitter.setEndPage(pageIndexOneBased)
            val pages = splitter.split(doc)
            pages.firstOrNull()?.use { single -> single.save(outputFile) }
        }
    }

    // 5. PDF Merge
    fun mergePdfs(inputs: List<File>, outputFile: File) {
        val merger = PDFMergerUtility()
        inputs.forEach { merger.addSource(it) }
        merger.destinationFileName = outputFile.absolutePath
        merger.mergeDocuments(null)
    }

    // 6. Sign PDF with Bitmap Signature
    fun signPdf(inputFile: File, signatureBitmap: Bitmap, pageIndex: Int, x: Float, y: Float, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            val page = doc.getPage(pageIndex.coerceIn(0, doc.numberOfPages - 1))
            val pdImage = LosslessFactory.createFromImage(doc, signatureBitmap)
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                stream.drawImage(pdImage, x, y, 140f, 60f)
            }
            doc.save(outputFile)
        }
    }

    // 9. PDF Password Protection (AES-256 StandardProtectionPolicy)
    fun protectPdf(inputFile: File, userPassword: String, ownerPassword: String, allowPrint: Boolean, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            val ap = AccessPermission().apply {
                setCanPrint(allowPrint)
                setCanModify(false)
            }
            val policy = StandardProtectionPolicy(ownerPassword, userPassword, ap).apply {
                encryptionKeyLength = 256
                permissions = ap
            }
            doc.protect(policy)
            doc.save(outputFile)
        }
    }
}
