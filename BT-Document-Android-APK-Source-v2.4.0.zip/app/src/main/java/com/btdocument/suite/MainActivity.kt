package com.btdocument.suite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

data class DocumentTool(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            MaterialTheme {
                BTDocumentApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BTDocumentApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tools = remember {
        listOf(
            DocumentTool("text_pdf", "Text to PDF", "Convert notes & plain text", Icons.Default.Description),
            DocumentTool("excel_pdf", "Excel to PDF", "Convert .xlsx spreadsheets", Icons.Default.TableChart),
            DocumentTool("pdf_crop", "PDF Photo Crop", "Interactive page margin trim", Icons.Default.Crop),
            DocumentTool("pdf_split", "PDF Page Split", "Extract custom page ranges", Icons.Default.CallSplit),
            DocumentTool("pdf_merge", "PDF Merge", "Combine multiple PDF files", Icons.Default.MergeType),
            DocumentTool("sign_pdf", "Sign PDF", "Draw & stamp wet signature", Icons.Default.Draw),
            DocumentTool("pdf_word", "PDF to Word", "Export editable .docx files", Icons.Default.Article),
            DocumentTool("word_pdf", "Word to PDF", "Convert .docx to standard PDF", Icons.Default.PictureAsPdf),
            DocumentTool("pdf_lock", "PDF Password", "AES-256 encryption & permissions", Icons.Default.Lock)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BT Document", fontWeight = FontWeight.Bold) }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "Tools") },
                    label = { Text("All Tools") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.History, contentDescription = "Recent") },
                    label = { Text("Recent Used") }
                )
            }
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(innerPadding).fillMaxSize()
        ) {
            items(tools) { tool ->
                ElevatedCard(
                    onClick = { /* Launches PdfEngineActivity for tool.id */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(tool.icon, contentDescription = tool.title, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(tool.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(tool.subtitle, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
