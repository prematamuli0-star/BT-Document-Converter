# BT Document — Native Android Studio Project (com.btdocument.suite)

This archive contains the complete Android Studio Kotlin + Jetpack Compose (Material Design 3) source project for **BT Document**.

## Included 9 Core Document Tools
1. **Text to PDF** (`PdfDocumentEngine.createPdfFromText`)
2. **Excel to PDF** (Apache POI `XSSFWorkbook` table parser to `PDDocument`)
3. **PDF Crop (Photo-style Crop)** (`PDRectangle` CropBox & MediaBox coordinate trimmer)
4. **PDF Page Split** (`Splitter` custom range extractor)
5. **PDF Merge** (`PDFMergerUtility` multi-file combiner)
6. **Sign PDF** (`LosslessFactory` wet-ink signature canvas overlay)
7. **PDF to Word** (`PDFTextStripper` to `.docx` `XWPFDocument`)
8. **Word to PDF** (`XWPFDocument` reader to `PDDocument`)
9. **PDF Password Protection** (`StandardProtectionPolicy` 256-bit AES encryption)

## How to Build the Native `.apk` File
1. Extract this ZIP archive and open the folder in **Android Studio Ladybug (2024.2.1)** or newer.
2. Let Gradle sync dependencies automatically.
3. From the top menu, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run in terminal:
   ```bash
   ./gradlew assembleDebug
   ```
4. Your installable APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`
