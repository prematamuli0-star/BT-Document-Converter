Sign PDF screen corrections applied to the Claude-provided source ZIP.

Changed file: app/src/main/java/com/btdocument/suite/ui/SignPdfScreen.kt only.

Changes:
- Removed the outer screen vertical scrolling that caused the extra right-edge floating scroll control.
- Kept the dedicated PDF preview scrollbar and increased its thumb width.
- Reduced the PDF preview height to a compact responsive range to reduce unused vertical space.
- Removed the extra preview hint, Ink label/selected-colour text, and drawing-area placeholder.
- Preserved the existing PDF pinch zoom/pan, signature move/resize handles, colour selection, signer name, and save flow.

Build status: Not compiled or device-tested in this environment. The supplied ZIP does not contain gradle-wrapper.jar, so a verified local Gradle build could not be run. Please run GitHub Actions and test on an Android device before publishing.
