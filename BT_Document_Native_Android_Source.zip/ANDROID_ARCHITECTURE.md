# BT Document — Native Android Kotlin & Jetpack Compose Technical Guide

## 1. Non-Destructive File Handling & Save Location Selection (SAF)
- **Open**: `ActivityResultContracts.OpenDocument()` opens any PDF/Excel/Word file via Android Storage Access Framework without requesting broad legacy storage permissions.
- **Read-Only Isolation**: `PdfDocumentEngine.copyUriToTempFile` copies the user's input stream into an app-private cache file. **The original file URI is never opened in write mode or modified.**
- **Rename & Save Location**: `ActivityResultContracts.CreateDocument(mimeType)` launches Android's native system file saver pre-filled with the user's custom filename (e.g. `Cropped_Contract.pdf`), allowing the user to pick any save folder (Downloads, Documents, Drive, SD Card).

## 2. PDF Crop (Photo-Style) — Technical Logic (`PdfCropScreen.kt` & `PdfDocumentEngine.cropPdfPermanent`)
1. **Preview**: `android.graphics.pdf.PdfRenderer` renders page bitmaps for instant display.
2. **Gestures**: Jetpack Compose `pointerInput` + `detectDragGestures` tracks touch coordinates across all **4 corners** (`NW, NE, SW, SE`), all **4 edges** (`N, S, E, W`), and the **interior rectangle** (`MOVE`) with a 48px touch tolerance.
3. **Live Preview**: `derivedStateOf` slices the rendered page `Bitmap` to `cropRect` bounds so the user sees the exact cropped output in real time.
4. **Revert & Reset**: `cropHistory` stores previous normalized crop boxes for 1-tap **Revert**; **Reset Full** restores `(0f, 0f, 1f, 1f)`.
5. **Permanent PDF Cropping**: `LayerUtility.importPageAsForm` imports each selected page as a PDF Form XObject, clips the graphics state to `[0, 0, cropW, cropH]`, translates by `(-cropX, -cropY)`, and writes normalized `mediaBox`, `cropBox`, `trimBox`, `bleedBox`, and `artBox`. Unselected pages are copied unmodified.

## 3. All 9 Tools Native Libraries
| # | Tool | Native Android Implementation |
|---|------|-------------------------------|
| 01 | Text to PDF | `PDDocument` + `PDPageContentStream` multi-page word-wrapping |
| 02 | Excel to PDF | Apache POI `WorkbookFactory` + `PDPageContentStream` table grid |
| 03 | PDF Crop | `PdfRenderer` + Compose gestures + `LayerUtility` permanent XObject clip |
| 04 | PDF Page Split | `Splitter` + `ZipOutputStream` |
| 05 | PDF Merge | `PDFMergerUtility` |
| 06 | Sign PDF | Compose `Canvas` -> `Bitmap` -> `LosslessFactory.createFromImage` |
| 07 | PDF to Word | `PDFTextStripper` -> Apache POI `XWPFDocument` (`.docx`) |
| 08 | Word to PDF | Apache POI `XWPFDocument` -> `PDDocument` |
| 09 | PDF Password | `StandardProtectionPolicy` (256-bit AES) + `AccessPermission` |

## 4. Build APK Instructions
```bash
./gradlew assembleDebug
# APK output: app/build/outputs/apk/debug/app-debug.apk
```
