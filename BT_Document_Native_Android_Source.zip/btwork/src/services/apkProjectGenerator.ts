import JSZip from 'jszip';

export interface ApkProjectConfig {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
}

export const DEFAULT_APK_CONFIG: ApkProjectConfig = {
  appName: 'BT Document',
  packageName: 'com.btdocument.suite',
  versionName: '2.4.1',
  versionCode: 25,
  minSdk: 26,
  targetSdk: 35,
};

export function getAndroidFiles(config: ApkProjectConfig): Record<string, string> {
  const pkgPath = config.packageName.replace(/\./g, '/');

  return {
    'settings.gradle.kts': `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${config.appName.replace(/\s+/g, '')}"
include(":app")
`,

    'gradle.properties': `org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
`,

  'build.gradle.kts': `plugins {
    id("com.android.application") version "8.7.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
`,

    'gradle/wrapper/gradle-wrapper.properties': `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`,

    'app/build.gradle.kts': `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "${config.packageName}"
    compileSdk = ${config.targetSdk}

    defaultConfig {
        applicationId = "${config.packageName}"
        minSdk = ${config.minSdk}
        targetSdk = ${config.targetSdk}
        versionCode = ${config.versionCode}
        versionName = "${config.versionName}"
        vectorDrawables { useSupportLibrary = true }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE",
                "META-INF/LICENSE.txt",
                "META-INF/NOTICE",
                "META-INF/NOTICE.txt"
            )
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // PDFBox-Android & Apache POI for full offline PDF + Excel + Word processing
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("org.apache.poi:poi-ooxml:5.2.5")
}
`,

    'app/proguard-rules.pro': `-keep class com.tom_roush.pdfbox.** { *; }
-keep class org.apache.poi.** { *; }
-dontwarn org.apache.poi.**
-dontwarn org.bouncycastle.**
`,

    'app/src/main/AndroidManifest.xml': `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>
</manifest>
`,

    'app/src/main/res/values/strings.xml': `<resources>
    <string name="app_name">${config.appName}</string>
</resources>
`,

    'app/src/main/res/xml/file_paths.xml': `<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <cache-path name="bt_cache" path="." />
    <files-path name="bt_files" path="." />
</paths>
`,

    [`app/src/main/java/${pkgPath}/model/DocumentModels.kt`]: `package ${config.packageName}.model

import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolType(val id: String, val title: String, val subtitle: String) {
    TEXT_TO_PDF("text_pdf", "Text to PDF", "Paginated A4 or Letter PDF"),
    EXCEL_TO_PDF("excel_pdf", "Excel to PDF", "Tabular .xlsx/.xls reports"),
    PDF_CROP("pdf_crop", "PDF Crop (Photo Style)", "4 corners + 4 edges + live preview"),
    PDF_SPLIT("pdf_split", "PDF Page Split", "Extract ranges to PDF or ZIP"),
    PDF_MERGE("pdf_merge", "PDF Merge", "Combine multiple PDFs in order"),
    SIGN_PDF("sign_pdf", "Sign PDF", "Touch wet-ink signature stamp"),
    PDF_TO_WORD("pdf_word", "PDF to Word", "Export editable .docx files"),
    WORD_TO_PDF("word_pdf", "Word to PDF", "Convert .docx into PDF 1.7"),
    PDF_PASSWORD("pdf_lock", "PDF Password", "AES-256 lock & watermark")
}

data class ToolCardMeta(
    val type: ToolType,
    val number: String,
    val icon: ImageVector
)

data class CropRectNorm(
    val left: Float = 0.06f,
    val top: Float = 0.06f,
    val width: Float = 0.88f,
    val height: Float = 0.88f
)

enum class CropPageScope {
    ALL_PAGES,
    CURRENT_PAGE,
    SELECTED_PAGES
}

data class RecentDocumentRecord(
    val id: String,
    val displayName: String,
    val toolTitle: String,
    val uriString: String,
    val sizeBytes: Long,
    val timestampLabel: String,
    val summary: String
)
`,

    [`app/src/main/java/${pkgPath}/engine/PdfDocumentEngine.kt`]: `package ${config.packageName}.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.multipdf.LayerUtility
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.text.PDFTextStripper
import ${config.packageName}.model.CropRectNorm
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xwpf.usermodel.XWPFDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Complete Native Android Document Engine covering all 9 BT Document tools.
 * Non-destructive: Always reads from source Uri into memory/temp files and writes
 * output to a user-chosen destination Uri (never overwriting the original file).
 */
object PdfDocumentEngine {

    private fun sanitizePdfText(raw: String): String =
        raw.replace("→", "->")
            .replace("←", "<-")
            .replace("•", "*")
            .replace("—", "--")
            .replace("–", "-")
            .replace(Regex("[^\\x20-\\x7E\\xA0-\\xFF]"), " ")

    fun copyUriToTempFile(context: Context, uri: Uri, prefix: String, ext: String): File {
        val temp = File.createTempFile(prefix, ext, context.cacheDir)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        } ?: error("Unable to open input stream for $uri")
        return temp
    }

    fun writeFileToDestinationUri(context: Context, sourceFile: File, destUri: Uri): Long {
        context.contentResolver.openOutputStream(destUri)?.use { out ->
            sourceFile.inputStream().use { input -> input.copyTo(out) }
        } ?: error("Unable to write to destination Uri: $destUri")
        return sourceFile.length()
    }

    /**
     * Render any page (0-indexed) of a PDF File to an Android Bitmap using PdfRenderer.
     */
    fun renderPdfPageBitmap(pdfFile: File, pageIndex: Int, scale: Float = 1.5f): Pair<Bitmap, Int> {
        ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                val count = renderer.pageCount
                val safeIndex = pageIndex.coerceIn(0, (count - 1).coerceAtLeast(0))
                renderer.openPage(safeIndex).use { page ->
                    val w = (page.width * scale).toInt().coerceAtLeast(100)
                    val h = (page.height * scale).toInt().coerceAtLeast(100)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Pair(bmp, count)
                }
            }
        }
    }

    // 1. Text to PDF (Multi-page word wrap)
    fun createPdfFromText(title: String, body: String, fontSize: Float, isLetter: Boolean, outFile: File) {
        val pageSize = if (isLetter) PDRectangle.LETTER else PDRectangle.A4
        val margin = 48f
        val usableW = pageSize.width - margin * 2f
        val lineHeight = fontSize * 1.45f

        PDDocument().use { doc ->
            var page = PDPage(pageSize)
            doc.addPage(page)
            var stream = PDPageContentStream(doc, page)
            var y = pageSize.height - margin

            val cleanTitle = sanitizePdfText(title.trim())
            if (cleanTitle.isNotEmpty()) {
                stream.beginText()
                stream.setFont(PDType1Font.HELVETICA_BOLD, fontSize + 5f)
                stream.newLineAtOffset(margin, y)
                stream.showText(cleanTitle)
                stream.endText()
                y -= (fontSize + 24f)
            }

            for (para in sanitizePdfText(body).replace("\\r\\n", "\\n").split("\\n")) {
                if (para.isBlank()) {
                    y -= lineHeight * 0.7f
                    if (y < margin + lineHeight) {
                        stream.close()
                        page = PDPage(pageSize)
                        doc.addPage(page)
                        stream = PDPageContentStream(doc, page)
                        y = pageSize.height - margin
                    }
                    continue
                }
                val words = para.split(Regex("\\\\s+"))
                var currentLine = ""
                for (w in words) {
                    val candidate = if (currentLine.isEmpty()) w else "$currentLine $w"
                    val width = PDType1Font.HELVETICA.getStringWidth(candidate) / 1000f * fontSize
                    if (width > usableW && currentLine.isNotEmpty()) {
                        if (y < margin + lineHeight) {
                            stream.close()
                            page = PDPage(pageSize)
                            doc.addPage(page)
                            stream = PDPageContentStream(doc, page)
                            y = pageSize.height - margin
                        }
                        stream.beginText()
                        stream.setFont(PDType1Font.HELVETICA, fontSize)
                        stream.newLineAtOffset(margin, y)
                        stream.showText(currentLine)
                        stream.endText()
                        y -= lineHeight
                        currentLine = w
                    } else {
                        currentLine = candidate
                    }
                }
                if (currentLine.isNotEmpty()) {
                    if (y < margin + lineHeight) {
                        stream.close()
                        page = PDPage(pageSize)
                        doc.addPage(page)
                        stream = PDPageContentStream(doc, page)
                        y = pageSize.height - margin
                    }
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, fontSize)
                    stream.newLineAtOffset(margin, y)
                    stream.showText(currentLine)
                    stream.endText()
                    y -= lineHeight
                }
            }
            stream.close()
            doc.save(outFile)
        }
    }

    // 2. Excel (.xlsx / .xls) to PDF using Apache POI WorkbookFactory
    fun convertExcelToPdf(excelFile: File, title: String, landscape: Boolean, outFile: File) {
        val rows = mutableListOf<List<String>>()
        excelFile.inputStream().use { input ->
            val wb = WorkbookFactory.create(input)
            val sheet = wb.getSheetAt(0)
            for (row in sheet) {
                val cells = (0 until row.lastCellNum.coerceAtLeast(1)).map { idx ->
                    row.getCell(idx)?.toString() ?: ""
                }
                if (cells.any { it.isNotBlank() }) rows.add(cells)
            }
            wb.close()
        }

        val pageSize = if (landscape) PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width) else PDRectangle.A4
        val margin = 36f
        val usableW = pageSize.width - margin * 2f
        val colCount = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val colW = usableW / colCount
        val rowH = 22f

        PDDocument().use { doc ->
            var page = PDPage(pageSize)
            doc.addPage(page)
            var stream = PDPageContentStream(doc, page)
            var y = pageSize.height - margin

            stream.beginText()
            stream.setFont(PDType1Font.HELVETICA_BOLD, 14f)
            stream.newLineAtOffset(margin, y)
            stream.showText(sanitizePdfText(title))
            stream.endText()
            y -= 28f

            rows.forEachIndexed { rIdx, row ->
                if (y - rowH < margin) {
                    stream.close()
                    page = PDPage(pageSize)
                    doc.addPage(page)
                    stream = PDPageContentStream(doc, page)
                    y = pageSize.height - margin
                }
                val isHeader = rIdx == 0
                if (isHeader) {
                    stream.setNonStrokingColor(23, 56, 133)
                    stream.addRect(margin, y - rowH, usableW, rowH)
                    stream.fill()
                } else if (rIdx % 2 == 1) {
                    stream.setNonStrokingColor(244, 246, 250)
                    stream.addRect(margin, y - rowH, usableW, rowH)
                    stream.fill()
                }
                stream.setNonStrokingColor(if (isHeader) 255 else 38, if (isHeader) 255 else 51, if (isHeader) 255 else 71)
                for (cIdx in 0 until colCount) {
                    val cell = sanitizePdfText(row.getOrElse(cIdx) { "" }).take(24)
                    stream.beginText()
                    stream.setFont(if (isHeader) PDType1Font.HELVETICA_BOLD else PDType1Font.HELVETICA, 9f)
                    stream.newLineAtOffset(margin + cIdx * colW + 4f, y - rowH + 6f)
                    stream.showText(cell)
                    stream.endText()
                }
                y -= rowH
            }
            stream.close()
            doc.save(outFile)
        }
    }

    // 3. Permanent PDF Photo-Style Crop (Creates separate output file, never alters inputFile)
    fun cropPdfPermanent(
        inputFile: File,
        outputFile: File,
        crop: CropRectNorm,
        targetPagesOneBased: Set<Int>
    ) {
        PDDocument.load(inputFile).use { srcDoc ->
            PDDocument().use { outDoc ->
                val layerUtil = LayerUtility(outDoc)
                for (i in 0 until srcDoc.numberOfPages) {
                    val pageNum = i + 1
                    val srcPage = srcDoc.getPage(i)
                    if (!targetPagesOneBased.contains(pageNum)) {
                        val imported = outDoc.importPage(srcPage)
                        imported.cropBox = srcPage.cropBox
                        continue
                    }

                    // Use the same visible page bounds as PdfRenderer preview. PDF page coordinates
                    // use a bottom-left origin while the crop UI uses a top-left origin.
                    val box = srcPage.cropBox ?: srcPage.mediaBox
                    val left = crop.left.coerceIn(0f, 0.98f)
                    val top = crop.top.coerceIn(0f, 0.98f)
                    val right = (crop.left + crop.width).coerceIn(left + 0.02f, 1f)
                    val bottom = (crop.top + crop.height).coerceIn(top + 0.02f, 1f)
                    val cropX = box.lowerLeftX + left * box.width
                    val cropW = ((right - left) * box.width).coerceIn(1f, box.width)
                    val cropH = ((bottom - top) * box.height).coerceIn(1f, box.height)
                    val cropY = box.lowerLeftY + box.height - bottom * box.height

                    // Import as Form XObject and clip permanently onto a fresh [0, 0, cropW, cropH] page
                    val form = layerUtil.importPageAsForm(srcDoc, i)
                    val newPage = PDPage(PDRectangle(0f, 0f, cropW, cropH))
                    newPage.mediaBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.cropBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.trimBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.bleedBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.artBox = PDRectangle(0f, 0f, cropW, cropH)
                    outDoc.addPage(newPage)

                    PDPageContentStream(outDoc, newPage).use { cs ->
                        cs.saveGraphicsState()
                        cs.addRect(0f, 0f, cropW, cropH)
                        cs.clip()
                        cs.transform(com.tom_roush.pdfbox.util.Matrix.getTranslateInstance(-cropX, -cropY))
                        cs.drawForm(form)
                        cs.restoreGraphicsState()
                    }
                }
                outDoc.save(outputFile)
            }
        }
    }

    // 4. PDF Page Split (Single PDF or ZIP of single pages)
    fun parsePageRange(rangeStr: String, maxPages: Int): List<Int> {
        val out = linkedSetOf<Int>()
        rangeStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            if (part.contains("-")) {
                val bounds = part.split("-").mapNotNull { it.trim().toIntOrNull() }
                if (bounds.size == 2) {
                    val s = minOf(bounds[0], bounds[1]).coerceIn(1, maxPages)
                    val e = maxOf(bounds[0], bounds[1]).coerceIn(1, maxPages)
                    for (p in s..e) out.add(p)
                }
            } else {
                part.toIntOrNull()?.let { if (it in 1..maxPages) out.add(it) }
            }
        }
        return out.sorted()
    }

    fun splitPdf(inputFile: File, pagesOneBased: List<Int>, asZip: Boolean, outFile: File) {
        PDDocument.load(inputFile).use { src ->
            if (!asZip || pagesOneBased.size <= 1) {
                PDDocument().use { outDoc ->
                    pagesOneBased.forEach { pNum ->
                        outDoc.importPage(src.getPage((pNum - 1).coerceIn(0, src.numberOfPages - 1)))
                    }
                    outDoc.save(outFile)
                }
            } else {
                ZipOutputStream(FileOutputStream(outFile)).use { zos ->
                    pagesOneBased.forEach { pNum ->
                        val splitter = Splitter().apply { startPage = pNum; endPage = pNum }
                        val single = splitter.split(src).firstOrNull()
                        single?.use { doc ->
                            val baos = ByteArrayOutputStream()
                            doc.save(baos)
                            zos.putNextEntry(ZipEntry("page_$pNum.pdf"))
                            zos.write(baos.toByteArray())
                            zos.closeEntry()
                        }
                    }
                }
            }
        }
    }

    // 5. PDF Merge
    fun mergePdfs(inputs: List<File>, outputFile: File) {
        val merger = PDFMergerUtility()
        inputs.forEach { merger.addSource(it) }
        merger.destinationFileName = outputFile.absolutePath
        merger.mergeDocuments(null)
    }

    // 6. Sign PDF with Wet-Ink Bitmap Signature
    fun signPdf(inputFile: File, signatureBitmap: Bitmap, signerName: String, pageOneBased: Int, xRatio: Float, yRatio: Float, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            val page = doc.getPage((pageOneBased - 1).coerceIn(0, doc.numberOfPages - 1))
            val media = page.cropBox ?: page.mediaBox
            val sigW = 145f
            val sigH = sigW * (signatureBitmap.height.toFloat() / signatureBitmap.width.coerceAtLeast(1))
            val drawX = (media.lowerLeftX + xRatio * media.width).coerceIn(16f, media.width - sigW - 16f)
            val drawY = (media.lowerLeftY + media.height - yRatio * media.height - sigH).coerceIn(24f, media.height - sigH - 16f)

            val pdImage = LosslessFactory.createFromImage(doc, signatureBitmap)
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                stream.drawImage(pdImage, drawX, drawY, sigW, sigH)
                if (signerName.isNotBlank()) {
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, 7.5f)
                    stream.setNonStrokingColor(30, 70, 165)
                    stream.newLineAtOffset(drawX, (drawY - 11f).coerceAtLeast(10f))
                    stream.showText(sanitizePdfText("Digitally Signed by $signerName"))
                    stream.endText()
                }
            }
            doc.save(outputFile)
        }
    }

    // 7. PDF to Word (.docx)
    fun convertPdfToWord(pdfFile: File, title: String, outDocxFile: File) {
        PDDocument.load(pdfFile).use { pdf ->
            val stripper = PDFTextStripper()
            XWPFDocument().use { docx ->
                val titlePara = docx.createParagraph()
                titlePara.createRun().apply {
                    isBold = true
                    fontSize = 16
                    setText(title)
                }
                for (p in 1..pdf.numberOfPages) {
                    stripper.startPage = p
                    stripper.endPage = p
                    val pageText = stripper.getText(pdf)
                    docx.createParagraph().createRun().apply {
                        isBold = true
                        color = "1D4ED8"
                        setText("Page $p")
                    }
                    pageText.lines().filter { it.isNotBlank() }.forEach { line ->
                        docx.createParagraph().createRun().setText(line)
                    }
                }
                FileOutputStream(outDocxFile).use { docx.write(it) }
            }
        }
    }

    // 8. Word (.docx) to PDF
    fun convertWordToPdf(docxFile: File, title: String, outPdfFile: File) {
        val textBuilder = StringBuilder()
        docxFile.inputStream().use { input ->
            XWPFDocument(input).use { docx ->
                docx.paragraphs.forEach { p ->
                    if (p.text.isNotBlank()) textBuilder.appendLine(p.text)
                }
            }
        }
        createPdfFromText(title, textBuilder.toString(), 11f, false, outPdfFile)
    }

    // 9. PDF Password Protection (True ISO 32000 AES-256 StandardProtectionPolicy)
    fun protectPdf(
        inputFile: File,
        userPassword: String,
        ownerPassword: String,
        watermark: String,
        allowPrint: Boolean,
        allowCopy: Boolean,
        outputFile: File
    ) {
        PDDocument.load(inputFile).use { doc ->
            if (watermark.isNotBlank()) {
                for (page in doc.pages) {
                    val media = page.cropBox ?: page.mediaBox
                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                        cs.beginText()
                        cs.setFont(PDType1Font.HELVETICA_BOLD, 32f)
                        cs.setNonStrokingColor(210, 45, 55)
                        cs.setTextMatrix(com.tom_roush.pdfbox.util.Matrix.getRotateInstance(Math.toRadians(35.0), media.width * 0.2f, media.height * 0.35f))
                        cs.showText(sanitizePdfText(watermark.uppercase()))
                        cs.endText()
                    }
                }
            }
            val ap = AccessPermission().apply {
                setCanPrint(allowPrint)
                setCanExtractContent(allowCopy)
                setCanModify(false)
            }
            val policy = StandardProtectionPolicy(ownerPassword, userPassword, ap).apply {
                encryptionKeyLength = 256
                permissions = ap
            }
            doc.protect(policy)
            doc.save(outputFile)
        }
    }
}
`,

    [`app/src/main/java/${pkgPath}/ui/PdfCropScreen.kt`]: `package ${config.packageName}.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import ${config.packageName}.engine.PdfDocumentEngine
import ${config.packageName}.model.CropPageScope
import ${config.packageName}.model.CropRectNorm
import ${config.packageName}.model.RecentDocumentRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private enum class DragMode {
    NONE, MOVE, NW, NE, SW, SE, N, S, W, E
}

@Composable
fun PdfCropScreen(
    onSaveRecent: (RecentDocumentRecord) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sourceFile by remember { mutableStateOf<File?>(null) }
    var sourceName by remember { mutableStateOf("No PDF Selected") }
    var totalPages by remember { mutableIntStateOf(0) }
    var currentPageIdx by remember { mutableIntStateOf(0) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var cropRect by remember { mutableStateOf(CropRectNorm()) }
    var cropHistory by remember { mutableStateOf<List<CropRectNorm>>(emptyList()) }
    var pageScope by remember { mutableStateOf(CropPageScope.ALL_PAGES) }
    var selectedRangeText by remember { mutableStateOf("1") }
    var outputFileName by remember { mutableStateOf("Cropped_Document.pdf") }
    var statusText by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }

    // Never mutates original sourceFile — only renders page preview
    fun loadPagePreview(file: File, pageIdx: Int) {
        scope.launch {
            val (bmp, count) = withContext(Dispatchers.IO) {
                PdfDocumentEngine.renderPdfPageBitmap(file, pageIdx, 1.6f)
            }
            pageBitmap = bmp
            totalPages = count
        }
    }

    val openPdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val temp = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.copyUriToTempFile(context, uri, "src_crop_", ".pdf")
                }
                sourceFile = temp
                val baseName = uri.lastPathSegment?.substringAfterLast('/') ?: "Document.pdf"
                sourceName = baseName
                outputFileName = "Cropped_\${baseName.removeSuffix(".pdf")}.pdf"
                currentPageIdx = 0
                cropRect = CropRectNorm()
                cropHistory = emptyList()
                loadPagePreview(temp, 0)
                statusText = "Opened original PDF (read-only). Ready to crop."
            }
        }
    }

    // SAF CreateDocument launcher lets user pick any save folder & rename file on Android
    val saveCroppedLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val src = sourceFile
        if (destUri != null && src != null) {
            isBusy = true
            scope.launch {
                val targetPages = when (pageScope) {
                    CropPageScope.ALL_PAGES -> (1..totalPages).toSet()
                    CropPageScope.CURRENT_PAGE -> setOf(currentPageIdx + 1)
                    CropPageScope.SELECTED_PAGES -> PdfDocumentEngine.parsePageRange(selectedRangeText, totalPages).toSet()
                }.ifEmpty { setOf(currentPageIdx + 1) }

                val outTemp = File.createTempFile("cropped_out_", ".pdf", context.cacheDir)
                val sizeBytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.cropPdfPermanent(src, outTemp, cropRect, targetPages)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, destUri)
                }
                onSaveRecent(
                    RecentDocumentRecord(
                        id = System.currentTimeMillis().toString(),
                        displayName = outputFileName,
                        toolTitle = "PDF Crop",
                        uriString = destUri.toString(),
                        sizeBytes = sizeBytes,
                        timestampLabel = "Just now",
                        summary = "\${targetPages.size} page(s) permanently cropped"
                    )
                )
                isBusy = false
                statusText = "Saved separate cropped PDF without modifying original."
            }
        }
    }

    // Live cropped Bitmap computed in memory whenever cropRect or pageBitmap changes
    val liveCroppedBitmap by remember(pageBitmap, cropRect) {
        derivedStateOf {
            pageBitmap?.let { bmp ->
                val x = (cropRect.left * bmp.width).toInt().coerceIn(0, bmp.width - 1)
                val y = (cropRect.top * bmp.height).toInt().coerceIn(0, bmp.height - 1)
                val w = (cropRect.width * bmp.width).toInt().coerceIn(1, bmp.width - x)
                val h = (cropRect.height * bmp.height).toInt().coerceIn(1, bmp.height - y)
                Bitmap.createBitmap(bmp, x, y, w, h)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("PDF Crop (Photo Style)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(sourceName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FileOpen, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Open PDF")
            }
        }

        if (totalPages > 0) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    enabled = currentPageIdx > 0,
                    onClick = {
                        currentPageIdx -= 1
                        sourceFile?.let { loadPagePreview(it, currentPageIdx) }
                    }
                ) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Page") }

                Text("Page \${currentPageIdx + 1} of $totalPages", fontWeight = FontWeight.SemiBold)

                IconButton(
                    enabled = currentPageIdx < totalPages - 1,
                    onClick = {
                        currentPageIdx += 1
                        sourceFile?.let { loadPagePreview(it, currentPageIdx) }
                    }
                ) { Icon(Icons.Default.ChevronRight, contentDescription = "Next Page") }
            }
        }

        // Revert & Reset Toolbar
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = cropHistory.isNotEmpty(),
                onClick = {
                    val prev = cropHistory.last()
                    cropHistory = cropHistory.dropLast(1)
                    cropRect = prev
                }
            ) {
                Icon(Icons.Default.Undo, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Revert")
            }
            OutlinedButton(
                onClick = {
                    cropHistory = cropHistory + cropRect
                    cropRect = CropRectNorm(0f, 0f, 1f, 1f)
                }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Reset Full")
            }
        }

        // Interactive Crop Overlay with 4 Corners + 4 Edges + Move
        pageBitmap?.let { bmp ->
            var boxSize by remember { mutableStateOf(IntSize(1, 1)) }
            var dragMode by remember { mutableStateOf(DragMode.NONE) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                    .onSizeChanged { boxSize = it }
                    .pointerInput(boxSize) {
                        awaitEachGesture {
                            // Consume the initial touch so the surrounding vertical scroll
                            // container cannot steal a crop-box drag gesture.
                            val down = awaitFirstDown(requireUnconsumed = false)
                            down.consume()
                            cropHistory = (cropHistory + cropRect).takeLast(12)
                            val w = boxSize.width.toFloat().coerceAtLeast(1f)
                            val h = boxSize.height.toFloat().coerceAtLeast(1f)
                            val l0 = cropRect.left * w
                            val t0 = cropRect.top * h
                            val r0 = (cropRect.left + cropRect.width) * w
                            val b0 = (cropRect.top + cropRect.height) * h
                            val tol = 56f
                            val nearL = abs(down.position.x - l0) < tol
                            val nearR = abs(down.position.x - r0) < tol
                            val nearT = abs(down.position.y - t0) < tol
                            val nearB = abs(down.position.y - b0) < tol
                            dragMode = when {
                                nearL && nearT -> DragMode.NW
                                nearR && nearT -> DragMode.NE
                                nearL && nearB -> DragMode.SW
                                nearR && nearB -> DragMode.SE
                                nearT && down.position.x in l0..r0 -> DragMode.N
                                nearB && down.position.x in l0..r0 -> DragMode.S
                                nearL && down.position.y in t0..b0 -> DragMode.W
                                nearR && down.position.y in t0..b0 -> DragMode.E
                                down.position.x in l0..r0 && down.position.y in t0..b0 -> DragMode.MOVE
                                else -> DragMode.NONE
                            }
                            var previous = down.position
                            do {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                val delta = change.position - previous
                                if (change.pressed && dragMode != DragMode.NONE) {
                                    change.consume()
                                    val dx = delta.x / w
                                    val dy = delta.y / h
                                    val minS = 0.08f
                                    val cur = cropRect
                                    var left = cur.left
                                    var top = cur.top
                                    var right = cur.left + cur.width
                                    var bottom = cur.top + cur.height
                                    when (dragMode) {
                                        DragMode.MOVE -> {
                                            left = (cur.left + dx).coerceIn(0f, 1f - cur.width)
                                            top = (cur.top + dy).coerceIn(0f, 1f - cur.height)
                                            cropRect = cur.copy(left = left, top = top)
                                        }
                                        DragMode.NW -> { left = (left + dx).coerceIn(0f, right - minS); top = (top + dy).coerceIn(0f, bottom - minS) }
                                        DragMode.NE -> { right = (right + dx).coerceIn(left + minS, 1f); top = (top + dy).coerceIn(0f, bottom - minS) }
                                        DragMode.SW -> { left = (left + dx).coerceIn(0f, right - minS); bottom = (bottom + dy).coerceIn(top + minS, 1f) }
                                        DragMode.SE -> { right = (right + dx).coerceIn(left + minS, 1f); bottom = (bottom + dy).coerceIn(top + minS, 1f) }
                                        DragMode.N -> top = (top + dy).coerceIn(0f, bottom - minS)
                                        DragMode.S -> bottom = (bottom + dy).coerceIn(top + minS, 1f)
                                        DragMode.W -> left = (left + dx).coerceIn(0f, right - minS)
                                        DragMode.E -> right = (right + dx).coerceIn(left + minS, 1f)
                                        DragMode.NONE -> Unit
                                    }
                                    if (dragMode != DragMode.MOVE) cropRect = CropRectNorm(left, top, right - left, bottom - top)
                                }
                                previous = change.position
                            } while (event.changes.any { it.id == down.id && it.pressed })
                            dragMode = DragMode.NONE
                        }
                    }
            ) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "PDF Page",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val l = cropRect.left * size.width
                    val t = cropRect.top * size.height
                    val w = cropRect.width * size.width
                    val h = cropRect.height * size.height

                    // Dark scrim outside crop region
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset.Zero, Size(size.width, t))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, t + h), Size(size.width, size.height - (t + h)))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, t), Size(l, h))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(l + w, t), Size(size.width - (l + w), h))

                    // Crop rectangle border
                    drawRect(Color(0xFF2563EB), Offset(l, t), Size(w, h), style = Stroke(width = 4f))

                    // 4 Corner handles + 4 Edge handles
                    val handles = listOf(
                        Offset(l, t), Offset(l + w, t), Offset(l, t + h), Offset(l + w, t + h),
                        Offset(l + w / 2f, t), Offset(l + w / 2f, t + h), Offset(l, t + h / 2f), Offset(l + w, t + h / 2f)
                    )
                    handles.forEach { pt ->
                        drawCircle(Color(0xFF2563EB), radius = 12f, center = pt)
                        drawCircle(Color.White, radius = 6f, center = pt)
                    }
                }
            }
        }

        // Live Crop Preview Card
        liveCroppedBitmap?.let { previewBmp ->
            Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Live Crop Preview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Image(
                        bitmap = previewBmp.asImageBitmap(),
                        contentDescription = "Live Cropped Preview",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }

        // Page Scope Selector: All Pages / Current Page / Selected Pages
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = pageScope == CropPageScope.ALL_PAGES,
                onClick = { pageScope = CropPageScope.ALL_PAGES },
                label = { Text("All Pages") }
            )
            FilterChip(
                selected = pageScope == CropPageScope.CURRENT_PAGE,
                onClick = { pageScope = CropPageScope.CURRENT_PAGE },
                label = { Text("Current Page") }
            )
            FilterChip(
                selected = pageScope == CropPageScope.SELECTED_PAGES,
                onClick = { pageScope = CropPageScope.SELECTED_PAGES },
                label = { Text("Selected") }
            )
        }
        if (pageScope == CropPageScope.SELECTED_PAGES) {
            OutlinedTextField(
                value = selectedRangeText,
                onValueChange = { selectedRangeText = it },
                label = { Text("Selected Pages (e.g. 1-2, 4)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Rename Output PDF + Choose Save Location via SAF
        OutlinedTextField(
            value = outputFileName,
            onValueChange = { outputFileName = it },
            label = { Text("Output PDF Name (Never overwrites original)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            enabled = sourceFile != null && !isBusy,
            onClick = { saveCroppedLauncher.launch(outputFileName.ifBlank { "Cropped.pdf" }) },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.Default.SaveAs, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (isBusy) "Cropping PDF..." else "Choose Save Location & Export Cropped PDF")
        }

        if (statusText.isNotEmpty()) {
            Text(statusText, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
`,

    [`app/src/main/java/${pkgPath}/ui/ToolScreens.kt`]: `package ${config.packageName}.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ${config.packageName}.engine.PdfDocumentEngine
import ${config.packageName}.model.RecentDocumentRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("Executive Project Brief") }
    var body by remember { mutableStateOf("Type or paste your notes here to convert to PDF.") }
    var isLetter by remember { mutableStateOf(false) }
    var outName by remember { mutableStateOf("Text_Document.pdf") }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            scope.launch {
                val outTemp = File.createTempFile("txt_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.createPdfFromText(title, body, 11f, isLetter, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Text to PDF", uri.toString(), bytes, "Just now", if (isLetter) "Letter" else "A4"))
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Text to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Document Heading") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Text Content") }, minLines = 6, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !isLetter, onClick = { isLetter = false }, label = { Text("A4") })
            FilterChip(selected = isLetter, onClick = { isLetter = true }, label = { Text("Letter") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output File Name") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Choose Save Location & Export PDF") }
    }
}

@Composable
fun ExcelToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var excelFile by remember { mutableStateOf<File?>(null) }
    var landscape by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("Spreadsheet_Report.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { excelFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "xls_", ".xlsx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = excelFile
        if (uri != null && src != null) {
            scope.launch {
                val outTemp = File.createTempFile("xls_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.convertExcelToPdf(src, outName.removeSuffix(".pdf"), landscape, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Excel to PDF", uri.toString(), bytes, "Just now", if (landscape) "Landscape" else "Portrait"))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }) {
            Text(if (excelFile == null) "Select .XLSX / .XLS File" else "Spreadsheet Loaded")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
            FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = excelFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Export Spreadsheet to PDF") }
    }
}

@Composable
fun PdfSplitScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var rangeStr by remember { mutableStateOf("1") }
    var asZip by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "split_", ".pdf") }
            val (_, count) = withContext(Dispatchers.IO) { PdfDocumentEngine.renderPdfPageBitmap(f, 0, 0.5f) }
            pdfFile = f; totalPages = count
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(if (asZip) "application/zip" else "application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val pages = PdfDocumentEngine.parsePageRange(rangeStr, totalPages.coerceAtLeast(1))
            val outTemp = File.createTempFile("split_out_", if (asZip) ".zip" else ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.splitPdf(src, pages, asZip, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), if (asZip) "Split_Pages.zip" else "Split_Pages.pdf", "PDF Split", uri.toString(), bytes, "Just now", "\${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Page Split", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "Loaded ($totalPages pages)") }
        OutlinedTextField(value = rangeStr, onValueChange = { rangeStr = it }, label = { Text("Page Range (e.g. 1-2, 4)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !asZip, onClick = { asZip = false }, label = { Text("Single PDF") })
            FilterChip(selected = asZip, onClick = { asZip = true }, label = { Text("ZIP of Pages") })
        }
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(if (asZip) "Split_Pages.zip" else "Split_Pages.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Extract & Save") }
    }
}

@Composable
fun PdfMergeScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<Pair<String, File>>>(emptyList()) }
    var outName by remember { mutableStateOf("Merged_Document.pdf") }

    val addLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                uris.mapIndexed { idx, u -> "PDF #\${files.size + idx + 1}" to PdfDocumentEngine.copyUriToTempFile(context, u, "merge_", ".pdf") }
            }
            files = files + loaded
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && files.isNotEmpty()) scope.launch {
            val outTemp = File.createTempFile("merged_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.mergePdfs(files.map { it.second }, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF Merge", uri.toString(), bytes, "Just now", "\${files.size} files"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Merge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { addLauncher.launch(arrayOf("application/pdf")) }) { Text("Add PDF Files (\${files.size} queued)") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Merged Output Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = files.size >= 2, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Merge & Save PDF") }
    }
}

@Composable
fun SignPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var signerName by remember { mutableStateOf("Authorized Signer") }
    var strokes by remember { mutableStateOf<List<List<androidx.compose.ui.geometry.Offset>>>(emptyList()) }
    var currentStroke by remember { mutableStateOf<List<androidx.compose.ui.geometry.Offset>>(emptyList()) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "sign_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val bmp = Bitmap.createBitmap(600, 220, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(bmp)
            val paint = Paint().apply { color = android.graphics.Color.rgb(29, 78, 216); strokeWidth = 6f; style = Paint.Style.STROKE; isAntiAlias = true }
            strokes.forEach { pts ->
                if (pts.size > 1) {
                    val path = AndroidPath().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                    canvas.drawPath(path, paint)
                }
            }
            val outTemp = File.createTempFile("signed_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.signPdf(src, bmp, signerName, 1, 0.52f, 0.72f, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Signed_Document.pdf", "Sign PDF", uri.toString(), bytes, "Just now", signerName))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sign PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "PDF Ready") }
        OutlinedTextField(value = signerName, onValueChange = { signerName = it }, label = { Text("Signer Name") }, modifier = Modifier.fillMaxWidth())
        Box(
            Modifier.fillMaxWidth().height(150.dp).background(Color.White).border(1.dp, MaterialTheme.colorScheme.outline)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { currentStroke = listOf(it) },
                        onDrag = { change, _ -> change.consume(); currentStroke = currentStroke + change.position },
                        onDragEnd = { strokes = strokes + listOf(currentStroke); currentStroke = emptyList() }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                (strokes + listOf(currentStroke)).forEach { pts ->
                    if (pts.size > 1) {
                        val p = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                        drawPath(p, Color(0xFF1D4ED8), style = Stroke(width = 6f, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { strokes = emptyList() }) { Text("Clear Ink") }
            Button(enabled = pdfFile != null && strokes.isNotEmpty(), onClick = { saveLauncher.launch("Signed_Document.pdf") }, modifier = Modifier.weight(1f)) { Text("Stamp & Save PDF") }
        }
    }
}

@Composable
fun PdfToWordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Converted_Document.docx") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "p2w_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("p2w_out_", ".docx", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertPdfToWord(src, outName.removeSuffix(".docx"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF to Word", uri.toString(), bytes, "Just now", "DOCX Export"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF to Word (.docx)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Select PDF" else "PDF Selected") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output Word Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save .DOCX") }
    }
}

@Composable
fun WordToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docxFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Word_Export.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { docxFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "w2p_", ".docx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = docxFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("w2p_out_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertWordToPdf(src, outName.removeSuffix(".pdf"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Word to PDF", uri.toString(), bytes, "Just now", "DOCX -> PDF"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Word (.docx) to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text(if (docxFile == null) "Select .DOCX File" else "Word File Ready") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = docxFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save PDF") }
    }
}

@Composable
fun PdfPasswordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var userPwd by remember { mutableStateOf("") }
    var ownerPwd by remember { mutableStateOf("") }
    var watermark by remember { mutableStateOf("CONFIDENTIAL") }
    var allowPrint by remember { mutableStateOf(true) }
    var allowCopy by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "lock_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("locked_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.protectPdf(src, userPwd, ownerPwd.ifBlank { userPwd }, watermark, allowPrint, allowCopy, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Protected_Document.pdf", "PDF Password", uri.toString(), bytes, "Just now", "AES-256 Encrypted"))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Password Protection (AES-256)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "PDF Ready") }
        OutlinedTextField(value = userPwd, onValueChange = { userPwd = it }, label = { Text("User Open Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ownerPwd, onValueChange = { ownerPwd = it }, label = { Text("Owner Permissions Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = watermark, onValueChange = { watermark = it }, label = { Text("Diagonal Watermark") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowPrint, onCheckedChange = { allowPrint = it }); Text("Allow Printing") }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowCopy, onCheckedChange = { allowCopy = it }); Text("Allow Copy") }
        Button(enabled = pdfFile != null && userPwd.isNotBlank(), onClick = { saveLauncher.launch("Protected_Document.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Encrypt & Save PDF") }
    }
}

@Composable
fun RecentUsedScreen(records: List<RecentDocumentRecord>, onClear: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Recent Used Files (\${records.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (records.isNotEmpty()) { TextButton(onClick = onClear) { Text("Clear") } }
        }
        if (records.isEmpty()) {
            Text("Processed documents will appear here for one-tap access.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { item ->
                    ElevatedCard(onClick = {
                        runCatching {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse(item.uriString)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.displayName, fontWeight = FontWeight.SemiBold)
                            Text("\${item.toolTitle} · \${item.summary} · \${item.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
`,

    [`app/src/main/java/${pkgPath}/MainActivity.kt`]: `package ${config.packageName}

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import ${config.packageName}.model.RecentDocumentRecord
import ${config.packageName}.model.ToolCardMeta
import ${config.packageName}.model.ToolType
import ${config.packageName}.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            MaterialTheme {
                BTDocumentApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BTDocumentApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeTool by remember { mutableStateOf<ToolType?>(null) }
    var recentRecords by remember { mutableStateOf<List<RecentDocumentRecord>>(emptyList()) }

    val toolCards = remember {
        listOf(
            ToolCardMeta(ToolType.TEXT_TO_PDF, "01", Icons.Default.Description),
            ToolCardMeta(ToolType.EXCEL_TO_PDF, "02", Icons.Default.TableChart),
            ToolCardMeta(ToolType.PDF_CROP, "03", Icons.Default.Crop),
            ToolCardMeta(ToolType.PDF_SPLIT, "04", Icons.Default.ContentCut),
            ToolCardMeta(ToolType.PDF_MERGE, "05", Icons.Default.Layers),
            ToolCardMeta(ToolType.SIGN_PDF, "06", Icons.Default.Draw),
            ToolCardMeta(ToolType.PDF_TO_WORD, "07", Icons.Default.Article),
            ToolCardMeta(ToolType.WORD_TO_PDF, "08", Icons.Default.PictureAsPdf),
            ToolCardMeta(ToolType.PDF_PASSWORD, "09", Icons.Default.Lock)
        )
    }

    val recordOutput: (RecentDocumentRecord) -> Unit = { rec ->
        recentRecords = listOf(rec) + recentRecords
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        activeTool?.title ?: "${config.appName}",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (activeTool != null) {
                        IconButton(onClick = { activeTool = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "All 9 Tools") },
                    label = { Text("All 9 Tools") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1; activeTool = null },
                    icon = { Icon(Icons.Default.History, contentDescription = "Recent Used") },
                    label = { Text("Recent (\${recentRecords.size})") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (selectedTab == 1) {
                RecentUsedScreen(
                    records = recentRecords,
                    onClear = { recentRecords = emptyList() }
                )
            } else when (activeTool) {
                null -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(toolCards) { card ->
                        ElevatedCard(
                            onClick = { activeTool = card.type },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Icon(card.icon, contentDescription = card.type.title, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("\${card.number}. \${card.type.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(card.type.subtitle, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                ToolType.TEXT_TO_PDF -> TextToPdfScreen(recordOutput)
                ToolType.EXCEL_TO_PDF -> ExcelToPdfScreen(recordOutput)
                ToolType.PDF_CROP -> PdfCropScreen(recordOutput)
                ToolType.PDF_SPLIT -> PdfSplitScreen(recordOutput)
                ToolType.PDF_MERGE -> PdfMergeScreen(recordOutput)
                ToolType.SIGN_PDF -> SignPdfScreen(recordOutput)
                ToolType.PDF_TO_WORD -> PdfToWordScreen(recordOutput)
                ToolType.WORD_TO_PDF -> WordToPdfScreen(recordOutput)
                ToolType.PDF_PASSWORD -> PdfPasswordScreen(recordOutput)
            }
        }
    }
}
`,

    'ANDROID_ARCHITECTURE.md': `# ${config.appName} — Native Android Kotlin & Jetpack Compose Technical Guide

## 1. Non-Destructive File Handling & Save Location Selection (SAF)
- **Open**: \`ActivityResultContracts.OpenDocument()\` opens any PDF/Excel/Word file via Android Storage Access Framework without requesting broad legacy storage permissions.
- **Read-Only Isolation**: \`PdfDocumentEngine.copyUriToTempFile\` copies the user's input stream into an app-private cache file. **The original file URI is never opened in write mode or modified.**
- **Rename & Save Location**: \`ActivityResultContracts.CreateDocument(mimeType)\` launches Android's native system file saver pre-filled with the user's custom filename (e.g. \`Cropped_Contract.pdf\`), allowing the user to pick any save folder (Downloads, Documents, Drive, SD Card).

## 2. PDF Crop (Photo-Style) — Technical Logic (\`PdfCropScreen.kt\` & \`PdfDocumentEngine.cropPdfPermanent\`)
1. **Preview**: \`android.graphics.pdf.PdfRenderer\` renders page bitmaps for instant display.
2. **Gestures**: Jetpack Compose \`pointerInput\` + \`detectDragGestures\` tracks touch coordinates across all **4 corners** (\`NW, NE, SW, SE\`), all **4 edges** (\`N, S, E, W\`), and the **interior rectangle** (\`MOVE\`) with a 48px touch tolerance.
3. **Live Preview**: \`derivedStateOf\` slices the rendered page \`Bitmap\` to \`cropRect\` bounds so the user sees the exact cropped output in real time.
4. **Revert & Reset**: \`cropHistory\` stores previous normalized crop boxes for 1-tap **Revert**; **Reset Full** restores \`(0f, 0f, 1f, 1f)\`.
5. **Permanent PDF Cropping**: \`LayerUtility.importPageAsForm\` imports each selected page as a PDF Form XObject, clips the graphics state to \`[0, 0, cropW, cropH]\`, translates by \`(-cropX, -cropY)\`, and writes normalized \`mediaBox\`, \`cropBox\`, \`trimBox\`, \`bleedBox\`, and \`artBox\`. Unselected pages are copied unmodified.

## 3. All 9 Tools Native Libraries
| # | Tool | Native Android Implementation |
|---|------|-------------------------------|
| 01 | Text to PDF | \`PDDocument\` + \`PDPageContentStream\` multi-page word-wrapping |
| 02 | Excel to PDF | Apache POI \`WorkbookFactory\` + \`PDPageContentStream\` table grid |
| 03 | PDF Crop | \`PdfRenderer\` + Compose gestures + \`LayerUtility\` permanent XObject clip |
| 04 | PDF Page Split | \`Splitter\` + \`ZipOutputStream\` |
| 05 | PDF Merge | \`PDFMergerUtility\` |
| 06 | Sign PDF | Compose \`Canvas\` -> \`Bitmap\` -> \`LosslessFactory.createFromImage\` |
| 07 | PDF to Word | \`PDFTextStripper\` -> Apache POI \`XWPFDocument\` (\`.docx\`) |
| 08 | Word to PDF | Apache POI \`XWPFDocument\` -> \`PDDocument\` |
| 09 | PDF Password | \`StandardProtectionPolicy\` (256-bit AES) + \`AccessPermission\` |

## 4. Build APK Instructions
\`\`\`bash
./gradlew assembleDebug
# APK output: app/build/outputs/apk/debug/app-debug.apk
\`\`\`
`,
  };
}

export async function generateAndroidStudioZip(config: ApkProjectConfig): Promise<Uint8Array> {
  const zip = new JSZip();
  const files = getAndroidFiles(config);

  for (const [filePath, content] of Object.entries(files)) {
    zip.file(filePath, content);
  }

  return await zip.generateAsync({ type: 'uint8array' });
}
