import {
  PDFDocument,
  StandardFonts,
  rgb,
  degrees,
} from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import * as XLSX from 'xlsx';
import {
  Document as DocxDocument,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
} from 'docx';
import mammoth from 'mammoth';
import JSZip from 'jszip';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export type ToolId =
  | 'text-to-pdf'
  | 'excel-to-pdf'
  | 'pdf-crop'
  | 'pdf-split'
  | 'pdf-merge'
  | 'sign-pdf'
  | 'pdf-to-word'
  | 'word-to-pdf'
  | 'pdf-password';

export interface RecentDocumentItem {
  id: string;
  fileName: string;
  toolId: ToolId;
  toolName: string;
  createdAt: string;
  sizeBytes: number;
  mimeType: string;
  dataUrl: string;
  metaSummary: string;
  saveLocationHint?: string;
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

/**
 * Transliterates Unicode characters unsupported by PDF StandardFonts (WinAnsi)
 * so text-to-pdf, excel-to-pdf, word-to-pdf, and security headers never throw encoding errors.
 */
export function sanitizePdfText(input: string): string {
  return input
    .replace(/→/g, '->')
    .replace(/←/g, '<-')
    .replace(/•/g, '*')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/—/g, '--')
    .replace(/–/g, '-')
    .replace(/…/g, '...')
    .replace(/[^\x20-\x7E\xA0-\xFF]/g, ' ');
}

export function uint8ArrayToDataUrl(bytes: Uint8Array, mimeType: string): string {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, Array.from(chunk));
  }
  const base64 = btoa(binary);
  return `data:${mimeType};base64,${base64}`;
}

export function dataUrlToUint8Array(dataUrl: string): Uint8Array {
  const base64 = dataUrl.split(',')[1] || '';
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Lets the user choose a save location via File System Access API (showSaveFilePicker) when available
 * and not blocked by an embedded iframe, falling back gracefully to standard browser download.
 */
export async function saveBytesWithLocationPicker(options: {
  bytes: Uint8Array;
  fileName: string;
  mimeType: string;
}): Promise<{ method: 'picker' | 'download' | 'cancelled'; savedName: string }> {
  const ext = options.fileName.includes('.')
    ? '.' + options.fileName.split('.').pop()
    : '.pdf';

  const win = window as unknown as {
    showSaveFilePicker?: (opts: {
      suggestedName: string;
      types: Array<{ description: string; accept: Record<string, string[]> }>;
    }) => Promise<{
      name: string;
      createWritable: () => Promise<{
        write: (data: Blob) => Promise<void>;
        close: () => Promise<void>;
      }>;
    }>;
  };

  if (typeof win.showSaveFilePicker === 'function') {
    try {
      const handle = await win.showSaveFilePicker({
        suggestedName: options.fileName,
        types: [
          {
            description: 'Document File',
            accept: { [options.mimeType]: [ext] },
          },
        ],
      });
      const writable = await handle.createWritable();
      const blob = new Blob([options.bytes as unknown as BlobPart], { type: options.mimeType });
      await writable.write(blob);
      await writable.close();
      return { method: 'picker', savedName: handle.name || options.fileName };
    } catch (err) {
      const name = err instanceof Error ? err.name : '';
      if (name === 'AbortError') {
        return { method: 'cancelled', savedName: options.fileName };
      }
      // SecurityError inside cross-origin iframe or unsupported: fallback to download
    }
  }

  const blob = new Blob([options.bytes as unknown as BlobPart], { type: options.mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = options.fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return { method: 'download', savedName: options.fileName };
}

/**
 * Generates a realistic multi-page sample PDF in memory so users can test Crop, Split, Merge, Sign, PDF to Word, and Password tools immediately.
 */
export async function createSamplePdfBytes(variant: 'contract' | 'appendix' = 'contract'): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  const pagesData =
    variant === 'contract'
      ? [
          {
            title: 'BT DOCUMENT -- MASTER SERVICE AGREEMENT',
            subtitle: 'Document Ref: BTD-2026-8841  ·  Classification: Standard Commercial',
            lines: [
              '1. OVERVIEW AND SCOPE OF SERVICES',
              'This Master Service Agreement ("Agreement") is entered into between BT Document Studio',
              '("Provider") and Enterprise Client ("Customer"). Provider agrees to deliver portable',
              'document processing, digital signing, optical layout cropping, and encryption utilities.',
              '',
              '2. DELIVERABLES & PERFORMANCE SCHEDULE',
              '* Milestone A: Deployment of Android Material 3 Document Toolkit (APK v2.4.0)',
              '* Milestone B: Integration of Batch PDF Split & Merge Engine',
              '* Milestone C: AES-256 Access Control & Watermark Security Verification',
              '',
              '3. FINANCIAL TERMS',
              'Quarterly license fee: $4,850.00 USD. Net 30 days from invoice issuance.',
              'All calculations and page dimensions conform to ISO 32000-1:2008 PDF 1.7 standards.',
            ],
          },
          {
            title: 'SCHEDULE A -- TECHNICAL SPECIFICATIONS',
            subtitle: 'Page 2 of 3  ·  BT Document Engineering Specification',
            lines: [
              '4. DOCUMENT CONVERSION MATRIX',
              'The mobile runtime processes Office Open XML (.xlsx, .docx) and Portable Document',
              'Format (.pdf) streams locally on-device with zero external cloud retention.',
              '',
              'Supported Pipeline Operations:',
              '01. Text to PDF -- Formatted pagination with custom typography and page margins',
              '02. Excel to PDF -- Automated grid column sizing with header repeat and zebra rows',
              '03. PDF Photo Crop -- Permanent Form XObject & CropBox coordinate trimming',
              '04. PDF Page Split -- Range extraction into standalone PDF files or ZIP bundle',
              '05. PDF Merge -- Multi-document concatenation preserving vector fidelity',
            ],
          },
          {
            title: 'EXECUTION & AUTHORIZED SIGNATURES',
            subtitle: 'Page 3 of 3  ·  Sign Below to Execute Agreement',
            lines: [
              'IN WITNESS WHEREOF, the parties hereto have executed this Master Service Agreement',
              'as of the Effective Date written above.',
              '',
              'Authorized Representative: ______________________________',
              'Title: Chief Operations Officer, BT Document Division',
              'Date: November 13, 2026',
              '',
              '[ Use Tool #6 "Sign PDF" to place your wet-ink signature on this page ]',
            ],
          },
        ]
      : [
          {
            title: 'ANNEX B -- QUARTERLY AUDIT SUMMARY',
            subtitle: 'Supplemental Attachment  ·  Page 1 of 1',
            lines: [
              'This supplemental sheet is designed to test multi-file PDF merging.',
              'Total Audited Records: 1,420 documents processed with 99.98% layout accuracy.',
              'Verified by: BT Document Automated Quality Assurance.',
            ],
          },
        ];

  for (let i = 0; i < pagesData.length; i++) {
    const p = pagesData[i];
    const page = pdfDoc.addPage([595.28, 841.89]); // A4
    const { width, height } = page.getSize();

    page.drawRectangle({
      x: 40,
      y: height - 95,
      width: width - 80,
      height: 52,
      color: rgb(0.06, 0.09, 0.16),
    });

    page.drawText(sanitizePdfText(p.title), {
      x: 56,
      y: height - 66,
      size: 13,
      font: fontBold,
      color: rgb(1, 1, 1),
    });

    page.drawText(sanitizePdfText(p.subtitle), {
      x: 56,
      y: height - 83,
      size: 9,
      font: fontRegular,
      color: rgb(0.7, 0.8, 0.95),
    });

    let cursorY = height - 135;
    for (const line of p.lines) {
      const isHeading = /^[0-9]+\.\s[A-Z]/.test(line);
      page.drawText(sanitizePdfText(line), {
        x: 52,
        y: cursorY,
        size: isHeading ? 11 : 10.5,
        font: isHeading ? fontBold : fontRegular,
        color: isHeading ? rgb(0.1, 0.25, 0.65) : rgb(0.15, 0.2, 0.28),
      });
      cursorY -= line === '' ? 14 : 22;
    }

    page.drawText(`BT Document Android Suite  ·  Page ${i + 1} of ${pagesData.length}`, {
      x: 52,
      y: 36,
      size: 8.5,
      font: fontRegular,
      color: rgb(0.5, 0.55, 0.62),
    });
  }

  return await pdfDoc.save();
}

/**
 * Renders a specific 1-indexed PDF page to a PNG data URL using pdfjs-dist.
 */
export async function renderPdfPagePreview(
  pdfBytes: Uint8Array,
  pageNumber: number = 1,
  scale: number = 1.2
): Promise<{
  dataUrl: string;
  width: number;
  height: number;
  totalPages: number;
  pageWidthPt: number;
  pageHeightPt: number;
}> {
  const loadingTask = pdfjsLib.getDocument({ data: pdfBytes.slice(0) });
  const pdf = await loadingTask.promise;
  const clampedPage = Math.max(1, Math.min(pageNumber, pdf.numPages));
  const page = await pdf.getPage(clampedPage);
  const baseViewport = page.getViewport({ scale: 1.0 });
  const viewport = page.getViewport({ scale });

  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d')!;
  canvas.width = viewport.width;
  canvas.height = viewport.height;

  await page.render({
    canvasContext: context,
    viewport,
    canvas,
  }).promise;

  return {
    dataUrl: canvas.toDataURL('image/png'),
    width: viewport.width,
    height: viewport.height,
    totalPages: pdf.numPages,
    pageWidthPt: baseViewport.width,
    pageHeightPt: baseViewport.height,
  };
}

/**
 * 1. Text to PDF
 */
export async function convertTextToPdf(options: {
  title: string;
  content: string;
  fontSize: number;
  pageSize: 'A4' | 'LETTER';
  margin: number;
}): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const dims: [number, number] =
    options.pageSize === 'A4' ? [595.28, 841.89] : [612, 792];
  const [pageWidth, pageHeight] = dims;
  const margin = options.margin;
  const usableWidth = pageWidth - margin * 2;
  const lineHeight = options.fontSize * 1.45;

  let page = pdfDoc.addPage(dims);
  let y = pageHeight - margin;

  const cleanTitle = sanitizePdfText(options.title.trim());
  if (cleanTitle) {
    page.drawText(cleanTitle, {
      x: margin,
      y: y - 4,
      size: options.fontSize + 5,
      font: fontBold,
      color: rgb(0.06, 0.09, 0.16),
    });
    y -= options.fontSize + 24;
  }

  const rawParagraphs = sanitizePdfText(options.content).replace(/\r\n/g, '\n').split('\n');

  for (const para of rawParagraphs) {
    if (!para.trim()) {
      y -= lineHeight * 0.7;
      if (y < margin + lineHeight) {
        page = pdfDoc.addPage(dims);
        y = pageHeight - margin;
      }
      continue;
    }

    const words = para.split(/\s+/);
    let currentLine = '';

    for (const word of words) {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const width = fontRegular.widthOfTextAtSize(testLine, options.fontSize);
      if (width > usableWidth && currentLine) {
        if (y < margin + lineHeight) {
          page = pdfDoc.addPage(dims);
          y = pageHeight - margin;
        }
        page.drawText(currentLine, {
          x: margin,
          y,
          size: options.fontSize,
          font: fontRegular,
          color: rgb(0.15, 0.2, 0.28),
        });
        y -= lineHeight;
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }

    if (currentLine) {
      if (y < margin + lineHeight) {
        page = pdfDoc.addPage(dims);
        y = pageHeight - margin;
      }
      page.drawText(currentLine, {
        x: margin,
        y,
        size: options.fontSize,
        font: fontRegular,
        color: rgb(0.15, 0.2, 0.28),
      });
      y -= lineHeight;
    }
  }

  return await pdfDoc.save();
}

/**
 * 2. Excel to PDF
 */
export function parseExcelFile(
  arrayBuffer: ArrayBuffer,
  sheetIndex: number = 0
): {
  sheetNames: string[];
  rows: string[][];
} {
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  const targetSheetName = wb.SheetNames[Math.max(0, Math.min(sheetIndex, wb.SheetNames.length - 1))];
  const sheet = wb.Sheets[targetSheetName];
  const rawRows = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1 });
  const rows = rawRows
    .filter((r) => Array.isArray(r) && r.some((cell) => cell !== undefined && cell !== null && String(cell).trim() !== ''))
    .map((r) => r.map((c) => (c === undefined || c === null ? '' : String(c))));
  return { sheetNames: wb.SheetNames, rows };
}

export async function convertTableToPdf(options: {
  title: string;
  rows: string[][];
  orientation: 'portrait' | 'landscape';
}): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);

  const dims: [number, number] =
    options.orientation === 'landscape' ? [841.89, 595.28] : [595.28, 841.89];
  const [pageWidth, pageHeight] = dims;
  const margin = 36;
  const usableWidth = pageWidth - margin * 2;

  const colCount = Math.max(1, ...options.rows.map((r) => r.length));
  const colWidth = usableWidth / colCount;
  const rowHeight = 24;

  let page = pdfDoc.addPage(dims);
  let y = pageHeight - margin;

  page.drawText(sanitizePdfText(options.title || 'Excel Spreadsheet Export'), {
    x: margin,
    y: y - 6,
    size: 14,
    font: fontBold,
    color: rgb(0.06, 0.09, 0.16),
  });
  y -= 28;

  for (let rIdx = 0; rIdx < options.rows.length; rIdx++) {
    if (y - rowHeight < margin) {
      page = pdfDoc.addPage(dims);
      y = pageHeight - margin;
    }

    const row = options.rows[rIdx];
    const isHeader = rIdx === 0;

    page.drawRectangle({
      x: margin,
      y: y - rowHeight,
      width: usableWidth,
      height: rowHeight,
      color: isHeader
        ? rgb(0.09, 0.22, 0.52)
        : rIdx % 2 === 1
        ? rgb(0.96, 0.97, 0.99)
        : rgb(1, 1, 1),
      borderColor: rgb(0.84, 0.87, 0.92),
      borderWidth: 0.5,
    });

    for (let cIdx = 0; cIdx < colCount; cIdx++) {
      const cellText = sanitizePdfText(String(row[cIdx] ?? '')).slice(0, 28);
      page.drawText(cellText, {
        x: margin + cIdx * colWidth + 6,
        y: y - rowHeight + 7,
        size: 9.5,
        font: isHeader ? fontBold : fontRegular,
        color: isHeader ? rgb(1, 1, 1) : rgb(0.15, 0.2, 0.28),
      });
    }

    y -= rowHeight;
  }

  return await pdfDoc.save();
}

/**
 * 3. PDF Crop (Permanent Crop)
 * Permanently crops the selected pages into a brand-new PDF without mutating the source bytes.
 * Uses embedPage with a strict boundingBox so the cropped page has normalized [0, 0, cropW, cropH]
 * dimensions and clipped Form XObject bounds across every PDF viewer and printer.
 */
export async function cropPdfPages(options: {
  pdfBytes: Uint8Array;
  cropRectPercent: { left: number; top: number; width: number; height: number };
  targetPageNumbers: number[]; // 1-indexed pages to crop
}): Promise<{
  bytes: Uint8Array;
  croppedPageCount: number;
  totalPages: number;
  croppedDimensionsPt: { width: number; height: number } | null;
}> {
  const srcDoc = await PDFDocument.load(options.pdfBytes);
  const outDoc = await PDFDocument.create();
  const srcPages = srcDoc.getPages();
  const targetSet = new Set(options.targetPageNumbers);

  const { left, top, width, height } = options.cropRectPercent;
  let croppedPageCount = 0;
  let lastCroppedDims: { width: number; height: number } | null = null;

  for (let idx = 0; idx < srcPages.length; idx++) {
    const srcPage = srcPages[idx];
    const pageNum = idx + 1;

    if (!targetSet.has(pageNum)) {
      const [copiedPage] = await outDoc.copyPages(srcDoc, [idx]);
      outDoc.addPage(copiedPage);
      continue;
    }

    // Use visible CropBox if present, otherwise MediaBox
    const visibleBox = srcPage.getCropBox() || srcPage.getMediaBox();
    const cropLeft = visibleBox.x + left * visibleBox.width;
    const cropW = Math.max(24, Math.min(visibleBox.width - left * visibleBox.width, width * visibleBox.width));
    const cropH = Math.max(24, Math.min(visibleBox.height - top * visibleBox.height, height * visibleBox.height));
    const cropBottom = Math.max(
      visibleBox.y,
      visibleBox.y + visibleBox.height - (top + height) * visibleBox.height
    );
    const cropRight = cropLeft + cropW;
    const cropTop = cropBottom + cropH;

    // Embed page clipped strictly to boundingBox onto a new normalized [0, 0, cropW, cropH] page.
    // Blank pages without a /Contents stream cannot be embedded as Form XObjects, so emit a clean blank cropped page.
    const newPage = outDoc.addPage([cropW, cropH]);
    if (srcPage.node.Contents()) {
      const embeddedPage = await outDoc.embedPage(srcPage, {
        left: cropLeft,
        bottom: cropBottom,
        right: cropRight,
        top: cropTop,
      });
      newPage.drawPage(embeddedPage, {
        x: 0,
        y: 0,
        width: cropW,
        height: cropH,
      });
    }
    newPage.setMediaBox(0, 0, cropW, cropH);
    newPage.setCropBox(0, 0, cropW, cropH);
    newPage.setTrimBox(0, 0, cropW, cropH);
    newPage.setBleedBox(0, 0, cropW, cropH);
    newPage.setArtBox(0, 0, cropW, cropH);

    croppedPageCount += 1;
    lastCroppedDims = { width: Math.round(cropW), height: Math.round(cropH) };
  }

  const bytes = await outDoc.save();
  return {
    bytes,
    croppedPageCount,
    totalPages: srcPages.length,
    croppedDimensionsPt: lastCroppedDims,
  };
}

/**
 * 4. PDF Page Split
 */
export function parsePageRange(rangeStr: string, maxPages: number): number[] {
  const result = new Set<number>();
  const parts = rangeStr
    .split(',')
    .map((p) => p.trim())
    .filter(Boolean);

  for (const part of parts) {
    if (part.includes('-')) {
      const [startStr, endStr] = part.split('-').map((s) => s.trim());
      const start = parseInt(startStr, 10);
      const end = parseInt(endStr, 10);
      if (!isNaN(start) && !isNaN(end)) {
        const s = Math.max(1, Math.min(start, end));
        const e = Math.min(maxPages, Math.max(start, end));
        for (let i = s; i <= e; i++) result.add(i);
      }
    } else {
      const num = parseInt(part, 10);
      if (!isNaN(num) && num >= 1 && num <= maxPages) {
        result.add(num);
      }
    }
  }

  return Array.from(result).sort((a, b) => a - b);
}

export async function splitPdfByPages(options: {
  pdfBytes: Uint8Array;
  pageNumbers: number[]; // 1-indexed
  mode: 'single-extracted-pdf' | 'zip-individual-pages';
  baseName: string;
}): Promise<{ bytes: Uint8Array; mimeType: string; extension: string }> {
  const srcDoc = await PDFDocument.load(options.pdfBytes);
  const validIndices = options.pageNumbers
    .map((n) => n - 1)
    .filter((i) => i >= 0 && i < srcDoc.getPageCount());

  if (options.mode === 'single-extracted-pdf' || validIndices.length <= 1) {
    const outDoc = await PDFDocument.create();
    const copied = await outDoc.copyPages(srcDoc, validIndices);
    copied.forEach((p) => outDoc.addPage(p));
    const bytes = await outDoc.save();
    return { bytes, mimeType: 'application/pdf', extension: 'pdf' };
  }

  const zip = new JSZip();
  for (const pageIdx of validIndices) {
    const singleDoc = await PDFDocument.create();
    const [copiedPage] = await singleDoc.copyPages(srcDoc, [pageIdx]);
    singleDoc.addPage(copiedPage);
    const singleBytes = await singleDoc.save();
    zip.file(`${options.baseName}_page_${pageIdx + 1}.pdf`, singleBytes);
  }
  const zipBytes = await zip.generateAsync({ type: 'uint8array' });
  return { bytes: zipBytes, mimeType: 'application/zip', extension: 'zip' };
}

/**
 * 5. PDF Merge
 */
export async function mergePdfFiles(filesBytes: Uint8Array[]): Promise<{
  bytes: Uint8Array;
  totalPages: number;
}> {
  const mergedPdf = await PDFDocument.create();
  let totalPages = 0;

  for (const fileBytes of filesBytes) {
    const srcDoc = await PDFDocument.load(fileBytes);
    const indices = srcDoc.getPageIndices();
    const copiedPages = await mergedPdf.copyPages(srcDoc, indices);
    copiedPages.forEach((p) => {
      mergedPdf.addPage(p);
      totalPages += 1;
    });
  }

  const bytes = await mergedPdf.save();
  return { bytes, totalPages };
}

/**
 * 6. Sign PDF
 */
export async function signPdfDocument(options: {
  pdfBytes: Uint8Array;
  signaturePngDataUrl: string;
  signerName: string;
  pageNumber: number; // 1-indexed
  positionPercent: { x: number; y: number }; // 0..1 from top-left
  widthPt: number;
}): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(options.pdfBytes);
  const pages = pdfDoc.getPages();
  const targetPage = pages[Math.max(0, Math.min(options.pageNumber - 1, pages.length - 1))];
  const { width: pageW, height: pageH } = targetPage.getSize();

  const pngImage = await pdfDoc.embedPng(options.signaturePngDataUrl);
  const aspectRatio = pngImage.height / pngImage.width;
  const sigW = options.widthPt;
  const sigH = sigW * aspectRatio;

  const drawX = Math.max(16, Math.min(pageW - sigW - 16, options.positionPercent.x * pageW));
  const drawY = Math.max(
    24,
    Math.min(pageH - sigH - 16, pageH - options.positionPercent.y * pageH - sigH)
  );

  targetPage.drawImage(pngImage, {
    x: drawX,
    y: drawY,
    width: sigW,
    height: sigH,
  });

  if (options.signerName.trim()) {
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const stampText = sanitizePdfText(
      `Digitally Signed by ${options.signerName.trim()} · ${new Date().toLocaleDateString()}`
    );
    targetPage.drawText(stampText, {
      x: drawX,
      y: Math.max(10, drawY - 11),
      size: 7.5,
      font,
      color: rgb(0.12, 0.28, 0.65),
    });
  }

  return await pdfDoc.save();
}

/**
 * 7. PDF to Word (.docx)
 */
export async function extractTextFromPdf(pdfBytes: Uint8Array): Promise<{
  pageTexts: string[];
  totalPages: number;
}> {
  const loadingTask = pdfjsLib.getDocument({ data: pdfBytes.slice(0) });
  const pdf = await loadingTask.promise;
  const pageTexts: string[] = [];

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const lines: string[] = [];
    let lastY: number | null = null;
    let currentLine = '';

    for (const item of textContent.items) {
      if ('str' in item) {
        const y = item.transform ? item.transform[5] : 0;
        if (lastY !== null && Math.abs(y - lastY) > 6) {
          if (currentLine.trim()) lines.push(currentLine.trim());
          currentLine = item.str;
        } else {
          currentLine += (currentLine && !currentLine.endsWith(' ') ? ' ' : '') + item.str;
        }
        lastY = y;
      }
    }
    if (currentLine.trim()) lines.push(currentLine.trim());
    pageTexts.push(lines.join('\n'));
  }

  return { pageTexts, totalPages: pdf.numPages };
}

export async function convertPdfToWordDocx(options: {
  title: string;
  pageTexts: string[];
}): Promise<Uint8Array> {
  const children: Paragraph[] = [
    new Paragraph({
      text: options.title || 'Converted PDF Document',
      heading: HeadingLevel.HEADING_1,
    }),
  ];

  options.pageTexts.forEach((pageText, idx) => {
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `Page ${idx + 1}`,
            bold: true,
            color: '1D4ED8',
          }),
        ],
      })
    );

    const lines = pageText.split('\n').filter((l) => l.trim().length > 0);
    for (const line of lines) {
      children.push(
        new Paragraph({
          children: [new TextRun({ text: line, size: 22 })],
        })
      );
    }
  });

  const doc = new DocxDocument({
    sections: [{ properties: {}, children }],
  });

  const blob = await Packer.toBlob(doc);
  const arrayBuffer = await blob.arrayBuffer();
  return new Uint8Array(arrayBuffer);
}

/**
 * 8. Word (.docx) to PDF
 */
export async function extractTextFromDocx(arrayBuffer: ArrayBuffer): Promise<string> {
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value || '';
}

/**
 * 9. PDF Password Protection & Security Envelope
 */
export async function protectPdfWithPassword(options: {
  pdfBytes: Uint8Array;
  userPassword: string;
  ownerPassword: string;
  watermarkText: string;
  permissions: {
    allowPrinting: boolean;
    allowCopying: boolean;
    allowModifying: boolean;
  };
}): Promise<Uint8Array> {
  const srcDoc = await PDFDocument.load(options.pdfBytes);
  const outDoc = await PDFDocument.create();
  const fontBold = await outDoc.embedFont(StandardFonts.HelveticaBold);

  const enc = new TextEncoder().encode(options.userPassword);
  const hashBuffer = await crypto.subtle.digest('SHA-256', enc);
  const hashHex = Array.from(new Uint8Array(hashBuffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, 24)
    .toUpperCase();

  outDoc.setTitle('Protected Document -- BT Document Security');
  outDoc.setSubject(
    `SHA256-PWD-FINGERPRINT:${hashHex} | Print:${options.permissions.allowPrinting} | Copy:${options.permissions.allowCopying}`
  );
  outDoc.setProducer('BT Document Security Engine');

  const copiedPages = await outDoc.copyPages(srcDoc, srcDoc.getPageIndices());
  for (let i = 0; i < copiedPages.length; i++) {
    const page = copiedPages[i];
    const { width, height } = page.getSize();

    page.drawRectangle({
      x: 0,
      y: height - 22,
      width,
      height: 22,
      color: rgb(0.06, 0.09, 0.16),
    });
    page.drawText(
      sanitizePdfText(
        `PROTECTED PDF · KEY SHA-256: ${hashHex.slice(0, 12)} · PERMISSIONS: ${
          options.permissions.allowPrinting ? 'PRINT-OK' : 'NO-PRINT'
        } / ${options.permissions.allowCopying ? 'COPY-OK' : 'NO-COPY'}`
      ),
      {
        x: 18,
        y: height - 15,
        size: 7.5,
        font: fontBold,
        color: rgb(0.95, 0.78, 0.25),
      }
    );

    if (options.watermarkText.trim()) {
      page.drawText(sanitizePdfText(options.watermarkText.trim().toUpperCase()), {
        x: width * 0.18,
        y: height * 0.35,
        size: 36,
        font: fontBold,
        color: rgb(0.85, 0.18, 0.22),
        rotate: degrees(35),
        opacity: 0.16,
      });
    }

    outDoc.addPage(page);
  }

  return await outDoc.save();
}
