import React, { useRef, useState, useEffect } from 'react';
import {
  Maximize2,
  Square,
  RectangleHorizontal,
  RectangleVertical,
  RotateCcw,
  Undo2,
  Eye,
} from 'lucide-react';

export interface CropRect {
  left: number;   // 0..1
  top: number;    // 0..1
  width: number;  // 0..1
  height: number; // 0..1
}

interface PhotoStylePdfCropperProps {
  previewUrl: string;
  pageWidthPt: number;
  pageHeightPt: number;
  crop: CropRect;
  canRevert: boolean;
  onChange: (next: CropRect) => void;
  onCommitStart?: () => void;
  onRevert: () => void;
  onReset: () => void;
}

type DragHandle =
  | 'move'
  | 'nw'
  | 'ne'
  | 'sw'
  | 'se'
  | 'n'
  | 's'
  | 'w'
  | 'e'
  | null;

export const PhotoStylePdfCropper: React.FC<PhotoStylePdfCropperProps> = ({
  previewUrl,
  pageWidthPt,
  pageHeightPt,
  crop,
  canRevert,
  onChange,
  onCommitStart,
  onRevert,
  onReset,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const livePreviewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sourceImageRef = useRef<HTMLImageElement | null>(null);
  const [imageLoadedTick, setImageLoadedTick] = useState(0);

  const [activeHandle, setActiveHandle] = useState<DragHandle>(null);
  const [dragStart, setDragStart] = useState<{
    x: number;
    y: number;
    initialCrop: CropRect;
  } | null>(null);

  // Load previewUrl into an offscreen Image object for 60fps Live Crop Preview rendering
  useEffect(() => {
    if (!previewUrl) return;
    const img = new Image();
    img.onload = () => {
      sourceImageRef.current = img;
      setImageLoadedTick((t) => t + 1);
    };
    img.src = previewUrl;
  }, [previewUrl]);

  // Draw the live cropped region onto the Live Crop Preview canvas
  useEffect(() => {
    const canvas = livePreviewCanvasRef.current;
    const img = sourceImageRef.current;
    if (!canvas || !img || img.naturalWidth === 0 || img.naturalHeight === 0) return;

    const sx = Math.max(0, crop.left * img.naturalWidth);
    const sy = Math.max(0, crop.top * img.naturalHeight);
    const sw = Math.max(1, Math.min(img.naturalWidth - sx, crop.width * img.naturalWidth));
    const sh = Math.max(1, Math.min(img.naturalHeight - sy, crop.height * img.naturalHeight));

    const maxPreviewDim = 260;
    const scale = Math.min(maxPreviewDim / sw, maxPreviewDim / sh, 1.5);
    const dw = Math.max(24, Math.round(sw * scale));
    const dh = Math.max(24, Math.round(sh * scale));

    canvas.width = dw;
    canvas.height = dh;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, dw, dh);
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, dw, dh);
  }, [crop, imageLoadedTick]);

  const getPointerNorm = (clientX: number, clientY: number) => {
    const el = containerRef.current;
    if (!el) return { x: 0, y: 0 };
    const rect = el.getBoundingClientRect();
    return {
      x: (clientX - rect.left) / rect.width,
      y: (clientY - rect.top) / rect.height,
    };
  };

  const beginPointerDrag = (
    handle: DragHandle,
    e: React.PointerEvent<HTMLDivElement>
  ) => {
    e.stopPropagation();
    e.preventDefault();
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // ignore if synthetic event
    }
    onCommitStart?.();
    const pt = getPointerNorm(e.clientX, e.clientY);
    setActiveHandle(handle);
    setDragStart({ x: pt.x, y: pt.y, initialCrop: { ...crop } });
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!activeHandle || !dragStart) return;
    e.stopPropagation();
    const pt = getPointerNorm(e.clientX, e.clientY);
    const dx = pt.x - dragStart.x;
    const dy = pt.y - dragStart.y;
    const init = dragStart.initialCrop;
    const minSize = 0.08;

    if (activeHandle === 'move') {
      const nextLeft = Math.max(0, Math.min(1 - init.width, init.left + dx));
      const nextTop = Math.max(0, Math.min(1 - init.height, init.top + dy));
      onChange({ ...init, left: nextLeft, top: nextTop });
      return;
    }

    let left = init.left;
    let top = init.top;
    let right = init.left + init.width;
    let bottom = init.top + init.height;

    if (activeHandle.includes('w')) {
      left = Math.max(0, Math.min(right - minSize, init.left + dx));
    }
    if (activeHandle.includes('e')) {
      right = Math.min(1, Math.max(left + minSize, init.left + init.width + dx));
    }
    if (activeHandle.includes('n')) {
      top = Math.max(0, Math.min(bottom - minSize, init.top + dy));
    }
    if (activeHandle.includes('s')) {
      bottom = Math.min(1, Math.max(top + minSize, init.top + init.height + dy));
    }

    onChange({
      left,
      top,
      width: right - left,
      height: bottom - top,
    });
  };

  const endPointerDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!activeHandle) return;
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    setActiveHandle(null);
    setDragStart(null);
  };

  const applyPreset = (preset: 'trim-margins' | 'top-half' | 'square') => {
    onCommitStart?.();
    if (preset === 'trim-margins') {
      onChange({ left: 0.08, top: 0.08, width: 0.84, height: 0.84 });
    } else if (preset === 'top-half') {
      onChange({ left: 0.05, top: 0.05, width: 0.9, height: 0.48 });
    } else if (preset === 'square') {
      onChange({ left: 0.12, top: 0.18, width: 0.76, height: 0.54 });
    }
  };

  const outWidthPt = Math.round(crop.width * pageWidthPt);
  const outHeightPt = Math.round(crop.height * pageHeightPt);
  const outWidthMm = Math.round(outWidthPt * 0.352778);
  const outHeightMm = Math.round(outHeightPt * 0.352778);

  return (
    <div className="space-y-4">
      {/* Toolbar: Presets + Revert & Reset */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => applyPreset('trim-margins')}
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RectangleVertical className="w-3.5 h-3.5" />
            <span>Trim Margins (8%)</span>
          </button>
          <button
            type="button"
            onClick={() => applyPreset('top-half')}
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RectangleHorizontal className="w-3.5 h-3.5" />
            <span>Header / Top Half</span>
          </button>
          <button
            type="button"
            onClick={() => applyPreset('square')}
            className="min-h-[36px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Square className="w-3.5 h-3.5" />
            <span>Center Focus</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onRevert}
            disabled={!canRevert}
            className="min-h-[36px] px-3 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-xs font-semibold text-amber-700 dark:text-amber-300 hover:bg-amber-100 disabled:opacity-40 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Undo2 className="w-3.5 h-3.5" />
            <span>Revert</span>
          </button>
          <button
            type="button"
            onClick={onReset}
            className="min-h-[36px] px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Full</span>
          </button>
        </div>
      </div>

      {/* Split Workspace: Interactive Cropper + Live Cropped Output Preview */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
        {/* Left: Interactive Touch/Pointer Crop Canvas */}
        <div className="md:col-span-7 space-y-2">
          <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
            Drag box to move · Drag any of 4 corners or 4 edges to resize
          </div>

          <div
            ref={containerRef}
            onPointerMove={handlePointerMove}
            onPointerUp={endPointerDrag}
            onPointerCancel={endPointerDrag}
            className="relative mx-auto max-w-[360px] select-none rounded-xl overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-900 shadow-inner touch-none"
          >
            <img
              src={previewUrl}
              alt="PDF Page Preview to Crop"
              referrerPolicy="no-referrer"
              className="w-full h-auto block pointer-events-none opacity-45"
            />

            {/* Highlighted Crop Window with Rule-of-Thirds Grid */}
            <div
              onPointerDown={(e) => beginPointerDrag('move', e)}
              onPointerMove={handlePointerMove}
              onPointerUp={endPointerDrag}
              onPointerCancel={endPointerDrag}
              style={{
                left: `${crop.left * 100}%`,
                top: `${crop.top * 100}%`,
                width: `${crop.width * 100}%`,
                height: `${crop.height * 100}%`,
              }}
              className="absolute border-2 border-blue-500 bg-white/15 backdrop-contrast-125 cursor-move shadow-[0_0_0_9999px_rgba(15,23,42,0.58)] touch-none"
            >
              {/* Rule of thirds lines */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                <div className="border-r border-b border-white/40" />
                <div className="border-r border-b border-white/40" />
                <div className="border-b border-white/40" />
                <div className="border-r border-b border-white/40" />
                <div className="border-r border-b border-white/40" />
                <div className="border-b border-white/40" />
                <div className="border-r border-white/40" />
                <div className="border-r border-white/40" />
                <div />
              </div>

              {/* 4 CORNER HANDLES (with 40px touch hit area) */}
              <div
                onPointerDown={(e) => beginPointerDrag('nw', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Top-Left Corner"
                className="absolute -top-5 -left-5 w-10 h-10 flex items-center justify-center cursor-nwse-resize touch-none z-20"
              >
                <span className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('ne', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Top-Right Corner"
                className="absolute -top-5 -right-5 w-10 h-10 flex items-center justify-center cursor-nesw-resize touch-none z-20"
              >
                <span className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('sw', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Bottom-Left Corner"
                className="absolute -bottom-5 -left-5 w-10 h-10 flex items-center justify-center cursor-nesw-resize touch-none z-20"
              >
                <span className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('se', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Bottom-Right Corner"
                className="absolute -bottom-5 -right-5 w-10 h-10 flex items-center justify-center cursor-nwse-resize touch-none z-20"
              >
                <span className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow" />
              </div>

              {/* 4 EDGE HANDLES (Top, Bottom, Left, Right) */}
              <div
                onPointerDown={(e) => beginPointerDrag('n', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Top Edge"
                className="absolute -top-4 left-1/2 -translate-x-1/2 w-14 h-8 flex items-center justify-center cursor-ns-resize touch-none z-10"
              >
                <span className="w-8 h-2 rounded-full bg-white border border-blue-600 shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('s', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Bottom Edge"
                className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-14 h-8 flex items-center justify-center cursor-ns-resize touch-none z-10"
              >
                <span className="w-8 h-2 rounded-full bg-white border border-blue-600 shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('w', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Left Edge"
                className="absolute top-1/2 -left-4 -translate-y-1/2 w-8 h-14 flex items-center justify-center cursor-ew-resize touch-none z-10"
              >
                <span className="w-2 h-8 rounded-full bg-white border border-blue-600 shadow" />
              </div>
              <div
                onPointerDown={(e) => beginPointerDrag('e', e)}
                onPointerMove={handlePointerMove}
                onPointerUp={endPointerDrag}
                title="Resize Right Edge"
                className="absolute top-1/2 -right-4 -translate-y-1/2 w-8 h-14 flex items-center justify-center cursor-ew-resize touch-none z-10"
              >
                <span className="w-2 h-8 rounded-full bg-white border border-blue-600 shadow" />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Live Crop Preview Panel */}
        <div className="md:col-span-5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 p-3.5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-100">
              <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Live Crop Preview</span>
            </div>
            <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 tabular-nums">
              {outWidthPt} × {outHeightPt} pt
            </span>
          </div>

          <div className="flex items-center justify-center min-h-[220px] rounded-lg bg-slate-200/70 dark:bg-slate-900/70 p-3 border border-slate-200 dark:border-slate-800">
            <canvas
              ref={livePreviewCanvasRef}
              className="max-w-full max-h-[240px] rounded shadow-md border border-slate-300 dark:border-slate-700 bg-white"
            />
          </div>

          <div className="space-y-1 text-[11px] font-mono text-slate-600 dark:text-slate-400 tabular-nums">
            <div className="flex items-center justify-between">
              <span>Origin (X, Y):</span>
              <span>
                {Math.round(crop.left * 100)}%, {Math.round(crop.top * 100)}%
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>Area Retained:</span>
              <span>
                {Math.round(crop.width * 100)}% × {Math.round(crop.height * 100)}%
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>Export Page Size:</span>
              <span>
                {outWidthMm} × {outHeightMm} mm
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
