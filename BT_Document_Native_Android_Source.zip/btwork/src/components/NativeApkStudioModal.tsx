import React, { useState } from 'react';
import {
  Download,
  Code2,
  CheckCircle2,
  Terminal,
  Smartphone,
  Copy,
  Check,
  FolderGit2,
} from 'lucide-react';
import {
  DEFAULT_APK_CONFIG,
  ApkProjectConfig,
  getAndroidFiles,
  generateAndroidStudioZip,
} from '../services/apkProjectGenerator';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const NativeApkStudioModal: React.FC<{
  onClose?: () => void;
  isEmbedded?: boolean;
}> = ({ onClose, isEmbedded = false }) => {
  const [config, setConfig] = useState<ApkProjectConfig>(DEFAULT_APK_CONFIG);
  const files = getAndroidFiles(config);
  const filePaths = Object.keys(files);
  const [selectedFile, setSelectedFile] = useState<string>(
    filePaths.find((p) => p.endsWith('MainActivity.kt')) || filePaths[0]
  );
  const [isDownloading, setIsDownloading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { isInstallable, install } = usePWAInstall();

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      const zipBytes = await generateAndroidStudioZip(config);
      const blob = new Blob([zipBytes as unknown as BlobPart], { type: 'application/zip' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `BT-Document-Android-APK-Source-v${config.versionName}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(files[selectedFile] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className={isEmbedded ? 'space-y-6' : 'p-6 space-y-6'}>
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Android APK Package & Native Kotlin Source Studio
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Install BT Document directly onto your Android device via WebAPK or export the complete Kotlin + Jetpack Compose Android Studio project to compile a signed native <code>.apk</code>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {isInstallable && (
            <button
              onClick={install}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition flex items-center gap-2 whitespace-nowrap shrink-0"
            >
              <Smartphone className="w-4 h-4 shrink-0" />
              <span>Install Direct on Android</span>
            </button>
          )}
          <button
            onClick={handleDownloadZip}
            disabled={isDownloading}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition flex items-center gap-2 shadow-sm whitespace-nowrap shrink-0"
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>
              {isDownloading
                ? 'Bundling Android Project...'
                : 'Download Android Studio Project (.ZIP)'}
            </span>
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition whitespace-nowrap shrink-0"
            >
              Back to Workspace
            </button>
          )}
        </div>
      </div>

      {/* Configuration Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
            Android Application Name
          </label>
          <input
            type="text"
            value={config.appName}
            onChange={(e) => setConfig({ ...config, appName: e.target.value })}
            className="mt-1.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-sm font-medium text-slate-900 dark:text-white"
          />
        </div>
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
            Application ID (Package Name)
          </label>
          <input
            type="text"
            value={config.packageName}
            onChange={(e) => setConfig({ ...config, packageName: e.target.value })}
            className="mt-1.5 w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-sm font-mono text-slate-900 dark:text-white"
          />
        </div>
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
            Version Name & Code
          </label>
          <div className="mt-1.5 flex items-center gap-2">
            <input
              type="text"
              value={config.versionName}
              onChange={(e) => setConfig({ ...config, versionName: e.target.value })}
              className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-sm font-mono text-slate-900 dark:text-white tabular-nums"
            />
            <span className="text-xs font-mono text-slate-500 tabular-nums shrink-0">
              Build #{config.versionCode}
            </span>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <label className="block text-xs font-medium text-slate-500 dark:text-slate-400">
            Android SDK Target
          </label>
          <div className="mt-2 flex items-center gap-2 text-sm font-medium text-slate-900 dark:text-white tabular-nums">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Min SDK {config.minSdk} · Target SDK {config.targetSdk}</span>
          </div>
        </div>
      </div>

      {/* Code Browser & Build Steps */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-4">
          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-800">
              <FolderGit2 className="w-4 h-4 text-blue-600" />
              <span>Android Studio Project Tree</span>
            </div>
            <div className="mt-3 space-y-1">
              {filePaths.map((path) => (
                <button
                  key={path}
                  onClick={() => setSelectedFile(path)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition flex items-center justify-between ${
                    selectedFile === path
                      ? 'bg-blue-600 text-white font-medium'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span className="truncate">{path}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-900 dark:text-white">
              <Terminal className="w-4 h-4 text-blue-600" />
              <span>Compile Signed APK Command</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Unzip the downloaded project and run the Gradle wrapper in Android Studio Terminal:
            </p>
            <pre className="p-3 rounded-lg bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto">
              ./gradlew assembleDebug
            </pre>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Output location: <code>app/build/outputs/apk/debug/app-debug.apk</code>
            </p>
          </div>
        </div>

        <div className="lg:col-span-8 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
              <Code2 className="w-4 h-4 text-blue-400" />
              <span>{selectedFile}</span>
            </div>
            <button
              onClick={handleCopyCode}
              className="min-h-[32px] px-3 py-1 rounded-md bg-slate-800 text-slate-200 text-xs font-medium hover:bg-slate-700 transition flex items-center gap-1.5"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy File</span>
                </>
              )}
            </button>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-[480px] leading-relaxed">
            {files[selectedFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};
