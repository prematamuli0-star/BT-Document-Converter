import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  onOpenApkStudio?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onOpenApkStudio }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="min-h-[40px] flex items-center gap-2 rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-sm hover:bg-blue-700 active:scale-[0.98] transition whitespace-nowrap shrink-0"
      >
        <Download className="w-4 h-4 shrink-0" />
        <span>Install Android App</span>
      </button>
    );
  }

  return (
    <>
      <button
        onClick={() => setShowGuide(true)}
        className="min-h-[40px] flex items-center gap-2 rounded-lg bg-slate-900 dark:bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-slate-800 dark:hover:bg-blue-500 active:scale-[0.98] transition whitespace-nowrap shrink-0"
      >
        <Smartphone className="w-4 h-4 shrink-0" />
        <span>{isIOS ? 'Install on iOS' : 'Get Android APK'}</span>
      </button>

      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {isIOS ? 'Install BT Document on iOS' : 'Install BT Document on Android'}
              </h3>
              <button
                onClick={() => setShowGuide(false)}
                className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isIOS ? (
              <div className="mt-4 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                <p>1. Tap the <strong>Share</strong> button in your Safari toolbar.</p>
                <p>2. Scroll down and select <strong>Add to Home Screen</strong>.</p>
                <p>3. Launch <strong>BT Document</strong> from your home screen in standalone app mode.</p>
              </div>
            ) : (
              <div className="mt-4 space-y-3 text-sm text-slate-600 dark:text-slate-300">
                <p>
                  You can install <strong>BT Document</strong> directly on your Android phone or download the complete native Kotlin Jetpack Compose Android Studio project to build a signed <code>.apk</code>:
                </p>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/70 space-y-1.5 text-xs">
                  <p className="font-semibold text-slate-900 dark:text-white">Option 1: Instant Android WebAPK</p>
                  <p>Open Chrome menu (⋮) on Android and tap <strong>Install app</strong> or <strong>Add to Home screen</strong>.</p>
                </div>
                <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/70 space-y-1.5 text-xs">
                  <p className="font-semibold text-blue-900 dark:text-blue-200">Option 2: Native Android Studio APK Project</p>
                  <p>Download the ready-to-compile Kotlin + Material 3 Android Studio project zip and build <code>app-debug.apk</code>.</p>
                </div>
              </div>
            )}

            <div className="mt-5 flex items-center justify-end gap-2">
              {onOpenApkStudio && (
                <button
                  onClick={() => {
                    setShowGuide(false);
                    onOpenApkStudio();
                  }}
                  className="min-h-[40px] px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition whitespace-nowrap shrink-0"
                >
                  Open Native APK Studio
                </button>
              )}
              <button
                onClick={() => setShowGuide(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition whitespace-nowrap shrink-0"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
