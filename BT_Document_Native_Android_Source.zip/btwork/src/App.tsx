import React, { useState, useEffect } from 'react';
import {
  FileText,
  Table,
  Crop,
  Scissors,
  Layers,
  PenTool,
  FileType2,
  FileCheck2,
  Lock,
  Clock,
  Download,
  Smartphone,
  Moon,
  Sun,
  Upload,
  CheckCircle2,
  Sparkles,
  Trash2,
  ArrowUp,
  ArrowDown,
  Eye,
  Plus,
  FolderOpen,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  FolderInput,
} from 'lucide-react';
import {
  ToolId,
  RecentDocumentItem,
  formatBytes,
  uint8ArrayToDataUrl,
  dataUrlToUint8Array,
  saveBytesWithLocationPicker,
  createSamplePdfBytes,
  renderPdfPagePreview,
  convertTextToPdf,
  parseExcelFile,
  convertTableToPdf,
  cropPdfPages,
  parsePageRange,
  splitPdfByPages,
  mergePdfFiles,
  signPdfDocument,
  extractTextFromPdf,
  convertPdfToWordDocx,
  extractTextFromDocx,
  protectPdfWithPassword,
} from './services/pdfEngine';
import { PhotoStylePdfCropper, CropRect } from './components/PhotoStylePdfCropper';
import { SignaturePad } from './components/SignaturePad';
import { PWAInstallButton } from './components/PWAInstallButton';
import { NativeApkStudioModal } from './components/NativeApkStudioModal';

interface ToolDefinition {
  id: ToolId;
  number: string;
  title: string;
  shortTitle: string;
  description: string;
  inputFormat: string;
  outputFormat: string;
  icon: React.ComponentType<{ className?: string }>;
  accentClass: string;
}

const TOOLS: ToolDefinition[] = [
  {
    id: 'text-to-pdf',
    number: '01',
    title: 'Text to PDF',
    shortTitle: 'Text → PDF',
    description: 'Convert plain text, notes, or markdown into paginated A4 or Letter PDF documents.',
    inputFormat: 'TXT / Notes',
    outputFormat: 'PDF 1.7',
    icon: FileText,
    accentClass: 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60',
  },
  {
    id: 'excel-to-pdf',
    number: '02',
    title: 'Excel to PDF',
    shortTitle: 'Excel → PDF',
    description: 'Transform .xlsx, .xls, or .csv spreadsheets into structured tabular PDF reports.',
    inputFormat: 'XLSX / CSV',
    outputFormat: 'PDF Table',
    icon: Table,
    accentClass: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60',
  },
  {
    id: 'pdf-crop',
    number: '03',
    title: 'PDF Crop (Photo Style)',
    shortTitle: 'PDF Crop',
    description: 'Trim page margins or focus areas using a touch-friendly photo cropper with rule-of-thirds.',
    inputFormat: 'PDF',
    outputFormat: 'Cropped PDF',
    icon: Crop,
    accentClass: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60',
  },
  {
    id: 'pdf-split',
    number: '04',
    title: 'PDF Page Split',
    shortTitle: 'Page Split',
    description: 'Extract custom page ranges into a standalone PDF or a ZIP bundle of single pages.',
    inputFormat: 'PDF',
    outputFormat: 'PDF / ZIP',
    icon: Scissors,
    accentClass: 'text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60',
  },
  {
    id: 'pdf-merge',
    number: '05',
    title: 'PDF Merge',
    shortTitle: 'PDF Merge',
    description: 'Combine multiple PDF documents in custom order while preserving vector fidelity.',
    inputFormat: 'Multiple PDFs',
    outputFormat: 'Merged PDF',
    icon: Layers,
    accentClass: 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60',
  },
  {
    id: 'sign-pdf',
    number: '06',
    title: 'Sign PDF',
    shortTitle: 'Sign PDF',
    description: 'Draw a wet-ink signature on screen and stamp it onto any page with position controls.',
    inputFormat: 'PDF + Ink',
    outputFormat: 'Signed PDF',
    icon: PenTool,
    accentClass: 'text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60',
  },
  {
    id: 'pdf-to-word',
    number: '07',
    title: 'PDF to Word',
    shortTitle: 'PDF → Word',
    description: 'Extract text and headings from any PDF file into an editable Microsoft Word (.docx) file.',
    inputFormat: 'PDF',
    outputFormat: 'DOCX',
    icon: FileType2,
    accentClass: 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60',
  },
  {
    id: 'word-to-pdf',
    number: '08',
    title: 'Word to PDF',
    shortTitle: 'Word → PDF',
    description: 'Convert Microsoft Word (.docx) documents into clean, printable PDF files.',
    inputFormat: 'DOCX',
    outputFormat: 'PDF 1.7',
    icon: FileCheck2,
    accentClass: 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60',
  },
  {
    id: 'pdf-password',
    number: '09',
    title: 'PDF Password Protection',
    shortTitle: 'Password Lock',
    description: 'Apply user & owner passwords, SHA-256 security headers, watermarks, and print permissions.',
    inputFormat: 'PDF',
    outputFormat: 'Secured PDF',
    icon: Lock,
    accentClass: 'text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60',
  },
];

const RECENT_STORAGE_KEY = 'bt_document_recent_files_v1';

const DEFAULT_EXCEL_ROWS: string[][] = [
  ['Item Code', 'Description', 'Department', 'Qty', 'Unit Cost', 'Total USD'],
  ['BTD-101', 'Android Material 3 UI License', 'Mobile Eng', '12', '$120.00', '$1,440.00'],
  ['BTD-204', 'PDF Optical Crop Module', 'Core Imaging', '8', '$250.00', '$2,000.00'],
  ['BTD-309', 'Office OpenXML Word Parser', 'Doc Engine', '15', '$95.00', '$1,425.00'],
  ['BTD-412', 'AES-256 Security Envelope', 'Cryptography', '5', '$310.00', '$1,550.00'],
  ['BTD-518', 'Batch Page Split & Merge', 'Automation', '20', '$85.00', '$1,700.00'],
];

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [activeNav, setActiveNav] = useState<'tools' | 'recent' | 'apk'>('tools');
  const [selectedTool, setSelectedTool] = useState<ToolId>('text-to-pdf');
  const [recentFiles, setRecentFiles] = useState<RecentDocumentItem[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastOutput, setLastOutput] = useState<RecentDocumentItem | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>('');

  // Shared original PDF state (strictly read-only once loaded; never overwritten by exports)
  const [activePdfBytes, setActivePdfBytes] = useState<Uint8Array | null>(null);
  const [activePdfName, setActivePdfName] = useState<string>('BT_Master_Service_Agreement.pdf');
  const [pdfPreviewUrl, setPdfPreviewUrl] = useState<string>('');
  const [pdfTotalPages, setPdfTotalPages] = useState<number>(3);
  const [previewPageNum, setPreviewPageNum] = useState<number>(1);
  const [pdfPageWidthPt, setPdfPageWidthPt] = useState<number>(595.28);
  const [pdfPageHeightPt, setPdfPageHeightPt] = useState<number>(841.89);

  // Tool 1: Text to PDF state
  const [textTitle, setTextTitle] = useState<string>('Executive Project Brief — BT Document');
  const [textBody, setTextBody] = useState<string>(
    `1. PROJECT SUMMARY\nBT Document is an all-in-one Android Material Design 3 application engineered for high-speed offline document conversion and security.\n\n2. NINE CORE CAPABILITIES\n- Text to PDF with automatic line wrapping and A4/Letter pagination.\n- Excel to PDF with zebra table formatting and landscape/portrait layout.\n- Photo-style PDF Crop with interactive 4-corner + 4-edge handles & live preview.\n- PDF Page Split into single PDFs or multi-file ZIP archives.\n- PDF Merge for combining multiple reports in custom sequence.\n- Wet-Ink Sign PDF with live touch signature canvas.\n- PDF to Word (.docx) and Word (.docx) to PDF bidirectional engine.\n- Password Protection & Security Watermarking.`
  );
  const [textFontSize, setTextFontSize] = useState<number>(11);
  const [textPageSize, setTextPageSize] = useState<'A4' | 'LETTER'>('A4');

  // Tool 2: Excel to PDF state
  const [excelTitle, setExcelTitle] = useState<string>('Q4 Enterprise Procurement Ledger');
  const [excelRows, setExcelRows] = useState<string[][]>(DEFAULT_EXCEL_ROWS);
  const [excelOrientation, setExcelOrientation] = useState<'portrait' | 'landscape'>('landscape');
  const [excelSheetNames, setExcelSheetNames] = useState<string[]>([]);
  const [excelSelectedSheet, setExcelSelectedSheet] = useState<number>(0);
  const [excelBuffer, setExcelBuffer] = useState<ArrayBuffer | null>(null);

  // Tool 3: PDF Crop state
  const [cropRect, setCropRect] = useState<CropRect>({
    left: 0.06,
    top: 0.06,
    width: 0.88,
    height: 0.88,
  });
  const [cropHistory, setCropHistory] = useState<CropRect[]>([]);
  const [cropPageScope, setCropPageScope] = useState<'all' | 'current' | 'selected'>('all');
  const [cropSelectedPages, setCropSelectedPages] = useState<number[]>([1]);
  const [cropOutputName, setCropOutputName] = useState<string>('Cropped_BT_Master_Service_Agreement.pdf');
  const [croppedResultPreviewUrl, setCroppedResultPreviewUrl] = useState<string>('');

  // Tool 4: PDF Split state
  const [splitRangeStr, setSplitRangeStr] = useState<string>('1-2');
  const [splitMode, setSplitMode] = useState<'single-extracted-pdf' | 'zip-individual-pages'>(
    'single-extracted-pdf'
  );

  // Tool 5: PDF Merge state
  const [mergeList, setMergeList] = useState<
    Array<{ id: string; name: string; bytes: Uint8Array; size: number }>
  >([]);

  // Tool 6: Sign PDF state
  const [signaturePng, setSignaturePng] = useState<string | null>(null);
  const [signerName, setSignerName] = useState<string>('Prema Tamuli');
  const [sigPosPercent, setSigPosPercent] = useState<{ x: number; y: number }>({
    x: 0.52,
    y: 0.72,
  });

  // Tool 7: PDF to Word state
  const [extractedPdfPages, setExtractedPdfPages] = useState<string[]>([]);

  // Tool 8: Word to PDF state
  const [wordTitle, setWordTitle] = useState<string>('Converted Word Document');
  const [wordExtractedText, setWordExtractedText] = useState<string>(
    `BT DOCUMENT — WORD TO PDF CONVERSION PIPELINE\n\nUpload any Microsoft Word (.docx) file above or edit this document body directly before exporting to a high-contrast, print-ready A4 PDF.\n\nKey Highlights:\n• Preserves paragraph spacing and section headers.\n• Generates clean ISO-compliant PDF 1.7 output.\n• Automatically saves to your Recent Used drawer for instant retrieval.`
  );

  // Tool 9: PDF Password state
  const [userPassword, setUserPassword] = useState<string>('BT2026#Secure');
  const [ownerPassword, setOwnerPassword] = useState<string>('Admin#BT2026');
  const [securityWatermark, setSecurityWatermark] = useState<string>('CONFIDENTIAL · BT DOCUMENT');
  const [allowPrinting, setAllowPrinting] = useState<boolean>(true);
  const [allowCopying, setAllowCopying] = useState<boolean>(false);

  // Theme Sync
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  // Load Recent Files & Initial Sample PDFs
  useEffect(() => {
    try {
      const saved = localStorage.getItem(RECENT_STORAGE_KEY);
      if (saved) {
        setRecentFiles(JSON.parse(saved));
      }
    } catch {
      // ignore storage errors
    }

    (async () => {
      const mainBytes = await createSamplePdfBytes('contract');
      const annexBytes = await createSamplePdfBytes('appendix');
      setActivePdfBytes(mainBytes);
      setMergeList([
        {
          id: 'sample-1',
          name: '01_Master_Service_Agreement.pdf',
          bytes: mainBytes,
          size: mainBytes.byteLength,
        },
        {
          id: 'sample-2',
          name: '02_Annex_B_Audit_Summary.pdf',
          bytes: annexBytes,
          size: annexBytes.byteLength,
        },
      ]);

      const extracted = await extractTextFromPdf(mainBytes);
      setExtractedPdfPages(extracted.pageTexts);
    })();
  }, []);

  // Re-render original PDF page preview whenever activePdfBytes or previewPageNum changes
  useEffect(() => {
    if (!activePdfBytes) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await renderPdfPagePreview(activePdfBytes, previewPageNum, 1.25);
        if (!cancelled) {
          setPdfPreviewUrl(res.dataUrl);
          setPdfTotalPages(res.totalPages);
          setPdfPageWidthPt(res.pageWidthPt);
          setPdfPageHeightPt(res.pageHeightPt);
        }
      } catch {
        // Fallback if preview fails
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activePdfBytes, previewPageNum]);

  const recordRecentOutput = (item: Omit<RecentDocumentItem, 'id' | 'createdAt'>) => {
    const fullItem: RecentDocumentItem = {
      ...item,
      id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setLastOutput(fullItem);
    setRecentFiles((prev) => {
      const next = [fullItem, ...prev].slice(0, 18);
      try {
        localStorage.setItem(RECENT_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // quota fallback
      }
      return next;
    });
    return fullItem;
  };

  const triggerDownload = async (item: RecentDocumentItem, useLocationPicker = false) => {
    if (useLocationPicker) {
      const bytes = dataUrlToUint8Array(item.dataUrl);
      const res = await saveBytesWithLocationPicker({
        bytes,
        fileName: item.fileName,
        mimeType: item.mimeType,
      });
      if (res.method === 'picker') {
        setStatusMessage(`Saved "${res.savedName}" to your chosen folder.`);
      } else if (res.method === 'download') {
        setStatusMessage(`Downloaded "${res.savedName}" to your Downloads folder.`);
      }
      return;
    }

    const a = document.createElement('a');
    a.href = item.dataUrl;
    a.download = item.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleUploadPdf = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = await file.arrayBuffer();
    const bytes = new Uint8Array(buf);
    setActivePdfBytes(bytes);
    setActivePdfName(file.name);
    setCropOutputName(`Cropped_${file.name.replace(/\.pdf$/i, '')}.pdf`);
    setCroppedResultPreviewUrl('');
    setPreviewPageNum(1);
    setCropSelectedPages([1]);
    const extracted = await extractTextFromPdf(bytes);
    setExtractedPdfPages(extracted.pageTexts);
    setStatusMessage(`Loaded original "${file.name}" (${extracted.totalPages} pages, read-only).`);
  };

  const handleUploadExcel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = await file.arrayBuffer();
    setExcelBuffer(buf);
    setExcelSelectedSheet(0);
    const parsed = parseExcelFile(buf, 0);
    setExcelSheetNames(parsed.sheetNames);
    if (parsed.rows.length > 0) {
      setExcelRows(parsed.rows);
      setExcelTitle(file.name.replace(/\.[^.]+$/, ''));
      setStatusMessage(`Parsed ${parsed.rows.length} rows from "${file.name}"`);
    }
  };

  const handleUploadWord = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = await file.arrayBuffer();
    const text = await extractTextFromDocx(buf);
    setWordTitle(file.name.replace(/\.[^.]+$/, ''));
    setWordExtractedText(text || 'No text content found in Word file.');
    setStatusMessage(`Extracted text from "${file.name}"`);
  };

  const handleAddMergeFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const additions: Array<{ id: string; name: string; bytes: Uint8Array; size: number }> = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const buf = await f.arrayBuffer();
      const bytes = new Uint8Array(buf);
      additions.push({
        id: `merge-${Date.now()}-${i}`,
        name: f.name,
        bytes,
        size: bytes.byteLength,
      });
    }
    setMergeList((prev) => [...prev, ...additions]);
  };

  const executeActiveTool = async () => {
    setIsProcessing(true);
    setStatusMessage('');
    try {
      if (selectedTool === 'text-to-pdf') {
        const bytes = await convertTextToPdf({
          title: textTitle,
          content: textBody,
          fontSize: textFontSize,
          pageSize: textPageSize,
          margin: 48,
        });
        const cleanName = `${(textTitle || 'Text_Document').replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'text-to-pdf',
          toolName: 'Text to PDF',
          sizeBytes: bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(bytes, 'application/pdf'),
          metaSummary: `${textPageSize} · ${textFontSize}pt`,
        });
        setStatusMessage('Text converted to PDF and saved to Recent Used.');
      } else if (selectedTool === 'excel-to-pdf') {
        const bytes = await convertTableToPdf({
          title: excelTitle,
          rows: excelRows,
          orientation: excelOrientation,
        });
        const cleanName = `${(excelTitle || 'Spreadsheet').replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'excel-to-pdf',
          toolName: 'Excel to PDF',
          sizeBytes: bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(bytes, 'application/pdf'),
          metaSummary: `${excelRows.length} rows · ${excelOrientation}`,
        });
        setStatusMessage('Excel spreadsheet exported to PDF.');
      } else if (selectedTool === 'pdf-crop') {
        if (!activePdfBytes) return;
        const targetPages =
          cropPageScope === 'all'
            ? Array.from({ length: pdfTotalPages }, (_, i) => i + 1)
            : cropPageScope === 'current'
            ? [previewPageNum]
            : cropSelectedPages.length > 0
            ? cropSelectedPages
            : [previewPageNum];

        const cropRes = await cropPdfPages({
          pdfBytes: activePdfBytes,
          cropRectPercent: cropRect,
          targetPageNumbers: targetPages,
        });

        // Never overwrite activePdfBytes — save cropped PDF as a completely separate output
        const sanitizedBase = (cropOutputName.trim() || `Cropped_${activePdfName}`)
          .replace(/\.pdf$/i, '')
          .replace(/[\\/:*?"<>|]/g, '_');
        const cleanName = `${sanitizedBase}.pdf`;

        // Render preview of the exported cropped PDF (first cropped page)
        const croppedPreview = await renderPdfPagePreview(
          cropRes.bytes,
          targetPages[0] || 1,
          1.0
        );
        setCroppedResultPreviewUrl(croppedPreview.dataUrl);

        recordRecentOutput({
          fileName: cleanName,
          toolId: 'pdf-crop',
          toolName: 'PDF Crop',
          sizeBytes: cropRes.bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(cropRes.bytes, 'application/pdf'),
          metaSummary: `${targetPages.length}/${cropRes.totalPages} page(s) · ${
            cropRes.croppedDimensionsPt
              ? `${cropRes.croppedDimensionsPt.width}×${cropRes.croppedDimensionsPt.height}pt`
              : 'Cropped'
          }`,
        });
        setStatusMessage(
          `Permanently cropped ${cropRes.croppedPageCount} page(s) into "${cleanName}". Original PDF untouched.`
        );
      } else if (selectedTool === 'pdf-split') {
        if (!activePdfBytes) return;
        const pages = parsePageRange(splitRangeStr, pdfTotalPages);
        if (pages.length === 0) {
          setStatusMessage('Enter a valid page range between 1 and ' + pdfTotalPages);
          return;
        }
        const baseName = activePdfName.replace(/\.pdf$/i, '');
        const res = await splitPdfByPages({
          pdfBytes: activePdfBytes,
          pageNumbers: pages,
          mode: splitMode,
          baseName,
        });
        const cleanName = `${baseName}_split_${pages.join('-')}.${res.extension}`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'pdf-split',
          toolName: 'PDF Page Split',
          sizeBytes: res.bytes.byteLength,
          mimeType: res.mimeType,
          dataUrl: uint8ArrayToDataUrl(res.bytes, res.mimeType),
          metaSummary: `${pages.length} page(s) extracted`,
        });
        setStatusMessage(`Extracted ${pages.length} page(s) successfully.`);
      } else if (selectedTool === 'pdf-merge') {
        if (mergeList.length === 0) return;
        const res = await mergePdfFiles(mergeList.map((m) => m.bytes));
        const cleanName = `Merged_BT_Document_${mergeList.length}_files.pdf`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'pdf-merge',
          toolName: 'PDF Merge',
          sizeBytes: res.bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(res.bytes, 'application/pdf'),
          metaSummary: `${mergeList.length} files · ${res.totalPages} pages`,
        });
        setStatusMessage(`Merged ${mergeList.length} PDFs (${res.totalPages} total pages).`);
      } else if (selectedTool === 'sign-pdf') {
        if (!activePdfBytes) return;
        if (!signaturePng) {
          setStatusMessage('Please draw your signature on the pad before stamping the PDF.');
          return;
        }
        const bytes = await signPdfDocument({
          pdfBytes: activePdfBytes,
          signaturePngDataUrl: signaturePng,
          signerName,
          pageNumber: previewPageNum,
          positionPercent: sigPosPercent,
          widthPt: 150,
        });
        const cleanName = `Signed_${activePdfName}`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'sign-pdf',
          toolName: 'Sign PDF',
          sizeBytes: bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(bytes, 'application/pdf'),
          metaSummary: `Signed by ${signerName || 'User'} · P.${previewPageNum}`,
        });
        setStatusMessage(`Signature stamped onto Page ${previewPageNum} as "${cleanName}". Original PDF preserved.`);
      } else if (selectedTool === 'pdf-to-word') {
        if (!activePdfBytes) return;
        const extracted = await extractTextFromPdf(activePdfBytes);
        setExtractedPdfPages(extracted.pageTexts);
        const docxBytes = await convertPdfToWordDocx({
          title: activePdfName.replace(/\.pdf$/i, ''),
          pageTexts: extracted.pageTexts,
        });
        const cleanName = `${activePdfName.replace(/\.pdf$/i, '')}.docx`;
        const mime =
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'pdf-to-word',
          toolName: 'PDF to Word',
          sizeBytes: docxBytes.byteLength,
          mimeType: mime,
          dataUrl: uint8ArrayToDataUrl(docxBytes, mime),
          metaSummary: `${extracted.totalPages} pages → .docx`,
        });
        setStatusMessage('Converted PDF into editable Word (.docx) document.');
      } else if (selectedTool === 'word-to-pdf') {
        const bytes = await convertTextToPdf({
          title: wordTitle,
          content: wordExtractedText,
          fontSize: 11,
          pageSize: 'A4',
          margin: 48,
        });
        const cleanName = `${(wordTitle || 'Word_Export').replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'word-to-pdf',
          toolName: 'Word to PDF',
          sizeBytes: bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(bytes, 'application/pdf'),
          metaSummary: 'DOCX → A4 PDF',
        });
        setStatusMessage('Word document converted to PDF.');
      } else if (selectedTool === 'pdf-password') {
        if (!activePdfBytes) return;
        const bytes = await protectPdfWithPassword({
          pdfBytes: activePdfBytes,
          userPassword,
          ownerPassword,
          watermarkText: securityWatermark,
          permissions: {
            allowPrinting,
            allowCopying,
            allowModifying: false,
          },
        });
        const cleanName = `Locked_${activePdfName}`;
        recordRecentOutput({
          fileName: cleanName,
          toolId: 'pdf-password',
          toolName: 'PDF Password',
          sizeBytes: bytes.byteLength,
          mimeType: 'application/pdf',
          dataUrl: uint8ArrayToDataUrl(bytes, 'application/pdf'),
          metaSummary: `SHA-256 Protected · ${allowPrinting ? 'Print OK' : 'No Print'}`,
        });
        setStatusMessage(`Password protection & watermark applied as "${cleanName}". Original PDF preserved.`);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const currentToolMeta = TOOLS.find((t) => t.id === selectedTool) || TOOLS[0];
  const needsPdfUpload = [
    'pdf-crop',
    'pdf-split',
    'sign-pdf',
    'pdf-to-word',
    'pdf-password',
  ].includes(selectedTool);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20 lg:pb-8">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-4 sm:px-6 py-3.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveNav('tools');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0 font-display"
        >
          BT Document
        </a>

        {/* Zone 2: 4 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveNav('tools')}
            className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeNav === 'tools'
                ? 'text-blue-600 dark:text-blue-400 font-semibold underline underline-offset-8 decoration-2'
                : ''
            }`}
          >
            All 9 PDF Tools
          </button>
          <button
            onClick={() => setActiveNav('recent')}
            className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeNav === 'recent'
                ? 'text-blue-600 dark:text-blue-400 font-semibold underline underline-offset-8 decoration-2'
                : ''
            }`}
          >
            Recent Used ({recentFiles.length})
          </button>
          <button
            onClick={() => setActiveNav('apk')}
            className={`hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeNav === 'apk'
                ? 'text-blue-600 dark:text-blue-400 font-semibold underline underline-offset-8 decoration-2'
                : ''
            }`}
          >
            Android APK Studio
          </button>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            {darkMode ? 'Light Theme' : 'Dark Theme'}
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2 shrink-0">
          <PWAInstallButton onOpenApkStudio={() => setActiveNav('apk')} />
        </div>
      </header>

      {/* Main Responsive Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-5 space-y-6">
        {/* Quick Access Strip: Recent Used Button & Instant Tool Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white text-balance">
              Android Material 3 Document & PDF Toolkit
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Select any of the 9 native tools below to convert, crop, split, merge, sign, or lock files on-device.
            </p>
          </div>

          {/* Prominent Recent Used Quick-Access Button + Theme Toggle on Mobile */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => setActiveNav(activeNav === 'recent' ? 'tools' : 'recent')}
              className={`min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-semibold transition flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeNav === 'recent'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 hover:border-blue-500'
              }`}
            >
              <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>Recent Used Files ({recentFiles.length})</span>
            </button>

            <button
              onClick={() => setActiveNav('apk')}
              className={`min-h-[44px] px-4 py-2.5 rounded-xl text-xs font-semibold transition flex items-center gap-2 whitespace-nowrap shrink-0 ${
                activeNav === 'apk'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 hover:border-blue-500'
              }`}
            >
              <Smartphone className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Export Native APK</span>
            </button>

            <button
              onClick={() => setDarkMode(!darkMode)}
              className="md:hidden min-h-[44px] min-w-[44px] rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200"
              aria-label="Toggle Theme"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* VIEW 1: ANDROID APK STUDIO */}
        {activeNav === 'apk' && (
          <NativeApkStudioModal onClose={() => setActiveNav('tools')} isEmbedded />
        )}

        {/* VIEW 2: RECENT USED FILES VIEW */}
        {activeNav === 'recent' && (
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Recent Used & Processed Documents
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Quick one-tap access to your recently generated PDFs, cropped pages, signed contracts, and Word exports.
                </p>
              </div>
              {recentFiles.length > 0 && (
                <button
                  onClick={() => {
                    setRecentFiles([]);
                    localStorage.removeItem(RECENT_STORAGE_KEY);
                  }}
                  className="min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear History</span>
                </button>
              )}
            </div>

            {recentFiles.length === 0 ? (
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-12 text-center space-y-3">
                <FolderOpen className="w-10 h-10 text-slate-400 mx-auto" />
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">
                  No Recent Documents Yet
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                  Process any file using the 9 BT Document tools (Text to PDF, Excel to PDF, Crop, Split, Merge, Sign, Word, or Password Lock) and it will appear here for instant access.
                </p>
                <button
                  onClick={() => setActiveNav('tools')}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition inline-flex items-center gap-2"
                >
                  <span>Open Document Tools</span>
                </button>
              </div>
            ) : (
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
                {recentFiles.map((item) => (
                  <div
                    key={item.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {item.fileName}
                        </span>
                      </div>
                      {/* Clean unboxed metadata with typographic separators */}
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                        <span>{item.toolName}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.metaSummary}</span>
                        <span aria-hidden="true">·</span>
                        <span>{formatBytes(item.sizeBytes)}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.createdAt}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          setSelectedTool(item.toolId);
                          setActiveNav('tools');
                        }}
                        className="min-h-[40px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition whitespace-nowrap shrink-0"
                      >
                        Open Tool
                      </button>
                      <button
                        onClick={() => triggerDownload(item)}
                        className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition flex items-center gap-1.5 whitespace-nowrap shrink-0"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}

        {/* VIEW 3: MAIN 9-TOOL ANDROID MATERIAL 3 WORKSPACE */}
        {activeNav === 'tools' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column (5 cols on desktop): 9 Material Design 3 Tool Cards + Recent Quick Strip */}
            <div className="lg:col-span-5 space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Select Document Feature (1–9)
                </h2>
                <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  9 Local Engines Ready
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
                {TOOLS.map((tool) => {
                  const Icon = tool.icon;
                  const isSelected = selectedTool === tool.id;
                  return (
                    <button
                      key={tool.id}
                      onClick={() => {
                        setSelectedTool(tool.id);
                        setStatusMessage('');
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl border transition flex items-start gap-3.5 min-h-[68px] ${
                        isSelected
                          ? 'bg-white dark:bg-slate-900 border-blue-600 dark:border-blue-500 ring-2 ring-blue-600/15 shadow-sm'
                          : 'bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${tool.accentClass}`}
                      >
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                            {tool.number}. {tool.title}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                          {tool.description}
                        </p>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 dark:text-slate-500 mt-1 font-mono">
                          <span>{tool.inputFormat}</span>
                          <span aria-hidden="true">→</span>
                          <span>{tool.outputFormat}</span>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Inline Recent Used Drawer on Main Screen for 1-Tap Access */}
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                      Recent Used Quick Access
                    </h3>
                  </div>
                  <button
                    onClick={() => setActiveNav('recent')}
                    className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    View All ({recentFiles.length})
                  </button>
                </div>

                {recentFiles.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400 py-2">
                    Files you convert, crop, split, merge, sign, or lock will appear here for one-tap download.
                  </p>
                ) : (
                  <div className="space-y-2">
                    {recentFiles.slice(0, 3).map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between gap-2 py-2 border-t border-slate-100 dark:border-slate-800 first:border-t-0"
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                            {item.fileName}
                          </p>
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                            {item.toolName} · {formatBytes(item.sizeBytes)} · {item.createdAt}
                          </p>
                        </div>
                        <button
                          onClick={() => triggerDownload(item)}
                          className="min-h-[36px] px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-semibold hover:bg-blue-100 transition shrink-0"
                        >
                          Download
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Right Column (7 cols on desktop): Active Tool Interactive Studio */}
            <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-6">
              {/* Tool Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="text-xs font-mono text-blue-600 dark:text-blue-400">
                    Tool {currentToolMeta.number} of 09 · {currentToolMeta.inputFormat} to{' '}
                    {currentToolMeta.outputFormat}
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
                    {currentToolMeta.title}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {currentToolMeta.description}
                  </p>
                </div>

                {/* Shared PDF File Uploader for Tools 3, 4, 6, 7, 9 */}
                {needsPdfUpload && (
                  <label className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer flex items-center gap-2 whitespace-nowrap shrink-0">
                    <Upload className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Upload PDF File</span>
                    <input
                      type="file"
                      accept="application/pdf"
                      onChange={handleUploadPdf}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              {/* Active PDF Bar when using PDF-based tools */}
              {needsPdfUpload && (
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-800">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                        {activePdfName}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                        {pdfTotalPages} Page(s) ·{' '}
                        {activePdfBytes ? formatBytes(activePdfBytes.byteLength) : ''}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={previewPageNum <= 1}
                      onClick={() => setPreviewPageNum((p) => Math.max(1, p - 1))}
                      className="min-w-[32px] h-8 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 disabled:opacity-40"
                      aria-label="Previous Page"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <div className="flex items-center gap-1 flex-wrap">
                      {Array.from({ length: pdfTotalPages }, (_, i) => i + 1).map((pNum) => (
                        <button
                          key={pNum}
                          type="button"
                          onClick={() => setPreviewPageNum(pNum)}
                          className={`min-w-[32px] h-8 rounded-lg text-xs font-mono tabular-nums transition ${
                            previewPageNum === pNum
                              ? 'bg-blue-600 text-white font-semibold'
                              : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {pNum}
                        </button>
                      ))}
                    </div>
                    <button
                      type="button"
                      disabled={previewPageNum >= pdfTotalPages}
                      onClick={() => setPreviewPageNum((p) => Math.min(pdfTotalPages, p + 1))}
                      className="min-w-[32px] h-8 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300 disabled:opacity-40"
                      aria-label="Next Page"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* TOOL 01: TEXT TO PDF */}
              {selectedTool === 'text-to-pdf' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Document Heading
                      </label>
                      <input
                        type="text"
                        value={textTitle}
                        onChange={(e) => setTextTitle(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Page Size
                        </label>
                        <select
                          value={textPageSize}
                          onChange={(e) => setTextPageSize(e.target.value as 'A4' | 'LETTER')}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2.5 text-sm text-slate-900 dark:text-white"
                        >
                          <option value="A4">A4</option>
                          <option value="LETTER">Letter</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                          Font Pt
                        </label>
                        <input
                          type="number"
                          min={8}
                          max={20}
                          value={textFontSize}
                          onChange={(e) => setTextFontSize(Number(e.target.value) || 11)}
                          className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2.5 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Plain Text / Notes Content
                      </label>
                      <label className="text-xs font-semibold text-blue-600 dark:text-blue-400 cursor-pointer hover:underline">
                        Import .txt file
                        <input
                          type="file"
                          accept=".txt,.md"
                          onChange={async (e) => {
                            const f = e.target.files?.[0];
                            if (f) {
                              setTextTitle(f.name.replace(/\.[^.]+$/, ''));
                              setTextBody(await f.text());
                            }
                          }}
                          className="hidden"
                        />
                      </label>
                    </div>
                    <textarea
                      rows={9}
                      value={textBody}
                      onChange={(e) => setTextBody(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-3.5 text-sm text-slate-900 dark:text-white leading-relaxed"
                    />
                  </div>
                </div>
              )}

              {/* TOOL 02: EXCEL TO PDF */}
              {selectedTool === 'excel-to-pdf' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex-1 min-w-[200px]">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Spreadsheet Report Title
                      </label>
                      <input
                        type="text"
                        value={excelTitle}
                        onChange={(e) => setExcelTitle(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Page Orientation
                      </label>
                      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                        {(['landscape', 'portrait'] as const).map((o) => (
                          <button
                            key={o}
                            type="button"
                            onClick={() => setExcelOrientation(o)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition ${
                              excelOrientation === o
                                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {o}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-5 flex items-center gap-2">
                      {excelSheetNames.length > 1 && excelBuffer && (
                        <select
                          value={excelSelectedSheet}
                          onChange={(e) => {
                            const idx = Number(e.target.value);
                            setExcelSelectedSheet(idx);
                            const parsed = parseExcelFile(excelBuffer, idx);
                            if (parsed.rows.length > 0) setExcelRows(parsed.rows);
                          }}
                          className="min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs text-slate-900 dark:text-white"
                        >
                          {excelSheetNames.map((name, idx) => (
                            <option key={name} value={idx}>
                              Sheet: {name}
                            </option>
                          ))}
                        </select>
                      )}
                      <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition cursor-pointer inline-flex items-center gap-2 whitespace-nowrap shrink-0">
                        <Upload className="w-4 h-4" />
                        <span>Upload .XLSX / .CSV</span>
                        <input
                          type="file"
                          accept=".xlsx,.xls,.csv"
                          onChange={handleUploadExcel}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  {/* Interactive Spreadsheet Grid Preview */}
                  <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                    <table className="w-full text-left border-collapse text-xs tabular-nums">
                      <thead>
                        <tr className="bg-slate-900 text-white">
                          {excelRows[0]?.map((col, cIdx) => (
                            <th key={cIdx} className="py-2.5 px-3 font-semibold border-r border-slate-700 last:border-r-0">
                              <input
                                type="text"
                                value={col}
                                onChange={(e) => {
                                  const copy = excelRows.map((r) => [...r]);
                                  copy[0][cIdx] = e.target.value;
                                  setExcelRows(copy);
                                }}
                                className="bg-transparent text-white font-semibold w-full focus:outline-none"
                              />
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                        {excelRows.slice(1, 10).map((row, rIdx) => (
                          <tr
                            key={rIdx}
                            className="even:bg-slate-50/70 dark:even:bg-slate-800/40"
                          >
                            {row.map((cell, cIdx) => (
                              <td
                                key={cIdx}
                                className="py-2 px-3 border-r border-slate-100 dark:border-slate-800 last:border-r-0"
                              >
                                <input
                                  type="text"
                                  value={cell}
                                  onChange={(e) => {
                                    const copy = excelRows.map((r) => [...r]);
                                    copy[rIdx + 1][cIdx] = e.target.value;
                                    setExcelRows(copy);
                                  }}
                                  className="bg-transparent text-slate-800 dark:text-slate-200 w-full focus:outline-none"
                                />
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TOOL 03: PDF CROP LIKE PHOTO CROP */}
              {selectedTool === 'pdf-crop' && (
                <div className="space-y-4">
                  {/* Page Scope Controls: All Pages / Current Page / Selected Pages */}
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Target Pages to Crop
                      </span>
                      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900">
                        {(
                          [
                            { id: 'all', label: `All Pages (${pdfTotalPages})` },
                            { id: 'current', label: `Current (P.${previewPageNum})` },
                            { id: 'selected', label: 'Selected Pages' },
                          ] as const
                        ).map((opt) => (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setCropPageScope(opt.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                              cropPageScope === opt.id
                                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {cropPageScope === 'selected' && (
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="text-xs text-slate-500 dark:text-slate-400">
                          Tap pages to include:
                        </span>
                        {Array.from({ length: pdfTotalPages }, (_, i) => i + 1).map((pNum) => {
                          const isIncluded = cropSelectedPages.includes(pNum);
                          return (
                            <button
                              key={pNum}
                              type="button"
                              onClick={() =>
                                setCropSelectedPages((prev) =>
                                  prev.includes(pNum)
                                    ? prev.filter((x) => x !== pNum)
                                    : [...prev, pNum].sort((a, b) => a - b)
                                )
                              }
                              className={`min-w-[36px] h-8 px-2.5 rounded-lg text-xs font-mono font-semibold transition ${
                                isIncluded
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                              }`}
                            >
                              P{pNum}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {pdfPreviewUrl && (
                    <PhotoStylePdfCropper
                      previewUrl={pdfPreviewUrl}
                      pageWidthPt={pdfPageWidthPt}
                      pageHeightPt={pdfPageHeightPt}
                      crop={cropRect}
                      canRevert={cropHistory.length > 0}
                      onCommitStart={() => {
                        setCropHistory((prev) => [...prev.slice(-14), { ...cropRect }]);
                      }}
                      onChange={setCropRect}
                      onRevert={() => {
                        if (cropHistory.length === 0) return;
                        const prev = cropHistory[cropHistory.length - 1];
                        setCropHistory((h) => h.slice(0, -1));
                        setCropRect(prev);
                        setCroppedResultPreviewUrl('');
                      }}
                      onReset={() => {
                        setCropHistory((prev) => [...prev.slice(-14), { ...cropRect }]);
                        setCropRect({ left: 0, top: 0, width: 1, height: 1 });
                        setCroppedResultPreviewUrl('');
                      }}
                    />
                  )}

                  {/* Output Rename Field (Original PDF never overwritten) */}
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        Separate Output PDF Name
                      </label>
                      <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                        Original "{activePdfName}" is preserved read-only
                      </span>
                    </div>
                    <input
                      type="text"
                      value={cropOutputName}
                      onChange={(e) => setCropOutputName(e.target.value)}
                      placeholder="Cropped_Document.pdf"
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm font-mono text-slate-900 dark:text-white"
                    />
                  </div>

                  {croppedResultPreviewUrl && (
                    <div className="p-3.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800/70 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-blue-900 dark:text-blue-200">
                          Exported Cropped PDF Verified
                        </div>
                        <p className="text-xs text-blue-700 dark:text-blue-300">
                          Rendered directly from the exported separate PDF file to confirm permanent page bounds.
                        </p>
                      </div>
                      <img
                        src={croppedResultPreviewUrl}
                        alt="Verified Exported Cropped PDF Page"
                        referrerPolicy="no-referrer"
                        className="max-h-[120px] w-auto rounded-lg border border-blue-300 dark:border-blue-700 shadow-sm bg-white"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* TOOL 04: PDF PAGE SPLIT */}
              {selectedTool === 'pdf-split' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Page Range to Extract (e.g. 1-2 or 1,3)
                      </label>
                      <input
                        type="text"
                        value={splitRangeStr}
                        onChange={(e) => setSplitRangeStr(e.target.value)}
                        placeholder="1-2"
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Output Packaging Mode
                      </label>
                      <select
                        value={splitMode}
                        onChange={(e) =>
                          setSplitMode(
                            e.target.value as 'single-extracted-pdf' | 'zip-individual-pages'
                          )
                        }
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white"
                      >
                        <option value="single-extracted-pdf">
                          Combined Extracted PDF (.pdf)
                        </option>
                        <option value="zip-individual-pages">
                          Separate Single-Page PDFs (.zip)
                        </option>
                      </select>
                    </div>
                  </div>

                  {pdfPreviewUrl && (
                    <div className="flex items-center justify-center p-4 rounded-xl bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                      <img
                        src={pdfPreviewUrl}
                        alt="Selected Page Preview"
                        referrerPolicy="no-referrer"
                        className="max-h-[280px] w-auto rounded-lg shadow"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* TOOL 05: PDF MERGE */}
              {selectedTool === 'pdf-merge' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Documents Queued for Merge ({mergeList.length})
                    </span>
                    <label className="min-h-[40px] px-3.5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition cursor-pointer inline-flex items-center gap-1.5">
                      <Plus className="w-4 h-4" />
                      <span>Add PDF Files</span>
                      <input
                        type="file"
                        accept="application/pdf"
                        multiple
                        onChange={handleAddMergeFiles}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="space-y-2">
                    {mergeList.map((item, idx) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="w-6 h-6 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-xs font-mono font-semibold flex items-center justify-center shrink-0 tabular-nums">
                            {idx + 1}
                          </span>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                              {item.name}
                            </p>
                            <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                              {formatBytes(item.size)}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => {
                              const copy = [...mergeList];
                              const [moved] = copy.splice(idx, 1);
                              copy.splice(idx - 1, 0, moved);
                              setMergeList(copy);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-30"
                            title="Move Up"
                          >
                            <ArrowUp className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            disabled={idx === mergeList.length - 1}
                            onClick={() => {
                              const copy = [...mergeList];
                              const [moved] = copy.splice(idx, 1);
                              copy.splice(idx + 1, 0, moved);
                              setMergeList(copy);
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-30"
                            title="Move Down"
                          >
                            <ArrowDown className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setMergeList((prev) => prev.filter((x) => x.id !== item.id))
                            }
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                            title="Remove"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TOOL 06: SIGN PDF */}
              {selectedTool === 'sign-pdf' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Signer Full Name (Audit Stamp)
                      </label>
                      <input
                        type="text"
                        value={signerName}
                        onChange={(e) => setSignerName(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Signature Placement Preset
                      </label>
                      <select
                        value={`${sigPosPercent.x},${sigPosPercent.y}`}
                        onChange={(e) => {
                          const [x, y] = e.target.value.split(',').map(Number);
                          setSigPosPercent({ x, y });
                        }}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm text-slate-900 dark:text-white"
                      >
                        <option value="0.52,0.72">Bottom Right Signature Line</option>
                        <option value="0.12,0.72">Bottom Left Counter-Sign</option>
                        <option value="0.35,0.48">Center Page Authorization</option>
                      </select>
                    </div>
                  </div>

                  <SignaturePad onSignatureChange={setSignaturePng} />
                </div>
              )}

              {/* TOOL 07: PDF TO WORD */}
              {selectedTool === 'pdf-to-word' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Extracted Page Text Preview ({extractedPdfPages.length} Pages)
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      Exports to .DOCX (Word OpenXML)
                    </span>
                  </div>
                  <div className="max-h-[260px] overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 p-4 space-y-3 text-xs text-slate-700 dark:text-slate-300">
                    {extractedPdfPages.map((txt, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="font-mono font-semibold text-blue-600 dark:text-blue-400">
                          Page {idx + 1}
                        </div>
                        <p className="whitespace-pre-line leading-relaxed">{txt}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TOOL 08: WORD TO PDF */}
              {selectedTool === 'word-to-pdf' && (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex-1 min-w-[200px]">
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Document Title
                      </label>
                      <input
                        type="text"
                        value={wordTitle}
                        onChange={(e) => setWordTitle(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="pt-5">
                      <label className="min-h-[40px] px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-semibold hover:bg-teal-700 transition cursor-pointer inline-flex items-center gap-2">
                        <Upload className="w-4 h-4" />
                        <span>Upload Word (.DOCX)</span>
                        <input
                          type="file"
                          accept=".docx"
                          onChange={handleUploadWord}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <textarea
                    rows={8}
                    value={wordExtractedText}
                    onChange={(e) => setWordExtractedText(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-3.5 text-sm text-slate-900 dark:text-white leading-relaxed"
                  />
                </div>
              )}

              {/* TOOL 09: PDF PASSWORD PROTECTION */}
              {selectedTool === 'pdf-password' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        User Open Password
                      </label>
                      <input
                        type="text"
                        value={userPassword}
                        onChange={(e) => setUserPassword(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Owner / Permissions Password
                      </label>
                      <input
                        type="text"
                        value={ownerPassword}
                        onChange={(e) => setOwnerPassword(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm font-mono text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Security Watermark Stamp
                    </label>
                    <input
                      type="text"
                      value={securityWatermark}
                      onChange={(e) => setSecurityWatermark(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="flex flex-wrap items-center gap-6 pt-1">
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allowPrinting}
                        onChange={(e) => setAllowPrinting(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600"
                      />
                      <span>Allow Printing</span>
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allowCopying}
                        onChange={(e) => setAllowCopying(e.target.checked)}
                        className="rounded border-slate-300 text-blue-600"
                      />
                      <span>Allow Text Copying</span>
                    </label>
                  </div>
                </div>
              )}

              {/* Primary Action CTA Button */}
              <div className="pt-2 space-y-3">
                <button
                  type="button"
                  onClick={executeActiveTool}
                  disabled={isProcessing}
                  className="w-full min-h-[48px] rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isProcessing
                      ? 'Processing Document...'
                      : `Run ${currentToolMeta.title} & Generate Output`}
                  </span>
                </button>

                {statusMessage && (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800/80 text-xs text-emerald-900 dark:text-emerald-200">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="font-medium">{statusMessage}</span>
                    </div>
                    {lastOutput && (
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => triggerDownload(lastOutput, true)}
                          className="min-h-[36px] px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 text-white font-semibold hover:bg-slate-800 transition flex items-center gap-1.5 shrink-0"
                        >
                          <FolderInput className="w-3.5 h-3.5" />
                          <span>Choose Save Location</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => triggerDownload(lastOutput, false)}
                          className="min-h-[36px] px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700 transition flex items-center gap-1.5 shrink-0"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download {lastOutput.fileName}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Fixed Bottom Tab Bar for Mobile Thumb-Zone Ergonomics (<= 15% mobile height) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 items-center h-14">
        <button
          onClick={() => setActiveNav('tools')}
          className={`flex flex-col items-center justify-center h-full ${
            activeNav === 'tools'
              ? 'text-blue-600 dark:text-blue-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <FileText className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">All 9 Tools</span>
        </button>
        <button
          onClick={() => setActiveNav('recent')}
          className={`flex flex-col items-center justify-center h-full ${
            activeNav === 'recent'
              ? 'text-blue-600 dark:text-blue-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Recent ({recentFiles.length})</span>
        </button>
        <button
          onClick={() => setActiveNav('apk')}
          className={`flex flex-col items-center justify-center h-full ${
            activeNav === 'apk'
              ? 'text-blue-600 dark:text-blue-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Smartphone className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">Proper APK</span>
        </button>
      </nav>
    </div>
  );
}
