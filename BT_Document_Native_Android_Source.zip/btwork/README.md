# BT Document – Main Source

This archive is the primary AI Studio source project for BT Document. Keep this project as the source of truth.

## Native Android APK source generator updates
- Android Gradle properties now explicitly enable AndroidX (`android.useAndroidX=true`).
- PDF Crop touch handling consumes the initial pointer event and processes drag gestures within the crop canvas, reducing conflicts with the surrounding vertical scroll container.
- Crop coordinates are clamped and converted from the top-left normalized preview coordinate system to PDF bottom-left coordinates using the visible page box.
- Native project version defaults to 2.4.1 (version code 25).

## Build notes
The Android project is generated from `src/services/apkProjectGenerator.ts` using the Native APK Studio UI. This source archive is not itself a compiled APK. Build the generated Android Studio project with JDK 17, Android SDK, and Gradle 8.9. Compile and test on real PDF files before release, especially rotated pages and PDFs with non-default page boxes.

## Important
The changes in this source archive are source-level fixes. They have not been compiled with Android Gradle or validated on a physical Android device in this environment. Do not treat the APK as release-ready until GitHub Actions builds successfully and the crop workflow is tested on-device.
