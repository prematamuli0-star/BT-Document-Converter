package com.btdocument.suite.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Matrix as AndroidMatrix
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.RecentDocumentRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil
import kotlin.math.atan2
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------
// Document coordinate system
//
// Every page is laid out in "document units": each page is DOC_W units wide and as tall as its
// aspect ratio requires, pages are stacked vertically with PAGE_GAP between them. The signature
// box is stored in these units, so it is anchored to the PDF itself and is unaffected by zoom or
// pan. The screen only applies  screen = off + doc * scale.
// On save the box is converted to page-relative ratios using the very same page layout, so the
// saved position and size are exactly what the preview shows.
// ---------------------------------------------------------------------------------------------

private const val SIGN_DOC_W = 1000f
private const val SIGN_PAGE_GAP = 24f
private const val SIGN_MIN_ZOOM = 1f
private const val SIGN_MAX_ZOOM = 6f
private const val SIGN_MIN_W = 60f
private const val SIGN_MAX_RENDER_W = 2000

private enum class SignDrag { PAN, PINCH, MOVE, NW, NE, SW, SE, STAMP_MOVE, STAMP_RESIZE }

private class StampPlacement {
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var w by mutableFloatStateOf(220f)
    var h by mutableFloatStateOf(120f)
    var page by mutableIntStateOf(0)
    var active by mutableStateOf(false)
    fun move(view: SignView, dx: Float, dy: Float) {
        val scale = view.scale
        val top = view.tops.getOrElse(page) { 0f }
        val ph = view.heights.getOrElse(page) { SIGN_DOC_W }
        x = (x + dx / scale).coerceIn(0f, max(0f, SIGN_DOC_W - w))
        y = (y + dy / scale).coerceIn(top, max(top, top + ph - h))
    }
    fun resize(view: SignView, pos: Offset) {
        val scale = view.scale
        val right = (pos.x - view.offX) / scale
        val bottom = (pos.y - view.offY) / scale
        val aspect = w / h.coerceAtLeast(1f)
        val top = view.tops.getOrElse(page) { 0f }
        val ph = view.heights.getOrElse(page) { SIGN_DOC_W }
        val nw = (right - x).coerceIn(60f, SIGN_DOC_W - x)
        val nh = (nw / aspect).coerceAtMost(top + ph - y)
        w = nw.coerceAtLeast(60f); h = nh.coerceAtLeast(30f)
    }
}

private class SignPageBmp(val bitmap: Bitmap, val width: Int)

/** Pan / zoom / page-layout state of the PDF viewport. */
private class SignView {
    var vpW by mutableFloatStateOf(1f)
    var vpH by mutableFloatStateOf(1f)
    var zoom by mutableFloatStateOf(1f)      // multiplier on top of "fit page width"
    var offX by mutableFloatStateOf(0f)      // screen px of document origin
    var offY by mutableFloatStateOf(0f)
    var tops by mutableStateOf(FloatArray(0))
    var heights by mutableStateOf(FloatArray(0))
    var totalH by mutableFloatStateOf(1f)

    val pageCount: Int get() = heights.size
    val scale: Float get() = (vpW / SIGN_DOC_W) * zoom
    val contentH: Float get() = totalH * scale

    fun setPages(sizes: List<Pair<Float, Float>>) {
        val n = sizes.size
        val t = FloatArray(n)
        val h = FloatArray(n)
        var y = 0f
        for (i in 0 until n) {
            val (pw, ph) = sizes[i]
            h[i] = SIGN_DOC_W * ph / pw.coerceAtLeast(1f)
            t[i] = y
            y += h[i] + SIGN_PAGE_GAP
        }
        tops = t
        heights = h
        totalH = (y - SIGN_PAGE_GAP).coerceAtLeast(1f)
        zoom = 1f; offX = 0f; offY = 0f
        clamp()
    }

    fun clamp() {
        val s = scale
        val cw = SIGN_DOC_W * s
        val ch = totalH * s
        offX = if (cw <= vpW) (vpW - cw) / 2f else offX.coerceIn(vpW - cw, 0f)
        offY = if (ch <= vpH) 0f else offY.coerceIn(vpH - ch, 0f)
    }

    fun zoomAbout(newZoom: Float, cx: Float, cy: Float) {
        val old = scale
        zoom = newZoom.coerceIn(SIGN_MIN_ZOOM, SIGN_MAX_ZOOM)
        val k = scale / old
        offX = cx - (cx - offX) * k
        offY = cy - (cy - offY) * k
        clamp()
    }

    fun panBy(dx: Float, dy: Float) {
        offX += dx
        offY += dy
        clamp()
    }

    fun resetZoom() {
        zoom = 1f
        clamp()
    }

    fun pageAt(docY: Float): Int {
        if (pageCount == 0) return 0
        for (i in 0 until pageCount) {
            if (docY < tops[i] + heights[i] + SIGN_PAGE_GAP / 2f) return i
        }
        return pageCount - 1
    }

    fun firstVisible(): Int = pageAt(-offY / scale)
    fun lastVisible(): Int = pageAt((vpH - offY) / scale)
    fun currentPage(): Int = pageAt((vpH / 2f - offY) / scale)

    fun scrollToPage(i: Int) {
        if (pageCount == 0) return
        val idx = i.coerceIn(0, pageCount - 1)
        offY = -tops[idx] * scale
        clamp()
    }
}

/** Signature rectangle in document units plus the scratch values used while resizing. */
private class SignPlacement {
    var placed by mutableStateOf(false)
    var x by mutableFloatStateOf(0f)
    var y by mutableFloatStateOf(0f)
    var w by mutableFloatStateOf(1f)
    var h by mutableFloatStateOf(1f)

    private var ax = 0f; private var ay = 0f
    private var grabX = 0f; private var grabY = 0f
    private var aspect = 1f
    private var movingLeft = false; private var movingTop = false
    private var pTop = 0f; private var pBottom = 0f

    fun placeAtCenter(view: SignView, inkAspect: Float) {
        if (view.pageCount == 0) return
        val s = view.scale
        val cy = (view.vpH / 2f - view.offY) / s
        val cx = (view.vpW / 2f - view.offX) / s
        val i = view.pageAt(cy)
        val ph = view.heights[i]
        var nw = SIGN_DOC_W * 0.4f
        var nh = nw / inkAspect
        if (nh > ph * 0.3f) { nh = ph * 0.3f; nw = nh * inkAspect }
        if (nw > SIGN_DOC_W * 0.9f) { nw = SIGN_DOC_W * 0.9f; nh = nw / inkAspect }
        if (nw < SIGN_MIN_W) { nw = SIGN_MIN_W; nh = nw / inkAspect }
        w = nw; h = nh
        x = cx - nw / 2f
        y = cy - nh / 2f
        placed = true
        snap(view)
    }

    /** Ink bounding box changed: keep top-left and width, follow the new aspect ratio. */
    fun reshape(view: SignView, inkAspect: Float) {
        if (view.pageCount == 0) return
        h = w / inkAspect
        snap(view)
    }

    /** Keep the box fully inside the page that contains its centre. */
    fun snap(view: SignView) {
        if (view.pageCount == 0) return
        val i = view.pageAt(y + h / 2f)
        val top = view.tops[i]
        val ph = view.heights[i]
        val a = w / h.coerceAtLeast(0.0001f)
        var nw = w
        var nh = h
        if (nw > SIGN_DOC_W) { nw = SIGN_DOC_W; nh = nw / a }
        if (nh > ph) { nh = ph; nw = nh * a }
        w = nw; h = nh
        x = x.coerceIn(0f, SIGN_DOC_W - w)
        y = y.coerceIn(top, top + ph - h)
    }

    fun hit(view: SignView, p: Offset, hitR: Float, bodyPad: Float): SignDrag {
        if (!placed) return SignDrag.PAN
        val s = view.scale
        val l = view.offX + x * s
        val t = view.offY + y * s
        val r = l + w * s
        val b = t + h * s
        val rad = min(hitR, max(hitR * 0.5f, 0.35f * min(r - l, b - t)))
        val corners = listOf(
            SignDrag.NW to Offset(l, t), SignDrag.NE to Offset(r, t),
            SignDrag.SW to Offset(l, b), SignDrag.SE to Offset(r, b)
        )
        val best = corners.minByOrNull { (it.second - p).getDistance() }!!
        if ((best.second - p).getDistance() <= rad) return best.first
        if (p.x >= l - bodyPad && p.x <= r + bodyPad && p.y >= t - bodyPad && p.y <= b + bodyPad) return SignDrag.MOVE
        return SignDrag.PAN
    }

    fun moveBy(view: SignView, dxPx: Float, dyPx: Float) {
        val s = view.scale
        x = (x + dxPx / s).coerceIn(0f, max(0f, SIGN_DOC_W - w))
        y = (y + dyPx / s).coerceIn(0f, max(0f, view.totalH - h))
    }

    fun beginCorner(view: SignView, mode: SignDrag, down: Offset) {
        aspect = w / h.coerceAtLeast(0.0001f)
        movingLeft = mode == SignDrag.NW || mode == SignDrag.SW
        movingTop = mode == SignDrag.NW || mode == SignDrag.NE
        ax = if (movingLeft) x + w else x
        ay = if (movingTop) y + h else y
        val cornerX = if (movingLeft) x else x + w
        val cornerY = if (movingTop) y else y + h
        val s = view.scale
        grabX = cornerX - (down.x - view.offX) / s
        grabY = cornerY - (down.y - view.offY) / s
        val i = view.pageAt(y + h / 2f)
        pTop = view.tops[i]
        pBottom = pTop + view.heights[i]
    }

    /** Aspect-locked resize around the opposite (anchor) corner, bounded by the page. */
    fun resizeTo(view: SignView, pos: Offset) {
        val s = view.scale
        val px = (pos.x - view.offX) / s + grabX
        val py = (pos.y - view.offY) / s + grabY
        val dx = if (movingLeft) ax - px else px - ax
        val dy = if (movingTop) ay - py else py - ay
        var nw = max(dx, dy * aspect)
        val maxByX = if (movingLeft) ax else SIGN_DOC_W - ax
        val maxByY = (if (movingTop) ay - pTop else pBottom - ay) * aspect
        val maxW = min(maxByX, maxByY).coerceAtLeast(SIGN_MIN_W)
        nw = nw.coerceIn(SIGN_MIN_W, maxW)
        val nh = nw / aspect
        w = nw; h = nh
        x = if (movingLeft) ax - nw else ax
        y = if (movingTop) ay - nh else ay
    }
}

/** Signature strokes normalised to their own padded bounding box (0..1 in both axes). */
private class SignInk(val strokes: List<List<Offset>>, val aspect: Float, val strokeRel: Float)

private fun normalizeSignInk(raw: List<List<Offset>>, penWidth: Float): SignInk? {
    val strokes = raw.filter { it.size > 1 }
    if (strokes.isEmpty()) return null
    var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
    var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
    strokes.forEach { s -> s.forEach { p ->
        minX = min(minX, p.x); maxX = max(maxX, p.x)
        minY = min(minY, p.y); maxY = max(maxY, p.y)
    } }
    val pad = 10f
    val bw = (maxX - minX) + 2 * pad
    val bh = (maxY - minY) + 2 * pad
    val mapped = strokes.map { s -> s.map { Offset((it.x - minX + pad) / bw, (it.y - minY + pad) / bh) } }
    return SignInk(mapped, bw / bh, (penWidth / bw).coerceIn(0.004f, 0.08f))
}

private fun rotateBitmapForPdf(source: Bitmap, degrees: Float): Bitmap {
    val normalized = ((degrees % 360f) + 360f) % 360f
    if (normalized == 0f) return source
    val matrix = AndroidMatrix().apply { postRotate(normalized) }
    return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
}

private fun renderSignInk(ink: SignInk, inkColor: Color, w: Int, h: Int): Bitmap {
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bmp)
    val paint = Paint().apply {
        color = AndroidColor.argb(
            255, (inkColor.red * 255f).roundToInt(), (inkColor.green * 255f).roundToInt(),
            (inkColor.blue * 255f).roundToInt()
        )
        strokeWidth = (ink.strokeRel * w).coerceAtLeast(2f)
        style = Paint.Style.STROKE
        isAntiAlias = true
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    ink.strokes.forEach { pts ->
        val p = AndroidPath()
        p.moveTo(pts[0].x * w, pts[0].y * h)
        for (k in 1 until pts.size) p.lineTo(pts[k].x * w, pts[k].y * h)
        canvas.drawPath(p, paint)
    }
    return bmp
}

/** One open PdfRenderer; Android allows only one open page at a time, so access is serialised. */
private class SignPdfRenderer private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    val sizes: List<Pair<Float, Float>>
) {
    private val lock = Mutex()
    private var closed = false

    suspend fun render(index: Int, widthPx: Int): Bitmap? = withContext(Dispatchers.IO) {
        lock.withLock {
            if (closed || index !in sizes.indices) return@withLock null
            try {
                renderer.openPage(index).use { page ->
                    val w = widthPx.coerceAtLeast(1)
                    val h = (w * page.height.toFloat() / page.width.coerceAtLeast(1)).roundToInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(AndroidColor.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            } catch (e: OutOfMemoryError) {
                null
            }
        }
    }

    suspend fun close() {
        withContext(Dispatchers.IO) {
            lock.withLock {
                if (!closed) {
                    closed = true
                    try { renderer.close() } catch (_: Exception) {}
                    try { pfd.close() } catch (_: Exception) {}
                }
            }
        }
    }

    fun closeAsync() {
        CoroutineScope(Dispatchers.IO).launch { close() }
    }

    companion object {
        fun open(file: File): SignPdfRenderer {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                val sizes = ArrayList<Pair<Float, Float>>()
                for (i in 0 until r.pageCount) {
                    r.openPage(i).use { sizes.add(it.width.toFloat() to it.height.toFloat()) }
                }
                if (sizes.isEmpty()) {
                    r.close()
                    throw IllegalStateException("The PDF has no pages")
                }
                return SignPdfRenderer(pfd, r, sizes)
            } catch (e: Exception) {
                try { pfd.close() } catch (_: Exception) {}
                throw e
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Gestures. One pointer handler owns every touch on the viewport, so there is no conflict:
//   * 2+ fingers on object -> rotate that signature/stamp with a two-finger twist
//   * 2+ fingers elsewhere -> pinch zoom (around the fingers' centre) + pan
//   * 1 finger on a corner -> resize signature (aspect locked)
//   * 1 finger on the box  -> move signature
//   * 1 finger elsewhere   -> pan / scroll the document
// ---------------------------------------------------------------------------------------------
private suspend fun PointerInputScope.signPdfGestures(
    view: SignView, sig: SignPlacement, stamp: StampPlacement,
    setSelectedSignature: (Boolean) -> Unit, setSelectedStamp: (Boolean) -> Unit,
    getSignatureRotation: () -> Float, setSignatureRotation: (Float) -> Unit,
    getStampRotation: () -> Float, setStampRotation: (Float) -> Unit
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val slop = viewConfiguration.touchSlop
        val hitR = 28.dp.toPx()
        val bodyPad = 6.dp.toPx()
        val stampScale = view.scale
        val stampL = view.offX + stamp.x * stampScale
        val stampT = view.offY + stamp.y * stampScale
        val stampR = stampL + stamp.w * stampScale
        val stampB = stampT + stamp.h * stampScale
        val stampHandle = 20.dp.toPx()
        val onStamp = stamp.active && stamp.page in view.firstVisible()..view.lastVisible() &&
            down.position.x in stampL..stampR && down.position.y in stampT..stampB
        val signatureHit = sig.hit(view, down.position, hitR, bodyPad)
        if (onStamp) {
            setSelectedStamp(true)
            setSelectedSignature(false)
        } else if (signatureHit != SignDrag.PAN) {
            setSelectedSignature(true)
            setSelectedStamp(false)
        } else {
            setSelectedSignature(false)
            setSelectedStamp(false)
        }
        var mode = when {
            onStamp && (down.position - Offset(stampR, stampB)).getDistance() <= stampHandle -> SignDrag.STAMP_RESIZE
            onStamp -> SignDrag.STAMP_MOVE
            else -> signatureHit
        }
        var started = mode == SignDrag.PAN
        var accum = Offset.Zero
        var touchedSignature = false
        val rotationTarget = when { onStamp -> 2; signatureHit != SignDrag.PAN -> 1; else -> 0 }
        if (mode == SignDrag.NW || mode == SignDrag.NE || mode == SignDrag.SW || mode == SignDrag.SE) sig.beginCorner(view, mode, down.position)
        down.consume()

        do {
            val event = awaitPointerEvent()
            val pressedCount = event.changes.count { it.pressed }
            if (pressedCount >= 2) {
                mode = SignDrag.PINCH
                val zoomChange = event.calculateZoom()
                val pan = event.calculatePan()
                val centroid = event.calculateCentroid(useCurrent = true)
                val pointers = event.changes.filter { it.pressed }.take(2)
                if (pointers.size == 2 && rotationTarget != 0) {
                    val a = pointers[0]
                    val b = pointers[1]
                    val previousVector = b.previousPosition - a.previousPosition
                    val currentVector = b.position - a.position
                    val previousAngle = atan2(previousVector.y, previousVector.x)
                    val currentAngle = atan2(currentVector.y, currentVector.x)
                    var deltaAngle = (currentAngle - previousAngle) * (180f / PI.toFloat())
                    if (deltaAngle > 180f) deltaAngle -= 360f
                    if (deltaAngle < -180f) deltaAngle += 360f
                    if (rotationTarget == 1) setSignatureRotation(getSignatureRotation() + deltaAngle)
                    else setStampRotation(getStampRotation() + deltaAngle)
                }
                if (rotationTarget != 0) {
                    // When the gesture starts on a signature or stamp, the two-finger twist
                    // rotates that object only; it must not zoom or pan the PDF underneath.
                } else if (centroid.isSpecified) {
                    if (zoomChange != 1f) view.zoomAbout(view.zoom * zoomChange, centroid.x, centroid.y)
                    view.panBy(pan.x, pan.y)
                }
                event.changes.forEach { if (it.positionChanged()) it.consume() }
            } else if (pressedCount == 1) {
                val ch = event.changes.first { it.pressed }
                if (mode == SignDrag.PINCH) { mode = SignDrag.PAN; started = true }
                val delta = ch.position - ch.previousPosition
                when (mode) {
                    SignDrag.PAN -> view.panBy(delta.x, delta.y)
                    SignDrag.MOVE -> {
                        if (!started) {
                            accum += delta
                            if (accum.getDistance() > slop) {
                                started = true
                                touchedSignature = true
                                sig.moveBy(view, accum.x, accum.y)
                            }
                        } else {
                            sig.moveBy(view, delta.x, delta.y)
                        }
                    }
                    SignDrag.STAMP_MOVE -> { stamp.move(view, delta.x, delta.y); started = true }
                    SignDrag.STAMP_RESIZE -> { stamp.resize(view, ch.position); started = true }
                    SignDrag.NW, SignDrag.NE, SignDrag.SW, SignDrag.SE -> {
                        if (!started) {
                            accum += delta
                            if (accum.getDistance() > slop) started = true
                        }
                        if (started) {
                            touchedSignature = true
                            sig.resizeTo(view, ch.position)
                        }
                    }
                    SignDrag.PINCH -> {}
                }
                if (ch.positionChanged()) ch.consume()
            }
        } while (event.changes.any { it.pressed })

        if (touchedSignature) sig.snap(view)
    }
}

// ---------------------------------------------------------------------------------------------
// Vertical scrollbar (always visible, 24dp wide hit area, 12dp thick thumb, draggable)
// ---------------------------------------------------------------------------------------------
@Composable
private fun SignPdfScrollbar(view: SignView, modifier: Modifier = Modifier) {
    val trackColor = Color(0x22000000)
    val thumbColor = Color(0xFF475569)
    Canvas(
        modifier
            .background(Color(0x0D000000), RoundedCornerShape(6.dp))
            .pointerInput(view) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val trackH = size.height.toFloat()
                    val minThumb = 56.dp.toPx()
                    fun thumbH(): Float {
                        val ch = view.contentH
                        return if (ch <= view.vpH) trackH else (view.vpH / ch * trackH).coerceIn(minThumb, trackH)
                    }
                    fun thumbTop(): Float {
                        val ch = view.contentH
                        val range = ch - view.vpH
                        if (range <= 0f) return 0f
                        return (-view.offY / range).coerceIn(0f, 1f) * (trackH - thumbH())
                    }
                    val th = thumbH()
                    val tt = thumbTop()
                    val grab = if (down.position.y in tt..(tt + th)) down.position.y - tt else th / 2f
                    fun scrollTo(y: Float) {
                        val travel = trackH - th
                        val range = view.contentH - view.vpH
                        if (travel > 0f && range > 0f) {
                            val frac = ((y - grab) / travel).coerceIn(0f, 1f)
                            view.offY = -frac * range
                            view.clamp()
                        }
                    }
                    scrollTo(down.position.y)
                    down.consume()
                    do {
                        val event = awaitPointerEvent()
                        val c = event.changes.firstOrNull()
                        if (c != null) { scrollTo(c.position.y); c.consume() }
                    } while (event.changes.any { it.pressed })
                }
            }
    ) {
        val trackH = size.height
        val ch = view.contentH
        val range = ch - view.vpH
        val th = if (range <= 0f) trackH else (view.vpH / ch * trackH).coerceIn(56.dp.toPx(), trackH)
        val tt = if (range <= 0f) 0f else (-view.offY / range).coerceIn(0f, 1f) * (trackH - th)
        val barW = 12.dp.toPx()
        val x = (size.width - barW) / 2f
        drawRoundRect(
            trackColor, Offset(x + barW / 2f - 1.dp.toPx(), 0f), Size(2.dp.toPx(), trackH),
            androidx.compose.ui.geometry.CornerRadius(1.dp.toPx())
        )
        drawRoundRect(
            thumbColor, Offset(x, tt), Size(barW, th),
            androidx.compose.ui.geometry.CornerRadius(barW / 2f)
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------------------------
@Composable
fun SignPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val view = remember { SignView() }
    val sig = remember { SignPlacement() }

    var pdfFile by remember { mutableStateOf<File?>(null) }
    var renderer by remember { mutableStateOf<SignPdfRenderer?>(null) }
    var loading by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var signerName by remember { mutableStateOf("Authorized Signer") }

    val inkColors = listOf(
        "Blue" to Color(0xFF1D4ED8), "Black" to Color(0xFF111827),
        "Red" to Color(0xFFDC2626), "Green" to Color(0xFF15803D),
        "Purple" to Color(0xFF7E22CE), "Navy" to Color(0xFF1E3A8A)
    )
    var selectedInkColor by remember { mutableStateOf(inkColors[0].second) }
    var penWidth by remember { mutableFloatStateOf(5f) }
    var signatureRotation by remember { mutableFloatStateOf(0f) }
    var stampRotation by remember { mutableFloatStateOf(0f) }
    var selectedSignature by remember { mutableStateOf(true) }
    var selectedStamp by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf<List<List<Offset>>>(emptyList()) }
    var currentStroke by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var undoHistory by remember { mutableStateOf<List<List<List<Offset>>>>(emptyList()) }
    var redoHistory by remember { mutableStateOf<List<List<List<Offset>>>>(emptyList()) }
    var selectedStampUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var stampBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val stampPlacement = remember { StampPlacement() }
    val ink = remember(strokes, penWidth) { normalizeSignInk(strokes, penWidth) }

    val latestRenderer by rememberUpdatedState(renderer)
    DisposableEffect(Unit) { onDispose { latestRenderer?.closeAsync() } }

    // Ink cleared -> remove the box; ink bounding box changed -> follow the new aspect ratio.
    LaunchedEffect(ink) {
        if (ink == null) sig.placed = false
        else if (sig.placed) sig.reshape(view, ink.aspect)
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            loading = true
            message = null
            try {
                val copied = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.copyUriToTempFile(context, uri, "sign_", ".pdf")
                }
                val opened = withContext(Dispatchers.IO) { SignPdfRenderer.open(copied) }
                val old = renderer
                renderer = opened
                pdfFile = copied
                sig.placed = false
                view.setPages(opened.sizes)
                old?.closeAsync()
            } catch (e: Exception) {
                message = "Could not open this PDF: ${e.message ?: "unsupported file"}"
            } finally {
                loading = false
            }
        }
    }

    val stampLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val decoded = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
                if (decoded != null) {
                    selectedStampUri = uri
                    stampBitmap = decoded
                    val page = view.currentPage().coerceIn(0, (view.pageCount - 1).coerceAtLeast(0))
                    stampPlacement.page = page
                    stampPlacement.active = true
                    selectedStamp = true
                    selectedSignature = false
                    stampRotation = 0f
                    val aspect = decoded.width.toFloat() / decoded.height.coerceAtLeast(1)
                    stampPlacement.w = (SIGN_DOC_W * 0.22f).coerceAtLeast(80f)
                    stampPlacement.h = stampPlacement.w / aspect
                    stampPlacement.x = (SIGN_DOC_W - stampPlacement.w) / 2f
                    stampPlacement.y = view.tops.getOrElse(page) { 0f } + (view.heights.getOrElse(page) { SIGN_DOC_W } - stampPlacement.h) / 2f
                    message = "Stamp added to PDF preview."
                } else message = "Could not read this image."
            } catch (e: Exception) {
                message = "Could not open stamp image: ${e.message ?: "unsupported image"}"
            }
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        val currentInk = ink
        if (uri != null && src != null && currentInk != null && sig.placed && view.pageCount > 0) scope.launch {
            saving = true
            message = null
            try {
                sig.snap(view)
                val pageIdx = view.pageAt(sig.y + sig.h / 2f)
                val top = view.tops[pageIdx]
                val ph = view.heights[pageIdx]
                val xRatio = sig.x / SIGN_DOC_W
                val yRatio = (sig.y - top) / ph
                val wRatio = sig.w / SIGN_DOC_W
                val hRatio = sig.h / ph
                val bmpW = 1600
                val bmpH = (bmpW / currentInk.aspect).roundToInt().coerceIn(8, 4000)
                val color = selectedInkColor
                val name = signerName
                val bytes = withContext(Dispatchers.IO) {
                    val rawBitmap = renderSignInk(currentInk, color, bmpW, bmpH)
                    val bitmap = rotateBitmapForPdf(rawBitmap, signatureRotation)
                    val outTemp = File.createTempFile("signed_", ".pdf", context.cacheDir)
                    val rotatedSignatureHeightRatio = (wRatio * (SIGN_DOC_W / ph) *
                        (bitmap.height.toFloat() / bitmap.width.coerceAtLeast(1))).coerceAtLeast(0.001f)
                    PdfDocumentEngine.signPdfPlaced(
                        src, bitmap, name, pageIdx + 1, xRatio, yRatio, wRatio,
                        rotatedSignatureHeightRatio, outTemp
                    )
                    val stamp = stampBitmap
                    if (stamp != null && stampPlacement.page in 0 until view.pageCount) {
                        val stampTop = view.tops[stampPlacement.page]
                        val stampHeight = view.heights[stampPlacement.page]
                        val stampOut = File.createTempFile("stamped_", ".pdf", context.cacheDir)
                        val rotatedStamp = rotateBitmapForPdf(stamp, stampRotation)
                        val stampWidthRatio = (stampPlacement.w / SIGN_DOC_W).coerceIn(0f, 1f)
                        val rotatedStampHeightRatio = (stampWidthRatio * (SIGN_DOC_W / stampHeight) *
                            (rotatedStamp.height.toFloat() / rotatedStamp.width.coerceAtLeast(1))).coerceAtLeast(0.001f)
                        PdfDocumentEngine.signPdfPlaced(
                            outTemp, rotatedStamp, "", stampPlacement.page + 1,
                            (stampPlacement.x / SIGN_DOC_W).coerceIn(0f, 1f),
                            ((stampPlacement.y - stampTop) / stampHeight).coerceIn(0f, 1f),
                            stampWidthRatio, rotatedStampHeightRatio, stampOut
                        )
                        PdfDocumentEngine.writeFileToDestinationUri(context, stampOut, uri)
                    } else {
                        PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                    }
                }
                onSaveRecent(
                    RecentDocumentRecord(
                        System.currentTimeMillis().toString(), "Signed_Document.pdf", "Sign PDF",
                        uri.toString(), bytes, "Just now", name
                    )
                )
                message = "Saved signed PDF."
            } catch (e: Exception) {
                message = "Save failed: ${e.message ?: "unknown error"}"
            } finally {
                saving = false
            }
        }
    }

    // --- page bitmap cache + renderer scheduling -------------------------------------------
    val pages = remember(renderer) { mutableStateMapOf<Int, SignPageBmp>() }
    val targetW by remember(view) {
        derivedStateOf {
            val bucket = ceil(view.zoom * 2f) / 2f
            val base = max(1, view.vpW.toInt())
            (view.vpW * bucket).toInt().coerceIn(base, max(base, SIGN_MAX_RENDER_W))
        }
    }
    val firstVis by remember(view) { derivedStateOf { view.firstVisible() } }
    val lastVis by remember(view) { derivedStateOf { view.lastVisible() } }
    val curPage by remember(view) { derivedStateOf { view.currentPage() } }

    LaunchedEffect(renderer, targetW, firstVis, lastVis) {
        val r = renderer ?: return@LaunchedEffect
        if (view.vpW <= 1f) return@LaunchedEffect
        val pre = if (targetW > view.vpW * 1.6f) 0 else 1
        val lo = (firstVis - pre).coerceAtLeast(0)
        val hi = (lastVis + pre).coerceAtMost(r.sizes.size - 1)
        pages.keys.filter { it < lo - 1 || it > hi + 1 }.forEach { pages.remove(it) }
        val order = (firstVis..lastVis).toList() + (lastVis + 1..hi).toList() + (lo until firstVis).toList().reversed()
        for (i in order) {
            if (i !in 0 until r.sizes.size) continue
            val have = pages[i]
            if (have == null || have.width < targetW) {
                val bmp = r.render(i, targetW) ?: continue
                pages[i] = SignPageBmp(bmp, targetW)
            }
        }
    }

    val setSelectedSignature: (Boolean) -> Unit = { selectedSignature = it }
    val setSelectedStamp: (Boolean) -> Unit = { selectedStamp = it }
    val latestSetSelectedSignature by rememberUpdatedState(setSelectedSignature)
    val latestSetSelectedStamp by rememberUpdatedState(setSelectedStamp)
    val bitmapPaint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val whitePaint = remember { Paint().apply { color = AndroidColor.WHITE } }
    val outline = MaterialTheme.colorScheme.outline

    BoxWithConstraints(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // ---- header -------------------------------------------------------------------
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                FilledTonalButton(
                    onClick = { openLauncher.launch(arrayOf("application/pdf")) },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) { Text(if (pdfFile == null) "Upload File" else "Change PDF", fontSize = 13.sp) }
                if (loading) CircularProgressIndicator(Modifier.padding(start = 8.dp).size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.weight(1f))
                if (pdfFile != null) {
                    TextButton(enabled = curPage > 0, contentPadding = PaddingValues(horizontal = 8.dp),
                        onClick = { view.scrollToPage(curPage - 1) }) { Text("Prev", fontSize = 13.sp) }
                    TextButton(enabled = curPage < view.pageCount - 1, contentPadding = PaddingValues(horizontal = 8.dp),
                        onClick = { view.scrollToPage(curPage + 1) }) { Text("Next", fontSize = 13.sp) }
                    TextButton(contentPadding = PaddingValues(horizontal = 8.dp),
                        onClick = { view.resetZoom() }) { Text("Reset Zoom", fontSize = 13.sp) }
                }
            }

            // ---- PDF viewport + scrollbar -------------------------------------------------
            val pdfViewportHeight = (this@BoxWithConstraints.maxHeight * 0.34f).coerceIn(180.dp, 250.dp)
            Row(Modifier.fillMaxWidth().height(pdfViewportHeight)) {
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, outline, RoundedCornerShape(8.dp))
                ) {
                    Canvas(
                        Modifier.fillMaxSize()
                            .clipToBounds()
                            .onSizeChanged {
                                view.vpW = it.width.toFloat().coerceAtLeast(1f)
                                view.vpH = it.height.toFloat().coerceAtLeast(1f)
                                view.clamp()
                            }
                            .pointerInput(view, sig, stampPlacement, stampBitmap) {
                                signPdfGestures(view, sig, stampPlacement,
                                    { latestSetSelectedSignature(it) }, { latestSetSelectedStamp(it) },
                                    { signatureRotation }, { signatureRotation = it },
                                    { stampRotation }, { stampRotation = it })
                            }
                    ) {
                        drawRect(Color(0xFFD1D5DB))
                        if (view.pageCount == 0) return@Canvas
                        val s = view.scale
                        val ox = view.offX
                        val oy = view.offY
                        for (i in view.firstVisible()..view.lastVisible()) {
                            if (i !in 0 until view.pageCount) continue
                            val l = ox
                            val t = oy + view.tops[i] * s
                            val r = l + SIGN_DOC_W * s
                            val b = t + view.heights[i] * s
                            val bmp = pages[i]
                            drawIntoCanvas { c ->
                                if (bmp != null) c.nativeCanvas.drawBitmap(bmp.bitmap, null, RectF(l, t, r, b), bitmapPaint)
                                else c.nativeCanvas.drawRect(l, t, r, b, whitePaint)
                            }
                        }
                        // Selected image stamp, anchored to PDF document coordinates.
                        stampBitmap?.let { stamp ->
                            if (stampPlacement.page in view.firstVisible()..view.lastVisible()) {
                                val sl = ox + stampPlacement.x * s
                                val st = oy + stampPlacement.y * s
                                val sr = sl + stampPlacement.w * s
                                val sb = st + stampPlacement.h * s
                                drawIntoCanvas { c ->
                                    val canvas = c.nativeCanvas
                                    val save = canvas.save()
                                    canvas.rotate(stampRotation, (sl + sr) / 2f, (st + sb) / 2f)
                                    canvas.drawBitmap(stamp, null, RectF(sl, st, sr, sb), bitmapPaint)
                                    canvas.restoreToCount(save)
                                }
                                if (selectedStamp) {
                                    drawRect(Color(0xFF2563EB), Offset(sl, st), Size(sr - sl, sb - st), style = Stroke(2.dp.toPx()))
                                    drawCircle(Color.White, 10.dp.toPx(), Offset(sr, sb))
                                    drawCircle(Color(0xFF2563EB), 7.dp.toPx(), Offset(sr, sb))
                                }
                            }
                        }
                        // signature adjustment box (document-anchored)
                        if (sig.placed && ink != null) {
                            val l = ox + sig.x * s
                            val t = oy + sig.y * s
                            val bw = sig.w * s
                            val bh = sig.h * s
                            val blue = Color(0xFF2563EB)
                            if (selectedSignature) drawRect(Color(0x142563EB), Offset(l, t), Size(bw, bh))
                            val sw = (ink.strokeRel * bw).coerceAtLeast(1.5f)
                            rotate(signatureRotation, pivot = Offset(l + bw / 2f, t + bh / 2f)) {
                            ink.strokes.forEach { pts ->
                                val p = Path()
                                p.moveTo(l + pts[0].x * bw, t + pts[0].y * bh)
                                for (k in 1 until pts.size) p.lineTo(l + pts[k].x * bw, t + pts[k].y * bh)
                                drawPath(p, selectedInkColor, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                            }
                            if (selectedSignature) {
                                drawRect(blue, Offset(l, t), Size(bw, bh), style = Stroke(2.dp.toPx()))
                                listOf(Offset(l, t), Offset(l + bw, t), Offset(l, t + bh), Offset(l + bw, t + bh)).forEach { pt ->
                                    drawCircle(Color.White, 11.dp.toPx(), pt)
                                    drawCircle(blue, 8.dp.toPx(), pt)
                                    drawCircle(Color.White, 3.dp.toPx(), pt)
                                }
                            }
                        }
                    }
                    if (pdfFile == null) {
                        Text("Upload a PDF to begin", Modifier.align(Alignment.Center),
                            style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4B5563))
                    } else {
                        Text(
                            "Page ${curPage + 1} of ${view.pageCount} · ${(view.zoom * 100).roundToInt()}%",
                            Modifier.align(Alignment.TopStart).padding(6.dp)
                                .background(Color(0xCC111827), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp),
                            color = Color.White, fontSize = 11.sp
                        )
                    }
                }
                Spacer(Modifier.width(4.dp))
                SignPdfScrollbar(view, Modifier.width(24.dp).fillMaxHeight())
            }

            // ---- ink colour swatches (compact, all functional) ---------------------------
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                inkColors.forEach { (label, color) ->
                    val selected = selectedInkColor == color
                    Box(
                        Modifier.size(32.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(if (selected) 3.dp else 1.dp,
                                if (selected) MaterialTheme.colorScheme.primary else outline, CircleShape)
                            .semantics { contentDescription = "$label ink" }
                            .clickable(onClickLabel = "Use $label ink", role = Role.RadioButton) { selectedInkColor = color },
                        contentAlignment = Alignment.Center
                    ) {
                        if (selected) Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.weight(1f))
                OutlinedButton(
                    onClick = { stampLauncher.launch(arrayOf("image/png", "image/jpeg", "image/jpg", "image/webp")) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) { Text("▧ Add Stamp", fontSize = 11.sp, maxLines = 1) }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pen size", fontSize = 11.sp)
                Slider(value = penWidth, onValueChange = { penWidth = it }, valueRange = 2f..14f,
                    modifier = Modifier.weight(1f))
                Text("${penWidth.roundToInt()} px", fontSize = 11.sp)
            }
            // Rotation is controlled directly with a two-finger twist gesture
            // on the selected signature or stamp in the PDF preview.

            OutlinedTextField(
                value = signerName, onValueChange = { signerName = it },
                label = { Text("Signer Name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // ---- drawing area + actions ---------------------------------------------------
            Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.dp, outline, RoundedCornerShape(8.dp))
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { currentStroke = listOf(it) },
                                onDrag = { change, _ -> change.consume(); currentStroke = currentStroke + change.position },
                                onDragEnd = {
                                    if (currentStroke.size > 1) {
                                        undoHistory = undoHistory + listOf(strokes)
                                        redoHistory = emptyList()
                                        strokes = strokes + listOf(currentStroke)
                                    }
                                    currentStroke = emptyList()
                                },
                                onDragCancel = { currentStroke = emptyList() }
                            )
                        }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        (strokes + listOf(currentStroke)).forEach { pts ->
                            if (pts.size > 1) {
                                val p = Path().apply {
                                    moveTo(pts.first().x, pts.first().y)
                                    pts.drop(1).forEach { lineTo(it.x, it.y) }
                                }
                                drawPath(p, selectedInkColor, style = Stroke(width = penWidth, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            }
                        }
                    }
                }
                Column(Modifier.width(108.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            if (strokes.isNotEmpty()) {
                                undoHistory = undoHistory + listOf(strokes)
                                redoHistory = emptyList()
                            }
                            strokes = emptyList(); currentStroke = emptyList()
                        },
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) { Text("Clear Ink", fontSize = 12.sp) }
                    FilledTonalButton(
                        enabled = pdfFile != null && ink != null,
                        onClick = { ink?.let { sig.placeAtCenter(view, it.aspect) } },
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    ) { Text("Place on PDF", fontSize = 12.sp) }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(
                    enabled = undoHistory.isNotEmpty(),
                    onClick = {
                        if (undoHistory.isNotEmpty()) {
                            redoHistory = redoHistory + listOf(strokes)
                            strokes = undoHistory.last()
                            undoHistory = undoHistory.dropLast(1)
                            currentStroke = emptyList()
                        }
                    },
                    modifier = Modifier.weight(1f).height(44.dp)
                ) { Text("↶  Undo") }
                FilledTonalButton(
                    enabled = redoHistory.isNotEmpty(),
                    onClick = {
                        if (redoHistory.isNotEmpty()) {
                            undoHistory = undoHistory + listOf(strokes)
                            strokes = redoHistory.last()
                            redoHistory = redoHistory.dropLast(1)
                            currentStroke = emptyList()
                        }
                    },
                    modifier = Modifier.weight(1f).height(44.dp)
                ) { Text("↷  Redo") }
            }

            Button(
                enabled = pdfFile != null && ink != null && sig.placed && !saving,
                onClick = { saveLauncher.launch("Signed_Document.pdf") },
                modifier = Modifier.fillMaxWidth().height(44.dp)
            ) { Text(if (saving) "Saving PDF..." else "Sign & Save PDF") }

            message?.let {
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = if (it.startsWith("Saved")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
    }
}
