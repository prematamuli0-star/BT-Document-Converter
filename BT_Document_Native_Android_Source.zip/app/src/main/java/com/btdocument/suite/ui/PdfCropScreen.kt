package com.btdocument.suite.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.CropPageScope
import com.btdocument.suite.model.CropRectNorm
import com.btdocument.suite.model.RecentDocumentRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

private enum class DragMode {
    NONE, MOVE, NW, NE, SW, SE, N, S, W, E
}

@Composable
fun PdfCropScreen(
    onSaveRecent: (RecentDocumentRecord) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sourceFile by remember { mutableStateOf<File?>(null) }
    var sourceName by remember { mutableStateOf("No PDF Selected") }
    var totalPages by remember { mutableIntStateOf(0) }
    var currentPageIdx by remember { mutableIntStateOf(0) }
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var cropRect by remember { mutableStateOf(CropRectNorm()) }
    var cropHistory by remember { mutableStateOf<List<CropRectNorm>>(emptyList()) }
    var pageScope by remember { mutableStateOf(CropPageScope.ALL_PAGES) }
    var selectedRangeText by remember { mutableStateOf("1") }
    var outputFileName by remember { mutableStateOf("Cropped_Document.pdf") }
    var statusText by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }

    // Never mutates original sourceFile — only renders page preview
    fun loadPagePreview(file: File, pageIdx: Int) {
        scope.launch {
            val (bmp, count) = withContext(Dispatchers.IO) {
                PdfDocumentEngine.renderPdfPageBitmap(file, pageIdx, 1.6f)
            }
            pageBitmap = bmp
            totalPages = count
        }
    }

    val openPdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val temp = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.copyUriToTempFile(context, uri, "src_crop_", ".pdf")
                }
                sourceFile = temp
                val baseName = uri.lastPathSegment?.substringAfterLast('/') ?: "Document.pdf"
                sourceName = baseName
                outputFileName = "Cropped_${baseName.removeSuffix(".pdf")}.pdf"
                currentPageIdx = 0
                cropRect = CropRectNorm()
                cropHistory = emptyList()
                loadPagePreview(temp, 0)
                statusText = "Opened original PDF (read-only). Ready to crop."
            }
        }
    }

    // SAF CreateDocument launcher lets user pick any save folder & rename file on Android
    val saveCroppedLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { destUri: Uri? ->
        val src = sourceFile
        if (destUri != null && src != null) {
            isBusy = true
            scope.launch {
                val targetPages = when (pageScope) {
                    CropPageScope.ALL_PAGES -> (1..totalPages).toSet()
                    CropPageScope.CURRENT_PAGE -> setOf(currentPageIdx + 1)
                    CropPageScope.SELECTED_PAGES -> PdfDocumentEngine.parsePageRange(selectedRangeText, totalPages).toSet()
                }.ifEmpty { setOf(currentPageIdx + 1) }

                val outTemp = File.createTempFile("cropped_out_", ".pdf", context.cacheDir)
                val sizeBytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.cropPdfPermanent(src, outTemp, cropRect, targetPages)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, destUri)
                }
                onSaveRecent(
                    RecentDocumentRecord(
                        id = System.currentTimeMillis().toString(),
                        displayName = outputFileName,
                        toolTitle = "PDF Crop",
                        uriString = destUri.toString(),
                        sizeBytes = sizeBytes,
                        timestampLabel = "Just now",
                        summary = "${targetPages.size} page(s) permanently cropped"
                    )
                )
                isBusy = false
                statusText = "Saved separate cropped PDF without modifying original."
            }
        }
    }

    // Live cropped Bitmap computed in memory whenever cropRect or pageBitmap changes
    val liveCroppedBitmap by remember(pageBitmap, cropRect) {
        derivedStateOf {
            pageBitmap?.let { bmp ->
                val x = (cropRect.left * bmp.width).toInt().coerceIn(0, bmp.width - 1)
                val y = (cropRect.top * bmp.height).toInt().coerceIn(0, bmp.height - 1)
                val w = (cropRect.width * bmp.width).toInt().coerceIn(1, bmp.width - x)
                val h = (cropRect.height * bmp.height).toInt().coerceIn(1, bmp.height - y)
                Bitmap.createBitmap(bmp, x, y, w, h)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("PDF Crop (Photo Style)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(sourceName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalButton(onClick = { openPdfLauncher.launch(arrayOf("application/pdf")) }) {
                Icon(Icons.Default.FileOpen, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Open PDF")
            }
        }

        if (totalPages > 0) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    enabled = currentPageIdx > 0,
                    onClick = {
                        currentPageIdx -= 1
                        sourceFile?.let { loadPagePreview(it, currentPageIdx) }
                    }
                ) { Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Page") }

                Text("Page ${currentPageIdx + 1} of $totalPages", fontWeight = FontWeight.SemiBold)

                IconButton(
                    enabled = currentPageIdx < totalPages - 1,
                    onClick = {
                        currentPageIdx += 1
                        sourceFile?.let { loadPagePreview(it, currentPageIdx) }
                    }
                ) { Icon(Icons.Default.ChevronRight, contentDescription = "Next Page") }
            }
        }

        // Revert & Reset Toolbar
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = cropHistory.isNotEmpty(),
                onClick = {
                    val prev = cropHistory.last()
                    cropHistory = cropHistory.dropLast(1)
                    cropRect = prev
                }
            ) {
                Icon(Icons.Default.Undo, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Revert")
            }
            OutlinedButton(
                onClick = {
                    cropHistory = cropHistory + cropRect
                    cropRect = CropRectNorm(0f, 0f, 1f, 1f)
                }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Reset Full")
            }
        }

        // Interactive Crop Overlay with 4 Corners + 4 Edges + Move
        pageBitmap?.let { bmp ->
            var boxSize by remember { mutableStateOf(IntSize(1, 1)) }
            var dragMode by remember { mutableStateOf(DragMode.NONE) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                    .onSizeChanged { boxSize = it }
                    .pointerInput(boxSize) {
                        detectDragGestures(
                            onDragStart = { start ->
                                cropHistory = (cropHistory + cropRect).takeLast(12)
                                val w = boxSize.width.toFloat().coerceAtLeast(1f)
                                val h = boxSize.height.toFloat().coerceAtLeast(1f)
                                val l = cropRect.left * w
                                val t = cropRect.top * h
                                val r = (cropRect.left + cropRect.width) * w
                                val b = (cropRect.top + cropRect.height) * h
                                val tol = 48f

                                val nearL = abs(start.x - l) < tol
                                val nearR = abs(start.x - r) < tol
                                val nearT = abs(start.y - t) < tol
                                val nearB = abs(start.y - b) < tol

                                dragMode = when {
                                    nearL && nearT -> DragMode.NW
                                    nearR && nearT -> DragMode.NE
                                    nearL && nearB -> DragMode.SW
                                    nearR && nearB -> DragMode.SE
                                    nearT && start.x in l..r -> DragMode.N
                                    nearB && start.x in l..r -> DragMode.S
                                    nearL && start.y in t..b -> DragMode.W
                                    nearR && start.y in t..b -> DragMode.E
                                    start.x in l..r && start.y in t..b -> DragMode.MOVE
                                    else -> DragMode.NONE
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val dx = dragAmount.x / boxSize.width.toFloat().coerceAtLeast(1f)
                                val dy = dragAmount.y / boxSize.height.toFloat().coerceAtLeast(1f)
                                val minS = 0.08f
                                val cur = cropRect
                                var l = cur.left
                                var t = cur.top
                                var r = cur.left + cur.width
                                var b = cur.top + cur.height

                                when (dragMode) {
                                    DragMode.MOVE -> {
                                        val nl = (cur.left + dx).coerceIn(0f, 1f - cur.width)
                                        val nt = (cur.top + dy).coerceIn(0f, 1f - cur.height)
                                        cropRect = cur.copy(left = nl, top = nt)
                                        return@detectDragGestures
                                    }
                                    DragMode.NW -> { l = (l + dx).coerceIn(0f, r - minS); t = (t + dy).coerceIn(0f, b - minS) }
                                    DragMode.NE -> { r = (r + dx).coerceIn(l + minS, 1f); t = (t + dy).coerceIn(0f, b - minS) }
                                    DragMode.SW -> { l = (l + dx).coerceIn(0f, r - minS); b = (b + dy).coerceIn(t + minS, 1f) }
                                    DragMode.SE -> { r = (r + dx).coerceIn(l + minS, 1f); b = (b + dy).coerceIn(t + minS, 1f) }
                                    DragMode.N -> { t = (t + dy).coerceIn(0f, b - minS) }
                                    DragMode.S -> { b = (b + dy).coerceIn(t + minS, 1f) }
                                    DragMode.W -> { l = (l + dx).coerceIn(0f, r - minS) }
                                    DragMode.E -> { r = (r + dx).coerceIn(l + minS, 1f) }
                                    DragMode.NONE -> return@detectDragGestures
                                }
                                cropRect = CropRectNorm(l, t, r - l, b - t)
                            }
                        )
                    }
            ) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "PDF Page",
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier.fillMaxSize()
                )
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val l = cropRect.left * size.width
                    val t = cropRect.top * size.height
                    val w = cropRect.width * size.width
                    val h = cropRect.height * size.height

                    // Dark scrim outside crop region
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset.Zero, Size(size.width, t))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, t + h), Size(size.width, size.height - (t + h)))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(0f, t), Size(l, h))
                    drawRect(Color.Black.copy(alpha = 0.45f), Offset(l + w, t), Size(size.width - (l + w), h))

                    // Crop rectangle border
                    drawRect(Color(0xFF2563EB), Offset(l, t), Size(w, h), style = Stroke(width = 4f))

                    // 4 Corner handles + 4 Edge handles
                    val handles = listOf(
                        Offset(l, t), Offset(l + w, t), Offset(l, t + h), Offset(l + w, t + h),
                        Offset(l + w / 2f, t), Offset(l + w / 2f, t + h), Offset(l, t + h / 2f), Offset(l + w, t + h / 2f)
                    )
                    handles.forEach { pt ->
                        drawCircle(Color(0xFF2563EB), radius = 12f, center = pt)
                        drawCircle(Color.White, radius = 6f, center = pt)
                    }
                }
            }
        }

        // Live Crop Preview Card
        liveCroppedBitmap?.let { previewBmp ->
            Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Live Crop Preview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Image(
                        bitmap = previewBmp.asImageBitmap(),
                        contentDescription = "Live Cropped Preview",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            }
        }

        // Page Scope Selector: All Pages / Current Page / Selected Pages
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = pageScope == CropPageScope.ALL_PAGES,
                onClick = { pageScope = CropPageScope.ALL_PAGES },
                label = { Text("All Pages") }
            )
            FilterChip(
                selected = pageScope == CropPageScope.CURRENT_PAGE,
                onClick = { pageScope = CropPageScope.CURRENT_PAGE },
                label = { Text("Current Page") }
            )
            FilterChip(
                selected = pageScope == CropPageScope.SELECTED_PAGES,
                onClick = { pageScope = CropPageScope.SELECTED_PAGES },
                label = { Text("Selected") }
            )
        }
        if (pageScope == CropPageScope.SELECTED_PAGES) {
            OutlinedTextField(
                value = selectedRangeText,
                onValueChange = { selectedRangeText = it },
                label = { Text("Selected Pages (e.g. 1-2, 4)") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Rename Output PDF + Choose Save Location via SAF
        OutlinedTextField(
            value = outputFileName,
            onValueChange = { outputFileName = it },
            label = { Text("Output PDF Name (Never overwrites original)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            enabled = sourceFile != null && !isBusy,
            onClick = { saveCroppedLauncher.launch(outputFileName.ifBlank { "Cropped.pdf" }) },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.Default.SaveAs, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (isBusy) "Cropping PDF..." else "Choose Save Location & Export Cropped PDF")
        }

        if (statusText.isNotEmpty()) {
            Text(statusText, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
