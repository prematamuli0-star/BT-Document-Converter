package com.btdocument.suite.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.hwpf.HWPFDocument
import org.apache.poi.hwpf.extractor.WordExtractor
import org.apache.poi.xwpf.usermodel.XWPFDocument

@Composable
fun DocumentViewerScreen(uri: Uri, displayName: String) {
    val context = LocalContext.current
    var pages by remember(uri) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var wordText by remember(uri) { mutableStateOf<String?>(null) }
    var errorMessage by remember(uri) { mutableStateOf<String?>(null) }
    var loading by remember(uri) { mutableStateOf(true) }

    LaunchedEffect(uri) {
        loading = true
        errorMessage = null
        try {
            val result = withContext(Dispatchers.IO) {
                val lower = displayName.lowercase()
                if (lower.endsWith(".pdf") || context.contentResolver.getType(uri) == "application/pdf") {
                    val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r")
                        ?: error("Cannot open this PDF file")
                    pfd.use { descriptor ->
                        PdfRenderer(descriptor).use { renderer ->
                            val output = mutableListOf<Bitmap>()
                            val count = minOf(renderer.pageCount, 30)
                            for (index in 0 until count) {
                                renderer.openPage(index).use { page ->
                                    val scale = (1200f / page.width).coerceAtMost(2f)
                                    val bitmap = Bitmap.createBitmap(
                                        (page.width * scale).toInt().coerceAtLeast(1),
                                        (page.height * scale).toInt().coerceAtLeast(1),
                                        Bitmap.Config.ARGB_8888
                                    )
                                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    output.add(bitmap)
                                }
                            }
                            Pair(output, null as String?)
                        }
                    }
                } else {
                    val text = context.contentResolver.openInputStream(uri)?.use { input ->
                        if (lower.endsWith(".doc")) {
                            WordExtractor(HWPFDocument(input)).use { it.text }
                        } else {
                            XWPFDocument(input).use { doc ->
                                doc.paragraphs.joinToString("\n\n") { it.text } +
                                    doc.tables.joinToString("\n\n") { table ->
                                        table.rows.joinToString("\n") { row ->
                                            row.tableCells.joinToString("   |   ") { cell -> cell.text }
                                        }
                                    }
                            }
                        }
                    } ?: error("Cannot read this Word document")
                    Pair(emptyList<Bitmap>(), text)
                }
            }
            pages = result.first
            wordText = result.second
        } catch (t: Throwable) {
            errorMessage = t.message ?: "This file could not be opened."
        } finally {
            loading = false
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text(displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        when {
            loading -> CircularProgressIndicator()
            errorMessage != null -> Text("Unable to open document: $errorMessage", color = MaterialTheme.colorScheme.error)
            wordText != null -> LazyColumn(Modifier.fillMaxSize()) {
                item { Text(wordText.orEmpty(), style = MaterialTheme.typography.bodyLarge) }
            }
            pages.isNotEmpty() -> LazyColumn(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(pages) { bitmap ->
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "PDF page",
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (pages.size == 30) {
                    item {
                        Text("Showing the first 30 pages in this preview.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
