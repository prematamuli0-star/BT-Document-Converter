package com.btdocument.suite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.btdocument.suite.model.RecentDocumentRecord
import com.btdocument.suite.model.ToolCardMeta
import com.btdocument.suite.model.ToolType
import com.btdocument.suite.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            MaterialTheme {
                BTDocumentApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BTDocumentApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeTool by remember { mutableStateOf<ToolType?>(null) }
    var recentRecords by remember { mutableStateOf<List<RecentDocumentRecord>>(emptyList()) }

    val toolCards = remember {
        listOf(
            ToolCardMeta(ToolType.TEXT_TO_PDF, "01", Icons.Default.Description),
            ToolCardMeta(ToolType.EXCEL_TO_PDF, "02", Icons.Default.TableChart),
            ToolCardMeta(ToolType.PDF_CROP, "03", Icons.Default.Crop),
            ToolCardMeta(ToolType.PDF_SPLIT, "04", Icons.Default.ContentCut),
            ToolCardMeta(ToolType.PDF_MERGE, "05", Icons.Default.Layers),
            ToolCardMeta(ToolType.SIGN_PDF, "06", Icons.Default.Draw),
            ToolCardMeta(ToolType.PDF_TO_WORD, "07", Icons.Default.Article),
            ToolCardMeta(ToolType.WORD_TO_PDF, "08", Icons.Default.PictureAsPdf),
            ToolCardMeta(ToolType.PDF_PASSWORD, "09", Icons.Default.Lock)
        )
    }

    val recordOutput: (RecentDocumentRecord) -> Unit = { rec ->
        recentRecords = listOf(rec) + recentRecords
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        activeTool?.title ?: "BT Document",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (activeTool != null) {
                        IconButton(onClick = { activeTool = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "All 9 Tools") },
                    label = { Text("All 9 Tools") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1; activeTool = null },
                    icon = { Icon(Icons.Default.History, contentDescription = "Recent Used") },
                    label = { Text("Recent (${recentRecords.size})") }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (selectedTab == 1) {
                RecentUsedScreen(
                    records = recentRecords,
                    onClear = { recentRecords = emptyList() }
                )
            } else when (activeTool) {
                null -> LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(toolCards) { card ->
                        ElevatedCard(
                            onClick = { activeTool = card.type },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Icon(card.icon, contentDescription = card.type.title, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("${card.number}. ${card.type.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(card.type.subtitle, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                ToolType.TEXT_TO_PDF -> TextToPdfScreen(recordOutput)
                ToolType.EXCEL_TO_PDF -> ExcelToPdfScreen(recordOutput)
                ToolType.PDF_CROP -> PdfCropScreen(recordOutput)
                ToolType.PDF_SPLIT -> PdfSplitScreen(recordOutput)
                ToolType.PDF_MERGE -> PdfMergeScreen(recordOutput)
                ToolType.SIGN_PDF -> SignPdfScreen(recordOutput)
                ToolType.PDF_TO_WORD -> PdfToWordScreen(recordOutput)
                ToolType.WORD_TO_PDF -> WordToPdfScreen(recordOutput)
                ToolType.PDF_PASSWORD -> PdfPasswordScreen(recordOutput)
            }
        }
    }
}
