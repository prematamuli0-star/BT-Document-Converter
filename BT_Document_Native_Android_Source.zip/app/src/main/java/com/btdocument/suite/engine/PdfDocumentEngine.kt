package com.btdocument.suite.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.multipdf.LayerUtility
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.btdocument.suite.model.CropRectNorm
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xwpf.usermodel.XWPFDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Complete Native Android Document Engine covering all 9 BT Document tools.
 * Non-destructive: Always reads from source Uri into memory/temp files and writes
 * output to a user-chosen destination Uri (never overwriting the original file).
 */
object PdfDocumentEngine {

    private fun sanitizePdfText(raw: String): String =
        raw.replace("→", "->")
            .replace("←", "<-")
            .replace("•", "*")
            .replace("—", "--")
            .replace("–", "-")
            .replace(Regex("""[^\x20-\x7E\xA0-\xFF]"""), " ")

    fun copyUriToTempFile(context: Context, uri: Uri, prefix: String, ext: String): File {
        val temp = File.createTempFile(prefix, ext, context.cacheDir)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        } ?: error("Unable to open input stream for $uri")
        return temp
    }

    fun writeFileToDestinationUri(context: Context, sourceFile: File, destUri: Uri): Long {
        context.contentResolver.openOutputStream(destUri)?.use { out ->
            sourceFile.inputStream().use { input -> input.copyTo(out) }
        } ?: error("Unable to write to destination Uri: $destUri")
        return sourceFile.length()
    }

    /**
     * Render any page (0-indexed) of a PDF File to an Android Bitmap using PdfRenderer.
     */
    fun renderPdfPageBitmap(pdfFile: File, pageIndex: Int, scale: Float = 1.5f): Pair<Bitmap, Int> {
        ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                val count = renderer.pageCount
                val safeIndex = pageIndex.coerceIn(0, (count - 1).coerceAtLeast(0))
                renderer.openPage(safeIndex).use { page ->
                    val w = (page.width * scale).toInt().coerceAtLeast(100)
                    val h = (page.height * scale).toInt().coerceAtLeast(100)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return Pair(bmp, count)
                }
            }
        }
    }

    // 1. Text to PDF (Multi-page word wrap)
    fun createPdfFromText(title: String, body: String, fontSize: Float, isLetter: Boolean, outFile: File) {
        val pageSize = if (isLetter) PDRectangle.LETTER else PDRectangle.A4
        val margin = 48f
        val usableW = pageSize.width - margin * 2f
        val lineHeight = fontSize * 1.45f

        PDDocument().use { doc ->
            var page = PDPage(pageSize)
            doc.addPage(page)
            var stream = PDPageContentStream(doc, page)
            var y = pageSize.height - margin

            val cleanTitle = sanitizePdfText(title.trim())
            if (cleanTitle.isNotEmpty()) {
                stream.beginText()
                stream.setFont(PDType1Font.HELVETICA_BOLD, fontSize + 5f)
                stream.newLineAtOffset(margin, y)
                stream.showText(cleanTitle)
                stream.endText()
                y -= (fontSize + 24f)
            }

            for (para in sanitizePdfText(body).replace("\r\n", "\n").split("\n")) {
                if (para.isBlank()) {
                    y -= lineHeight * 0.7f
                    if (y < margin + lineHeight) {
                        stream.close()
                        page = PDPage(pageSize)
                        doc.addPage(page)
                        stream = PDPageContentStream(doc, page)
                        y = pageSize.height - margin
                    }
                    continue
                }
                val words = para.split(Regex("\\s+"))
                var currentLine = ""
                for (w in words) {
                    val candidate = if (currentLine.isEmpty()) w else "$currentLine $w"
                    val width = PDType1Font.HELVETICA.getStringWidth(candidate) / 1000f * fontSize
                    if (width > usableW && currentLine.isNotEmpty()) {
                        if (y < margin + lineHeight) {
                            stream.close()
                            page = PDPage(pageSize)
                            doc.addPage(page)
                            stream = PDPageContentStream(doc, page)
                            y = pageSize.height - margin
                        }
                        stream.beginText()
                        stream.setFont(PDType1Font.HELVETICA, fontSize)
                        stream.newLineAtOffset(margin, y)
                        stream.showText(currentLine)
                        stream.endText()
                        y -= lineHeight
                        currentLine = w
                    } else {
                        currentLine = candidate
                    }
                }
                if (currentLine.isNotEmpty()) {
                    if (y < margin + lineHeight) {
                        stream.close()
                        page = PDPage(pageSize)
                        doc.addPage(page)
                        stream = PDPageContentStream(doc, page)
                        y = pageSize.height - margin
                    }
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, fontSize)
                    stream.newLineAtOffset(margin, y)
                    stream.showText(currentLine)
                    stream.endText()
                    y -= lineHeight
                }
            }
            stream.close()
            doc.save(outFile)
        }
    }

    // 2. Excel (.xlsx / .xls) to PDF using Apache POI WorkbookFactory
    fun convertExcelToPdf(excelFile: File, title: String, landscape: Boolean, outFile: File) {
        val rows = mutableListOf<List<String>>()
        excelFile.inputStream().use { input ->
            val wb = WorkbookFactory.create(input)
            val sheet = wb.getSheetAt(0)
            for (row in sheet) {
                val cells = (0 until row.lastCellNum.coerceAtLeast(1)).map { idx ->
                    row.getCell(idx)?.toString() ?: ""
                }
                if (cells.any { it.isNotBlank() }) rows.add(cells)
            }
            wb.close()
        }

        val pageSize = if (landscape) PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width) else PDRectangle.A4
        val margin = 36f
        val usableW = pageSize.width - margin * 2f
        val colCount = rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val colW = usableW / colCount
        val rowH = 22f

        PDDocument().use { doc ->
            var page = PDPage(pageSize)
            doc.addPage(page)
            var stream = PDPageContentStream(doc, page)
            var y = pageSize.height - margin

            stream.beginText()
            stream.setFont(PDType1Font.HELVETICA_BOLD, 14f)
            stream.newLineAtOffset(margin, y)
            stream.showText(sanitizePdfText(title))
            stream.endText()
            y -= 28f

            rows.forEachIndexed { rIdx, row ->
                if (y - rowH < margin) {
                    stream.close()
                    page = PDPage(pageSize)
                    doc.addPage(page)
                    stream = PDPageContentStream(doc, page)
                    y = pageSize.height - margin
                }
                val isHeader = rIdx == 0
                if (isHeader) {
                    stream.setNonStrokingColor(23, 56, 133)
                    stream.addRect(margin, y - rowH, usableW, rowH)
                    stream.fill()
                } else if (rIdx % 2 == 1) {
                    stream.setNonStrokingColor(244, 246, 250)
                    stream.addRect(margin, y - rowH, usableW, rowH)
                    stream.fill()
                }
                stream.setNonStrokingColor(if (isHeader) 255 else 38, if (isHeader) 255 else 51, if (isHeader) 255 else 71)
                for (cIdx in 0 until colCount) {
                    val cell = sanitizePdfText(row.getOrElse(cIdx) { "" }).take(24)
                    stream.beginText()
                    stream.setFont(if (isHeader) PDType1Font.HELVETICA_BOLD else PDType1Font.HELVETICA, 9f)
                    stream.newLineAtOffset(margin + cIdx * colW + 4f, y - rowH + 6f)
                    stream.showText(cell)
                    stream.endText()
                }
                y -= rowH
            }
            stream.close()
            doc.save(outFile)
        }
    }

    // 3. Permanent PDF Photo-Style Crop (Creates separate output file, never alters inputFile)
    fun cropPdfPermanent(
        inputFile: File,
        outputFile: File,
        crop: CropRectNorm,
        targetPagesOneBased: Set<Int>
    ) {
        PDDocument.load(inputFile).use { srcDoc ->
            PDDocument().use { outDoc ->
                val layerUtil = LayerUtility(outDoc)
                for (i in 0 until srcDoc.numberOfPages) {
                    val pageNum = i + 1
                    val srcPage = srcDoc.getPage(i)
                    if (!targetPagesOneBased.contains(pageNum)) {
                        val imported = outDoc.importPage(srcPage)
                        imported.cropBox = srcPage.cropBox
                        continue
                    }

                    val box = srcPage.cropBox ?: srcPage.mediaBox
                    val cropX = box.lowerLeftX + crop.left * box.width
                    val cropW = (crop.width * box.width).coerceIn(24f, box.width - crop.left * box.width)
                    val cropH = (crop.height * box.height).coerceIn(24f, box.height - crop.top * box.height)
                    val cropY = (box.lowerLeftY + box.height - (crop.top + crop.height) * box.height)
                        .coerceAtLeast(box.lowerLeftY)

                    // Import as Form XObject and clip permanently onto a fresh [0, 0, cropW, cropH] page
                    val form = layerUtil.importPageAsForm(srcDoc, i)
                    val newPage = PDPage(PDRectangle(0f, 0f, cropW, cropH))
                    newPage.mediaBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.cropBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.trimBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.bleedBox = PDRectangle(0f, 0f, cropW, cropH)
                    newPage.artBox = PDRectangle(0f, 0f, cropW, cropH)
                    outDoc.addPage(newPage)

                    PDPageContentStream(outDoc, newPage).use { cs ->
                        cs.saveGraphicsState()
                        cs.addRect(0f, 0f, cropW, cropH)
                        cs.clip()
                        cs.transform(com.tom_roush.pdfbox.util.Matrix.getTranslateInstance(-cropX, -cropY))
                        cs.drawForm(form)
                        cs.restoreGraphicsState()
                    }
                }
                outDoc.save(outputFile)
            }
        }
    }

    // 4. PDF Page Split (Single PDF or ZIP of single pages)
    fun parsePageRange(rangeStr: String, maxPages: Int): List<Int> {
        val out = linkedSetOf<Int>()
        rangeStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            if (part.contains("-")) {
                val bounds = part.split("-").mapNotNull { it.trim().toIntOrNull() }
                if (bounds.size == 2) {
                    val s = minOf(bounds[0], bounds[1]).coerceIn(1, maxPages)
                    val e = maxOf(bounds[0], bounds[1]).coerceIn(1, maxPages)
                    for (p in s..e) out.add(p)
                }
            } else {
                part.toIntOrNull()?.let { if (it in 1..maxPages) out.add(it) }
            }
        }
        return out.sorted()
    }

    fun splitPdf(inputFile: File, pagesOneBased: List<Int>, asZip: Boolean, outFile: File) {
        PDDocument.load(inputFile).use { src ->
            if (!asZip || pagesOneBased.size <= 1) {
                PDDocument().use { outDoc ->
                    pagesOneBased.forEach { pNum ->
                        outDoc.importPage(src.getPage((pNum - 1).coerceIn(0, src.numberOfPages - 1)))
                    }
                    outDoc.save(outFile)
                }
            } else {
                ZipOutputStream(FileOutputStream(outFile)).use { zos ->
                    pagesOneBased.forEach { pNum ->
                        val splitter = Splitter().apply { setStartPage(pNum); setEndPage(pNum) }
                        val single = splitter.split(src).firstOrNull()
                        single?.use { doc ->
                            val baos = ByteArrayOutputStream()
                            doc.save(baos)
                            zos.putNextEntry(ZipEntry("page_$pNum.pdf"))
                            zos.write(baos.toByteArray())
                            zos.closeEntry()
                        }
                    }
                }
            }
        }
    }

    // 5. PDF Merge
    fun mergePdfs(inputs: List<File>, outputFile: File) {
        val merger = PDFMergerUtility()
        inputs.forEach { merger.addSource(it) }
        merger.destinationFileName = outputFile.absolutePath
        merger.mergeDocuments(null)
    }

    // 6. Sign PDF with Wet-Ink Bitmap Signature
    fun signPdf(inputFile: File, signatureBitmap: Bitmap, signerName: String, pageOneBased: Int, xRatio: Float, yRatio: Float, outputFile: File) {
        PDDocument.load(inputFile).use { doc ->
            val page = doc.getPage((pageOneBased - 1).coerceIn(0, doc.numberOfPages - 1))
            val media = page.cropBox ?: page.mediaBox
            val sigW = 145f
            val sigH = sigW * (signatureBitmap.height.toFloat() / signatureBitmap.width.coerceAtLeast(1))
            val drawX = (media.lowerLeftX + xRatio * media.width).coerceIn(16f, media.width - sigW - 16f)
            val drawY = (media.lowerLeftY + media.height - yRatio * media.height - sigH).coerceIn(24f, media.height - sigH - 16f)

            val pdImage = LosslessFactory.createFromImage(doc, signatureBitmap)
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { stream ->
                stream.drawImage(pdImage, drawX, drawY, sigW, sigH)
                if (signerName.isNotBlank()) {
                    stream.beginText()
                    stream.setFont(PDType1Font.HELVETICA, 7.5f)
                    stream.setNonStrokingColor(30, 70, 165)
                    stream.newLineAtOffset(drawX, (drawY - 11f).coerceAtLeast(10f))
                    stream.showText(sanitizePdfText("Digitally Signed by $signerName"))
                    stream.endText()
                }
            }
            doc.save(outputFile)
        }
    }

    // 7. PDF to Word (.docx)
    fun convertPdfToWord(pdfFile: File, title: String, outDocxFile: File) {
        PDDocument.load(pdfFile).use { pdf ->
            val stripper = PDFTextStripper()
            XWPFDocument().use { docx ->
                val titlePara = docx.createParagraph()
                titlePara.createRun().apply {
                    isBold = true
                    fontSize = 16
                    setText(title)
                }
                for (p in 1..pdf.numberOfPages) {
                    stripper.startPage = p
                    stripper.endPage = p
                    val pageText = stripper.getText(pdf)
                    docx.createParagraph().createRun().apply {
                        isBold = true
                        color = "1D4ED8"
                        setText("Page $p")
                    }
                    pageText.lines().filter { it.isNotBlank() }.forEach { line ->
                        docx.createParagraph().createRun().setText(line)
                    }
                }
                FileOutputStream(outDocxFile).use { docx.write(it) }
            }
        }
    }

    // 8. Word (.docx) to PDF
    fun convertWordToPdf(docxFile: File, title: String, outPdfFile: File) {
        val textBuilder = StringBuilder()
        docxFile.inputStream().use { input ->
            XWPFDocument(input).use { docx ->
                docx.paragraphs.forEach { p ->
                    if (p.text.isNotBlank()) textBuilder.appendLine(p.text)
                }
            }
        }
        createPdfFromText(title, textBuilder.toString(), 11f, false, outPdfFile)
    }

    // 9. PDF Password Protection (True ISO 32000 AES-256 StandardProtectionPolicy)
    fun protectPdf(
        inputFile: File,
        userPassword: String,
        ownerPassword: String,
        watermark: String,
        allowPrint: Boolean,
        allowCopy: Boolean,
        outputFile: File
    ) {
        PDDocument.load(inputFile).use { doc ->
            if (watermark.isNotBlank()) {
                for (page in doc.pages) {
                    val media = page.cropBox ?: page.mediaBox
                    PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                        cs.beginText()
                        cs.setFont(PDType1Font.HELVETICA_BOLD, 32f)
                        cs.setNonStrokingColor(210, 45, 55)
                        cs.setTextMatrix(com.tom_roush.pdfbox.util.Matrix.getRotateInstance(Math.toRadians(35.0), media.width * 0.2f, media.height * 0.35f))
                        cs.showText(sanitizePdfText(watermark.uppercase()))
                        cs.endText()
                    }
                }
            }
            val ap = AccessPermission().apply {
                setCanPrint(allowPrint)
                setCanExtractContent(allowCopy)
                setCanModify(false)
            }
            val policy = StandardProtectionPolicy(ownerPassword, userPassword, ap).apply {
                encryptionKeyLength = 256
                permissions = ap
            }
            doc.protect(policy)
            doc.save(outputFile)
        }
    }
}
