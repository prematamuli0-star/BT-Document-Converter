package com.btdocument.suite.model

import android.graphics.Bitmap

data class EditorPage(
    val text: String = "",
    val images: List<Bitmap> = emptyList()
)
