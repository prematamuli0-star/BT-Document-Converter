package com.btdocument.suite.model

import android.graphics.Bitmap

data class EditorImage(
    val bitmap: Bitmap,
    val x: Float = 0.08f,
    val y: Float = 0.12f,
    val width: Float = 0.42f,
    val height: Float = 0.24f
)

data class EditorPage(
    val text: String = "",
    val images: List<EditorImage> = emptyList()
)
