package com.btdocument.suite.model

import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolType(val id: String, val title: String, val subtitle: String) {
    TEXT_TO_PDF("text_pdf", "Text to PDF", "Paginated A4 or Letter PDF"),
    EXCEL_TO_PDF("excel_pdf", "Excel to PDF", "Tabular .xlsx/.xls reports"),
    PDF_CROP("pdf_crop", "PDF Crop (Photo Style)", "4 corners + 4 edges + live preview"),
    PDF_SPLIT("pdf_split", "PDF Page Split", "Extract ranges to PDF or ZIP"),
    PDF_MERGE("pdf_merge", "PDF Merge", "Combine multiple PDFs in order"),
    SIGN_PDF("sign_pdf", "Sign PDF", "Touch wet-ink signature stamp"),
    PDF_TO_WORD("pdf_word", "PDF to Word", "Export editable .docx files"),
    WORD_TO_PDF("word_pdf", "Word to PDF", "Convert .docx into PDF 1.7"),
    PDF_PASSWORD("pdf_lock", "PDF Password", "AES-256 lock & watermark")
}

data class ToolCardMeta(
    val type: ToolType,
    val number: String,
    val icon: ImageVector
)

data class CropRectNorm(
    val left: Float = 0.06f,
    val top: Float = 0.06f,
    val width: Float = 0.88f,
    val height: Float = 0.88f
)

enum class CropPageScope {
    ALL_PAGES,
    CURRENT_PAGE,
    SELECTED_PAGES
}

data class RecentDocumentRecord(
    val id: String,
    val displayName: String,
    val toolTitle: String,
    val uriString: String,
    val sizeBytes: Long,
    val timestampLabel: String,
    val summary: String
)
