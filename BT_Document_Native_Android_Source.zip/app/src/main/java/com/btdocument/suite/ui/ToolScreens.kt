package com.btdocument.suite.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.RecentDocumentRecord
import com.btdocument.suite.model.EditorPage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf(listOf(EditorPage())) }
    var activePage by remember { mutableIntStateOf(0) }
    var editorMode by remember { mutableStateOf("PDF") }
    var outName by remember { mutableStateOf("My_Document") }
    var fontSize by remember { mutableIntStateOf(16) }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) {
                val updated = pages.toMutableList()
                updated[activePage] = updated[activePage].copy(images = updated[activePage].images + bitmap)
                pages = updated
            }
        }
    }
    val openWordLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val importedText = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    org.apache.poi.xwpf.usermodel.XWPFDocument(input).use { doc ->
                        doc.paragraphs.joinToString("\\n") { it.text }
                    }
                }.orEmpty()
            }
            pages = listOf(EditorPage(text = importedText))
            activePage = 0
            editorMode = "Word"
            outName = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Edited_Document"
        }
    }
    val pdfSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".pdf", context.cacheDir)
            val content = pages.map { it.text to it.images }
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createPdfFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.pdf", "Text to PDF", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }
    val wordSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".docx", context.cacheDir)
            val content = pages.map { it.text to it.images }
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createDocxFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.docx", "Word Editor", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text("Document Editor", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = editorMode == "PDF", onClick = { editorMode = "PDF" }, label = { Text("PDF") })
            FilterChip(selected = editorMode == "Word", onClick = { editorMode = "Word" }, label = { Text("Word DOCX") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (editorMode == "Word") {
                OutlinedButton(onClick = { openWordLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Open DOCX") }
            }
            OutlinedButton(onClick = { imageLauncher.launch(arrayOf("image/png", "image/jpeg", "image/*")) }) { Text("Add Photo / PNG") }
            OutlinedButton(onClick = { pages = pages + EditorPage(); activePage = pages.lastIndex }) { Text("+ Add Page") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Page ${activePage + 1} of ${pages.size}")
            Spacer(Modifier.weight(1f))
            TextButton(enabled = activePage > 0, onClick = { activePage-- }) { Text("Previous") }
            TextButton(enabled = activePage < pages.lastIndex, onClick = { activePage++ }) { Text("Next") }
        }
        // Paper-like editable page surface. Text remains editable in the field;
        // inserted photos are shown on the same page and embedded on export.
        Card(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Page ${activePage + 1}", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                OutlinedTextField(
                    value = pages[activePage].text,
                    onValueChange = { value ->
                        val updated = pages.toMutableList()
                        updated[activePage] = updated[activePage].copy(text = value)
                        pages = updated
                    },
                    placeholder = { Text("Start typing here…") },
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                    minLines = 14,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(fontSize = fontSize.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                pages[activePage].images.forEachIndexed { imageIndex, bitmap ->
                    Image(
                        bitmap.asImageBitmap(),
                        contentDescription = "Inserted document image",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp)
                    )
                    TextButton(onClick = {
                        val updated = pages.toMutableList()
                        updated[activePage] = updated[activePage].copy(
                            images = updated[activePage].images.filterIndexed { i, _ -> i != imageIndex }
                        )
                        pages = updated
                    }) { Text("Remove Image") }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Font size")
            TextButton(onClick = { fontSize = (fontSize - 1).coerceAtLeast(10) }) { Text("A−") }
            Text("$fontSize")
            TextButton(onClick = { fontSize = (fontSize + 1).coerceAtMost(28) }) { Text("A+") }
        }
        OutlinedTextField(
            value = outName, onValueChange = { outName = it },
            label = { Text("File name") }, modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                val name = outName.ifBlank { "My_Document" }.let {
                    if (editorMode == "PDF") it.removeSuffix(".pdf").removeSuffix(".docx")
                    else it.removeSuffix(".docx").removeSuffix(".pdf")
                }
                if (editorMode == "PDF") pdfSaveLauncher.launch("$name.pdf")
                else wordSaveLauncher.launch("$name.docx")
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (editorMode == "PDF") "Export PDF" else "Save Word DOCX") }
    }
}

@Composable
fun ExcelToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var excelFile by remember { mutableStateOf<File?>(null) }
    var landscape by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("Spreadsheet_Report.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { excelFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "xls_", ".xlsx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = excelFile
        if (uri != null && src != null) {
            scope.launch {
                val outTemp = File.createTempFile("xls_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.convertExcelToPdf(src, outName.removeSuffix(".pdf"), landscape, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Excel to PDF", uri.toString(), bytes, "Just now", if (landscape) "Landscape" else "Portrait"))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }) {
            Text("Upload File")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
            FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = excelFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Export Spreadsheet to PDF") }
    }
}

@Composable
fun PdfSplitScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var rangeStr by remember { mutableStateOf("1") }
    var asZip by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "split_", ".pdf") }
            val (_, count) = withContext(Dispatchers.IO) { PdfDocumentEngine.renderPdfPageBitmap(f, 0, 0.5f) }
            pdfFile = f; totalPages = count
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(if (asZip) "application/zip" else "application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val pages = PdfDocumentEngine.parsePageRange(rangeStr, totalPages.coerceAtLeast(1))
            val outTemp = File.createTempFile("split_out_", if (asZip) ".zip" else ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.splitPdf(src, pages, asZip, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), if (asZip) "Split_Pages.zip" else "Split_Pages.pdf", "PDF Split", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Page Split", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = rangeStr, onValueChange = { rangeStr = it }, label = { Text("Page Range (e.g. 1-2, 4)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !asZip, onClick = { asZip = false }, label = { Text("Single PDF") })
            FilterChip(selected = asZip, onClick = { asZip = true }, label = { Text("ZIP of Pages") })
        }
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(if (asZip) "Split_Pages.zip" else "Split_Pages.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Extract & Save") }
    }
}

@Composable
fun PdfMergeScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<Pair<String, File>>>(emptyList()) }
    var outName by remember { mutableStateOf("Merged_Document.pdf") }

    val addLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                uris.mapIndexed { idx, u -> "PDF #${files.size + idx + 1}" to PdfDocumentEngine.copyUriToTempFile(context, u, "merge_", ".pdf") }
            }
            files = files + loaded
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && files.isNotEmpty()) scope.launch {
            val outTemp = File.createTempFile("merged_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.mergePdfs(files.map { it.second }, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF Merge", uri.toString(), bytes, "Just now", "${files.size} files"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Merge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { addLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Merged Output Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = files.size >= 2, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Merge & Save PDF") }
    }
}

@Composable
fun SignPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var pdfPreview by remember { mutableStateOf<Bitmap?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var selectedPage by remember { mutableIntStateOf(1) }
    var signerName by remember { mutableStateOf("Authorized Signer") }
    val inkColors = listOf(
        "Blue" to Color(0xFF1D4ED8),
        "Black" to Color(0xFF111827),
        "Red" to Color(0xFFDC2626),
        "Green" to Color(0xFF15803D),
        "Purple" to Color(0xFF7E22CE),
        "Navy" to Color(0xFF1E3A8A)
    )
    var selectedInkColor by remember { mutableStateOf(inkColors[0].second) }
    var strokes by remember { mutableStateOf<List<List<androidx.compose.ui.geometry.Offset>>>(emptyList()) }
    var currentStroke by remember { mutableStateOf<List<androidx.compose.ui.geometry.Offset>>(emptyList()) }
    var selectionStart by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
    var selectionEnd by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
    var previewSize by remember { mutableStateOf(androidx.compose.ui.geometry.Size.Zero) }
    var loadingPreview by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val copied = withContext(Dispatchers.IO) {
                PdfDocumentEngine.copyUriToTempFile(context, uri, "sign_", ".pdf")
            }
            pdfFile = copied
            selectedPage = 1
            loadingPreview = true
            val rendered = withContext(Dispatchers.IO) {
                val descriptor = ParcelFileDescriptor.open(copied, ParcelFileDescriptor.MODE_READ_ONLY)
                descriptor.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pageCount = renderer.pageCount
                        renderer.openPage(0).use { page ->
                            val scale = (1200f / page.width).coerceAtMost(2f)
                            Bitmap.createBitmap(
                                (page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1),
                                Bitmap.Config.ARGB_8888
                            ).also { bmp ->
                                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            }
                        }
                    }
                }
            }
            pdfPreview = rendered
            selectionStart = null
            selectionEnd = null
            loadingPreview = false
            strokes = emptyList()
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        val start = selectionStart
        val finish = selectionEnd
        val size = previewSize
        if (uri != null && src != null && start != null && finish != null && size.width > 0f && size.height > 0f) scope.launch {
            val bmp = Bitmap.createBitmap(600, 220, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(bmp)
            val paint = Paint().apply {
                color = android.graphics.Color.argb(255, (selectedInkColor.red * 255).toInt(), (selectedInkColor.green * 255).toInt(), (selectedInkColor.blue * 255).toInt())
                strokeWidth = 6f
                style = Paint.Style.STROKE
                isAntiAlias = true
                strokeCap = Paint.Cap.ROUND
            }
            strokes.forEach { pts ->
                if (pts.size > 1) {
                    val path = AndroidPath().apply {
                        moveTo(pts[0].x, pts[0].y)
                        pts.drop(1).forEach { lineTo(it.x, it.y) }
                    }
                    canvas.drawPath(path, paint)
                }
            }
            val outTemp = File.createTempFile("signed_", ".pdf", context.cacheDir)
            val left = minOf(start.x, finish.x) / size.width
            val top = minOf(start.y, finish.y) / size.height
            val width = kotlin.math.abs(finish.x - start.x) / size.width
            val height = kotlin.math.abs(finish.y - start.y) / size.height
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.signPdf(
                    src, bmp, signerName, selectedPage,
                    left, top, width.coerceIn(0.08f, 0.9f), outTemp
                )
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(
                RecentDocumentRecord(
                    System.currentTimeMillis().toString(),
                    "Signed_Document.pdf", "Sign PDF", uri.toString(),
                    bytes, "Just now", signerName
                )
            )
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Sign PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) {
            Text(if (pdfFile == null) "Upload File" else "Change PDF")
        }
        if (loadingPreview) {
            CircularProgressIndicator()
        }
        pdfPreview?.let { pageBitmap ->
            Text("1. Preview PDF — drag on the page to select signature area")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Page $selectedPage of $pageCount")
                Spacer(Modifier.weight(1f))
                TextButton(
                    enabled = selectedPage > 1,
                    onClick = {
                        selectedPage--
                        scope.launch {
                            val file = pdfFile ?: return@launch
                            pdfPreview = withContext(Dispatchers.IO) {
                                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                                pfd.use { fd -> PdfRenderer(fd).use { renderer ->
                                    renderer.openPage(selectedPage - 1).use { page ->
                                        val scale = (1200f / page.width).coerceAtMost(2f)
                                        Bitmap.createBitmap((page.width * scale).toInt(), (page.height * scale).toInt(), Bitmap.Config.ARGB_8888)
                                            .also { page.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) }
                                    }
                                } }
                            }
                            selectionStart = null; selectionEnd = null
                        }
                    }
                ) { Text("Previous") }
                TextButton(
                    enabled = selectedPage < pageCount,
                    onClick = {
                        selectedPage++
                        scope.launch {
                            val file = pdfFile ?: return@launch
                            pdfPreview = withContext(Dispatchers.IO) {
                                val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                                pfd.use { fd -> PdfRenderer(fd).use { renderer ->
                                    renderer.openPage(selectedPage - 1).use { page ->
                                        val scale = (1200f / page.width).coerceAtMost(2f)
                                        Bitmap.createBitmap((page.width * scale).toInt(), (page.height * scale).toInt(), Bitmap.Config.ARGB_8888)
                                            .also { page.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) }
                                    }
                                } }
                            }
                            selectionStart = null; selectionEnd = null
                        }
                    }
                ) { Text("Next") }
            }
            BoxWithConstraints(
                Modifier.fillMaxWidth().background(Color(0xFFEFEFEF)).border(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                val w = constraints.maxWidth.toFloat()
                val h = if (pageBitmap.width > 0) w * pageBitmap.height / pageBitmap.width else 0f
                Box(
                    Modifier.fillMaxWidth().height(with(androidx.compose.ui.platform.LocalDensity.current) { h.toDp() })
                        .pointerInput(selectedPage, pageBitmap) {
                            detectDragGestures(
                                onDragStart = { selectionStart = it; selectionEnd = it },
                                onDrag = { change, _ -> change.consume(); selectionEnd = change.position }
                            )
                        }
                ) {
                    Image(pageBitmap.asImageBitmap(), contentDescription = "PDF page preview", modifier = Modifier.fillMaxSize())
                    Canvas(Modifier.fillMaxSize()) {
                        previewSize = size
                        val a = selectionStart
                        val b = selectionEnd
                        if (a != null && b != null) {
                            val left = minOf(a.x, b.x); val top = minOf(a.y, b.y)
                            val rectW = kotlin.math.abs(b.x - a.x); val rectH = kotlin.math.abs(b.y - a.y)
                            drawRect(Color(0x332563EB), androidx.compose.ui.geometry.Offset(left, top), androidx.compose.ui.geometry.Size(rectW, rectH))
                            drawRect(Color(0xFF2563EB), androidx.compose.ui.geometry.Offset(left, top), androidx.compose.ui.geometry.Size(rectW, rectH), style = Stroke(3f))
                        }
                    }
                }
            }
            Text("Blue box = signature placement area. Drag to choose the position and size.")
        }
        Text("2. Choose signature colour")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            inkColors.forEach { (label, color) ->
                FilterChip(
                    selected = selectedInkColor == color,
                    onClick = { selectedInkColor = color },
                    label = { Text(label) },
                    leadingIcon = {
                        Box(
                            Modifier.size(14.dp)
                                .background(color, androidx.compose.foundation.shape.CircleShape)
                        )
                    }
                )
            }
        }
        Text("3. Draw your signature")
        OutlinedTextField(
            value = signerName, onValueChange = { signerName = it },
            label = { Text("Signer Name") }, modifier = Modifier.fillMaxWidth()
        )
        Box(
            Modifier.fillMaxWidth().height(130.dp).background(Color.White)
                .border(1.dp, MaterialTheme.colorScheme.outline)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { currentStroke = listOf(it) },
                        onDrag = { change, _ -> change.consume(); currentStroke = currentStroke + change.position },
                        onDragEnd = { strokes = strokes + listOf(currentStroke); currentStroke = emptyList() }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                (strokes + listOf(currentStroke)).forEach { pts ->
                    if (pts.size > 1) {
                        val path = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                        drawPath(path, selectedInkColor, style = Stroke(width = 6f, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { strokes = emptyList() }) { Text("Clear Ink") }
            OutlinedButton(onClick = { selectionStart = null; selectionEnd = null }) { Text("Clear Area") }
        }
        Button(
            enabled = pdfFile != null && pdfPreview != null && strokes.isNotEmpty() &&
                selectionStart != null && selectionEnd != null &&
                kotlin.math.abs((selectionEnd?.x ?: 0f) - (selectionStart?.x ?: 0f)) > 12f &&
                kotlin.math.abs((selectionEnd?.y ?: 0f) - (selectionStart?.y ?: 0f)) > 12f,
            onClick = { saveLauncher.launch("Signed_Document.pdf") },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Sign & Save PDF") }
    }
}

@Composable
fun PdfToWordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Converted_Document.docx") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "p2w_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("p2w_out_", ".docx", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertPdfToWord(src, outName.removeSuffix(".docx"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF to Word", uri.toString(), bytes, "Just now", "DOCX Export"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF to Word (.docx)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output Word Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save .DOCX") }
    }
}

@Composable
fun WordToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docxFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Word_Export.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { docxFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "w2p_", ".docx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = docxFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("w2p_out_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertWordToPdf(src, outName.removeSuffix(".pdf"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Word to PDF", uri.toString(), bytes, "Just now", "DOCX -> PDF"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Word (.docx) to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = docxFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save PDF") }
    }
}

@Composable
fun PdfPasswordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var userPwd by remember { mutableStateOf("") }
    var ownerPwd by remember { mutableStateOf("") }
    var watermark by remember { mutableStateOf("CONFIDENTIAL") }
    var allowPrint by remember { mutableStateOf(true) }
    var allowCopy by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "lock_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("locked_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.protectPdf(src, userPwd, ownerPwd.ifBlank { userPwd }, watermark, allowPrint, allowCopy, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Protected_Document.pdf", "PDF Password", uri.toString(), bytes, "Just now", "AES-256 Encrypted"))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Password Protection (AES-256)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = userPwd, onValueChange = { userPwd = it }, label = { Text("User Open Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ownerPwd, onValueChange = { ownerPwd = it }, label = { Text("Owner Permissions Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = watermark, onValueChange = { watermark = it }, label = { Text("Diagonal Watermark") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowPrint, onCheckedChange = { allowPrint = it }); Text("Allow Printing") }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowCopy, onCheckedChange = { allowCopy = it }); Text("Allow Copy") }
        Button(enabled = pdfFile != null && userPwd.isNotBlank(), onClick = { saveLauncher.launch("Protected_Document.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Encrypt & Save PDF") }
    }
}

@Composable
fun RecentUsedScreen(records: List<RecentDocumentRecord>, onClear: () -> Unit, onOpen: (RecentDocumentRecord) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Recent Used Files (${records.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (records.isNotEmpty()) { TextButton(onClick = onClear) { Text("Clear") } }
        }
        if (records.isEmpty()) {
            Text("Processed documents will appear here for one-tap access.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { item ->
                    ElevatedCard(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.displayName, fontWeight = FontWeight.SemiBold)
                            Text("${item.toolTitle} · ${item.summary} · ${item.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
