package com.btdocument.suite.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.RecentDocumentRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("Executive Project Brief") }
    var body by remember { mutableStateOf("Type or paste your notes here to convert to PDF.") }
    var isLetter by remember { mutableStateOf(false) }
    var outName by remember { mutableStateOf("Text_Document.pdf") }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            scope.launch {
                val outTemp = File.createTempFile("txt_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.createPdfFromText(title, body, 11f, isLetter, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Text to PDF", uri.toString(), bytes, "Just now", if (isLetter) "Letter" else "A4"))
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Text to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Document Heading") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Text Content") }, minLines = 6, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !isLetter, onClick = { isLetter = false }, label = { Text("A4") })
            FilterChip(selected = isLetter, onClick = { isLetter = true }, label = { Text("Letter") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output File Name") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Choose Save Location & Export PDF") }
    }
}

@Composable
fun ExcelToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var excelFile by remember { mutableStateOf<File?>(null) }
    var landscape by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("Spreadsheet_Report.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { excelFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "xls_", ".xlsx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = excelFile
        if (uri != null && src != null) {
            scope.launch {
                val outTemp = File.createTempFile("xls_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.convertExcelToPdf(src, outName.removeSuffix(".pdf"), landscape, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Excel to PDF", uri.toString(), bytes, "Just now", if (landscape) "Landscape" else "Portrait"))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }) {
            Text(if (excelFile == null) "Select .XLSX / .XLS File" else "Spreadsheet Loaded")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
            FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = excelFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Export Spreadsheet to PDF") }
    }
}

@Composable
fun PdfSplitScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var rangeStr by remember { mutableStateOf("1") }
    var asZip by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "split_", ".pdf") }
            val (_, count) = withContext(Dispatchers.IO) { PdfDocumentEngine.renderPdfPageBitmap(f, 0, 0.5f) }
            pdfFile = f; totalPages = count
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(if (asZip) "application/zip" else "application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val pages = PdfDocumentEngine.parsePageRange(rangeStr, totalPages.coerceAtLeast(1))
            val outTemp = File.createTempFile("split_out_", if (asZip) ".zip" else ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.splitPdf(src, pages, asZip, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), if (asZip) "Split_Pages.zip" else "Split_Pages.pdf", "PDF Split", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Page Split", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "Loaded ($totalPages pages)") }
        OutlinedTextField(value = rangeStr, onValueChange = { rangeStr = it }, label = { Text("Page Range (e.g. 1-2, 4)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !asZip, onClick = { asZip = false }, label = { Text("Single PDF") })
            FilterChip(selected = asZip, onClick = { asZip = true }, label = { Text("ZIP of Pages") })
        }
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(if (asZip) "Split_Pages.zip" else "Split_Pages.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Extract & Save") }
    }
}

@Composable
fun PdfMergeScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<Pair<String, File>>>(emptyList()) }
    var outName by remember { mutableStateOf("Merged_Document.pdf") }

    val addLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                uris.mapIndexed { idx, u -> "PDF #${files.size + idx + 1}" to PdfDocumentEngine.copyUriToTempFile(context, u, "merge_", ".pdf") }
            }
            files = files + loaded
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && files.isNotEmpty()) scope.launch {
            val outTemp = File.createTempFile("merged_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.mergePdfs(files.map { it.second }, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF Merge", uri.toString(), bytes, "Just now", "${files.size} files"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Merge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { addLauncher.launch(arrayOf("application/pdf")) }) { Text("Add PDF Files (${files.size} queued)") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Merged Output Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = files.size >= 2, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Merge & Save PDF") }
    }
}

@Composable
fun SignPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var signerName by remember { mutableStateOf("Authorized Signer") }
    var strokes by remember { mutableStateOf<List<List<androidx.compose.ui.geometry.Offset>>>(emptyList()) }
    var currentStroke by remember { mutableStateOf<List<androidx.compose.ui.geometry.Offset>>(emptyList()) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "sign_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val bmp = Bitmap.createBitmap(600, 220, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(bmp)
            val paint = Paint().apply { color = android.graphics.Color.rgb(29, 78, 216); strokeWidth = 6f; style = Paint.Style.STROKE; isAntiAlias = true }
            strokes.forEach { pts ->
                if (pts.size > 1) {
                    val path = AndroidPath().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                    canvas.drawPath(path, paint)
                }
            }
            val outTemp = File.createTempFile("signed_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.signPdf(src, bmp, signerName, 1, 0.52f, 0.72f, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Signed_Document.pdf", "Sign PDF", uri.toString(), bytes, "Just now", signerName))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Sign PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "PDF Ready") }
        OutlinedTextField(value = signerName, onValueChange = { signerName = it }, label = { Text("Signer Name") }, modifier = Modifier.fillMaxWidth())
        Box(
            Modifier.fillMaxWidth().height(150.dp).background(Color.White).border(1.dp, MaterialTheme.colorScheme.outline)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { currentStroke = listOf(it) },
                        onDrag = { change, _ -> change.consume(); currentStroke = currentStroke + change.position },
                        onDragEnd = { strokes = strokes + listOf(currentStroke); currentStroke = emptyList() }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                (strokes + listOf(currentStroke)).forEach { pts ->
                    if (pts.size > 1) {
                        val p = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                        drawPath(p, Color(0xFF1D4ED8), style = Stroke(width = 6f, cap = StrokeCap.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { strokes = emptyList() }) { Text("Clear Ink") }
            Button(enabled = pdfFile != null && strokes.isNotEmpty(), onClick = { saveLauncher.launch("Signed_Document.pdf") }, modifier = Modifier.weight(1f)) { Text("Stamp & Save PDF") }
        }
    }
}

@Composable
fun PdfToWordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Converted_Document.docx") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "p2w_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("p2w_out_", ".docx", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertPdfToWord(src, outName.removeSuffix(".docx"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF to Word", uri.toString(), bytes, "Just now", "DOCX Export"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF to Word (.docx)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Select PDF" else "PDF Selected") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output Word Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save .DOCX") }
    }
}

@Composable
fun WordToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docxFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Word_Export.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { docxFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "w2p_", ".docx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = docxFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("w2p_out_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertWordToPdf(src, outName.removeSuffix(".pdf"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Word to PDF", uri.toString(), bytes, "Just now", "DOCX -> PDF"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Word (.docx) to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text(if (docxFile == null) "Select .DOCX File" else "Word File Ready") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = docxFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save PDF") }
    }
}

@Composable
fun PdfPasswordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var userPwd by remember { mutableStateOf("") }
    var ownerPwd by remember { mutableStateOf("") }
    var watermark by remember { mutableStateOf("CONFIDENTIAL") }
    var allowPrint by remember { mutableStateOf(true) }
    var allowCopy by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "lock_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("locked_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.protectPdf(src, userPwd, ownerPwd.ifBlank { userPwd }, watermark, allowPrint, allowCopy, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Protected_Document.pdf", "PDF Password", uri.toString(), bytes, "Just now", "AES-256 Encrypted"))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Password Protection (AES-256)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text(if (pdfFile == null) "Open PDF" else "PDF Ready") }
        OutlinedTextField(value = userPwd, onValueChange = { userPwd = it }, label = { Text("User Open Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ownerPwd, onValueChange = { ownerPwd = it }, label = { Text("Owner Permissions Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = watermark, onValueChange = { watermark = it }, label = { Text("Diagonal Watermark") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowPrint, onCheckedChange = { allowPrint = it }); Text("Allow Printing") }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowCopy, onCheckedChange = { allowCopy = it }); Text("Allow Copy") }
        Button(enabled = pdfFile != null && userPwd.isNotBlank(), onClick = { saveLauncher.launch("Protected_Document.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Encrypt & Save PDF") }
    }
}

@Composable
fun RecentUsedScreen(records: List<RecentDocumentRecord>, onClear: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Recent Used Files (${records.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (records.isNotEmpty()) { TextButton(onClick = onClear) { Text("Clear") } }
        }
        if (records.isEmpty()) {
            Text("Processed documents will appear here for one-tap access.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { item ->
                    ElevatedCard(onClick = {
                        runCatching {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse(item.uriString)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.displayName, fontWeight = FontWeight.SemiBold)
                            Text("${item.toolTitle} · ${item.summary} · ${item.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
