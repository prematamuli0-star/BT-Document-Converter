package com.btdocument.suite.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.RecentDocumentRecord
import com.btdocument.suite.model.EditorPage
import com.btdocument.suite.model.EditorImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf(listOf(EditorPage())) }
    var activePage by remember { mutableIntStateOf(0) }
    var editorMode by remember { mutableStateOf("PDF") }
    var outName by remember { mutableStateOf("My_Document") }
    var fontSize by remember { mutableIntStateOf(16) }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) {
                val updated = pages.toMutableList()
                updated[activePage] = updated[activePage].copy(images = updated[activePage].images + EditorImage(bitmap))
                pages = updated
            }
        }
    }
    val openWordLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val importedText = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    org.apache.poi.xwpf.usermodel.XWPFDocument(input).use { doc ->
                        doc.paragraphs.joinToString("\\n") { it.text }
                    }
                }.orEmpty()
            }
            pages = listOf(EditorPage(text = importedText))
            activePage = 0
            editorMode = "Word"
            outName = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Edited_Document"
        }
    }
    val pdfSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".pdf", context.cacheDir)
            val content = pages
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createPdfFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.pdf", "Text to PDF", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }
    val wordSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".docx", context.cacheDir)
            val content = pages
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createDocxFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.docx", "Word Editor", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text("Document Editor", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = editorMode == "PDF", onClick = { editorMode = "PDF" }, label = { Text("PDF") })
            FilterChip(selected = editorMode == "Word", onClick = { editorMode = "Word" }, label = { Text("Word DOCX") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (editorMode == "Word") {
                OutlinedButton(onClick = { openWordLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Open DOCX") }
            }
            OutlinedButton(onClick = { imageLauncher.launch(arrayOf("image/png", "image/jpeg", "image/*")) }) { Text("Add Photo / PNG") }
            OutlinedButton(onClick = { pages = pages + EditorPage(); activePage = pages.lastIndex }) { Text("+ Add Page") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Page ${activePage + 1} of ${pages.size}")
            Spacer(Modifier.weight(1f))
            TextButton(enabled = activePage > 0, onClick = { activePage-- }) { Text("Previous") }
            TextButton(enabled = activePage < pages.lastIndex, onClick = { activePage++ }) { Text("Next") }
        }
        // A4 sheet preview: exact portrait A4 proportion (210 x 297 mm).
        val density = LocalDensity.current
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            val paperWidth = maxWidth
            val paperHeight = paperWidth * (297f / 210f)
            Card(Modifier.width(paperWidth).height(paperHeight), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(4.dp), shape = RoundedCornerShape(3.dp)) {
                BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
                    val pw = maxWidth; val ph = maxHeight
                    Text("A4 • Page ${activePage + 1}", Modifier.align(Alignment.TopEnd), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = pages[activePage].text,
                        onValueChange = { value -> val u=pages.toMutableList(); u[activePage]=u[activePage].copy(text=value); pages=u },
                        placeholder = { Text("Start typing here…") },
                        modifier = Modifier.fillMaxSize().padding(top=18.dp),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize=fontSize.sp, color=Color.Black),
                        colors = OutlinedTextFieldDefaults.colors(focusedContainerColor=Color.Transparent, unfocusedContainerColor=Color.Transparent, focusedBorderColor=Color.Transparent, unfocusedBorderColor=Color.Transparent)
                    )
                    pages[activePage].images.forEachIndexed { imageIndex, item ->
                        Box(Modifier.offset(x=pw*item.x, y=ph*item.y).width(pw*item.width).height(ph*item.height)
                            .border(1.5.dp, Color(0xFF6750A4))
                            .pointerInput(activePage,imageIndex,pw,ph) { detectDragGestures { change, drag ->
                                change.consume(); val dx=with(density){drag.x.toDp().value}/pw.value.coerceAtLeast(1f); val dy=with(density){drag.y.toDp().value}/ph.value.coerceAtLeast(1f)
                                val u=pages.toMutableList(); val list=u[activePage].images.toMutableList(); val old=list[imageIndex]
                                list[imageIndex]=old.copy(x=(old.x+dx).coerceIn(0f,1f-old.width), y=(old.y+dy).coerceIn(0f,1f-old.height)); u[activePage]=u[activePage].copy(images=list); pages=u
                            } }) {
                            Image(item.bitmap.asImageBitmap(), "Inserted image", Modifier.fillMaxSize())
                            Box(Modifier.align(Alignment.BottomEnd).size(26.dp).background(Color(0xFF6750A4), RoundedCornerShape(topStart=6.dp))
                                .pointerInput(activePage,imageIndex,pw,ph) { detectDragGestures { change, drag ->
                                    change.consume(); val dx=with(density){drag.x.toDp().value}/pw.value.coerceAtLeast(1f); val dy=with(density){drag.y.toDp().value}/ph.value.coerceAtLeast(1f)
                                    val u=pages.toMutableList(); val list=u[activePage].images.toMutableList(); val old=list[imageIndex]
                                    list[imageIndex]=old.copy(width=(old.width+dx).coerceIn(0.12f,1f-old.x), height=(old.height+dy).coerceIn(0.08f,1f-old.y)); u[activePage]=u[activePage].copy(images=list); pages=u
                                } }, contentAlignment=Alignment.Center) { Icon(Icons.Default.OpenInFull,null,tint=Color.White,modifier=Modifier.size(15.dp)) }
                            Box(Modifier.align(Alignment.TopEnd).size(24.dp).background(Color(0xFFB3261E), RoundedCornerShape(bottomStart=6.dp))) {
                                IconButton(onClick={ val u=pages.toMutableList(); u[activePage]=u[activePage].copy(images=u[activePage].images.filterIndexed{i,_->i!=imageIndex}); pages=u }, modifier=Modifier.size(24.dp)) { Icon(Icons.Default.Close,"Remove image",tint=Color.White,modifier=Modifier.size(14.dp)) }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Font size")
            TextButton(onClick = { fontSize = (fontSize - 1).coerceAtLeast(10) }) { Text("A−") }
            Text("$fontSize")
            TextButton(onClick = { fontSize = (fontSize + 1).coerceAtMost(28) }) { Text("A+") }
        }
        OutlinedTextField(
            value = outName, onValueChange = { outName = it },
            label = { Text("File name") }, modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                val name = outName.ifBlank { "My_Document" }.let {
                    if (editorMode == "PDF") it.removeSuffix(".pdf").removeSuffix(".docx")
                    else it.removeSuffix(".docx").removeSuffix(".pdf")
                }
                if (editorMode == "PDF") pdfSaveLauncher.launch("$name.pdf")
                else wordSaveLauncher.launch("$name.docx")
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (editorMode == "PDF") "Export PDF" else "Save Word DOCX") }
    }
}

@Composable
fun ExcelToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var excelFile by remember { mutableStateOf<File?>(null) }
    var landscape by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("Spreadsheet_Report.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { excelFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "xls_", ".xlsx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = excelFile
        if (uri != null && src != null) {
            scope.launch {
                val outTemp = File.createTempFile("xls_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.convertExcelToPdf(src, outName.removeSuffix(".pdf"), landscape, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Excel to PDF", uri.toString(), bytes, "Just now", if (landscape) "Landscape" else "Portrait"))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }) {
            Text("Upload File")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
            FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = excelFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Export Spreadsheet to PDF") }
    }
}

@Composable
fun PdfSplitScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var rangeStr by remember { mutableStateOf("1") }
    var asZip by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "split_", ".pdf") }
            val (_, count) = withContext(Dispatchers.IO) { PdfDocumentEngine.renderPdfPageBitmap(f, 0, 0.5f) }
            pdfFile = f; totalPages = count
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(if (asZip) "application/zip" else "application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val pages = PdfDocumentEngine.parsePageRange(rangeStr, totalPages.coerceAtLeast(1))
            val outTemp = File.createTempFile("split_out_", if (asZip) ".zip" else ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.splitPdf(src, pages, asZip, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), if (asZip) "Split_Pages.zip" else "Split_Pages.pdf", "PDF Split", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Page Split", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = rangeStr, onValueChange = { rangeStr = it }, label = { Text("Page Range (e.g. 1-2, 4)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !asZip, onClick = { asZip = false }, label = { Text("Single PDF") })
            FilterChip(selected = asZip, onClick = { asZip = true }, label = { Text("ZIP of Pages") })
        }
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(if (asZip) "Split_Pages.zip" else "Split_Pages.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Extract & Save") }
    }
}

@Composable
fun PdfMergeScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<Pair<String, File>>>(emptyList()) }
    var outName by remember { mutableStateOf("Merged_Document.pdf") }

    val addLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                uris.mapIndexed { idx, u -> "PDF #${files.size + idx + 1}" to PdfDocumentEngine.copyUriToTempFile(context, u, "merge_", ".pdf") }
            }
            files = files + loaded
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && files.isNotEmpty()) scope.launch {
            val outTemp = File.createTempFile("merged_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.mergePdfs(files.map { it.second }, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF Merge", uri.toString(), bytes, "Just now", "${files.size} files"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Merge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { addLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Merged Output Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = files.size >= 2, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Merge & Save PDF") }
    }
}

@Composable
fun SignPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var pdfPreview by remember { mutableStateOf<Bitmap?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var selectedPage by remember { mutableIntStateOf(1) }
    var signerName by remember { mutableStateOf("Authorized Signer") }
    val inkColors = listOf(
        "Blue" to Color(0xFF1D4ED8), "Black" to Color(0xFF111827),
        "Red" to Color(0xFFDC2626), "Green" to Color(0xFF15803D),
        "Purple" to Color(0xFF7E22CE), "Navy" to Color(0xFF1E3A8A)
    )
    var selectedInkColor by remember { mutableStateOf(inkColors[0].second) }
    var strokes by remember { mutableStateOf<List<List<androidx.compose.ui.geometry.Offset>>>(emptyList()) }
    var currentStroke by remember { mutableStateOf<List<androidx.compose.ui.geometry.Offset>>(emptyList()) }
    // Normalized placement rectangle, matching the PDF Crop touch model.
    var boxLeft by remember { mutableFloatStateOf(0.22f) }
    var boxTop by remember { mutableFloatStateOf(0.68f) }
    var boxWidth by remember { mutableFloatStateOf(0.56f) }
    var boxHeight by remember { mutableFloatStateOf(0.16f) }
    var pageBoxSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize(1, 1)) }
    var inkCanvasSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize(1, 1)) }
    var loadingPreview by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var pdfZoom by remember { mutableFloatStateOf(1f) }
    var pdfPanX by remember { mutableFloatStateOf(0f) }
    var pdfPanY by remember { mutableFloatStateOf(0f) }
    val pdfTransformState = rememberTransformableState { zoomChange, panChange, _ ->
        pdfZoom = (pdfZoom * zoomChange).coerceIn(1f, 4f)
        pdfPanX += panChange.x
        pdfPanY += panChange.y
    }

    fun loadPage(file: File, pageIndex: Int) {
        scope.launch {
            loadingPreview = true
            val rendered = withContext(Dispatchers.IO) {
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                descriptor.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pageCount = renderer.pageCount
                        renderer.openPage(pageIndex).use { page ->
                            val scale = (1200f / page.width).coerceAtMost(2f)
                            Bitmap.createBitmap(
                                (page.width * scale).toInt().coerceAtLeast(1),
                                (page.height * scale).toInt().coerceAtLeast(1),
                                Bitmap.Config.ARGB_8888
                            ).also { page.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY) }
                        }
                    }
                }
            }
            pdfPreview = rendered
            pdfZoom = 1f; pdfPanX = 0f; pdfPanY = 0f
            boxLeft = 0.22f; boxTop = 0.68f; boxWidth = 0.56f; boxHeight = 0.16f
            loadingPreview = false
        }
    }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val copied = withContext(Dispatchers.IO) {
                PdfDocumentEngine.copyUriToTempFile(context, uri, "sign_", ".pdf")
            }
            pdfFile = copied
            selectedPage = 1
            strokes = emptyList()
            currentStroke = emptyList()
            loadPage(copied, 0)
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        val preview = pdfPreview
        if (uri != null && src != null && preview != null && strokes.isNotEmpty()) scope.launch {
            saving = true
            val bmpW = 900
            val bmpH = (bmpW * (boxHeight * pageBoxSize.height / (boxWidth * pageBoxSize.width).coerceAtLeast(1f))).toInt().coerceIn(100, 900)
            val signature = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(signature)
            val paint = Paint().apply {
                color = android.graphics.Color.argb(255,
                    (selectedInkColor.red * 255).toInt(), (selectedInkColor.green * 255).toInt(),
                    (selectedInkColor.blue * 255).toInt())
                strokeWidth = (bmpW / 100f).coerceAtLeast(5f)
                style = Paint.Style.STROKE; isAntiAlias = true; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
            }
            val sourceW = inkCanvasSize.width.toFloat().coerceAtLeast(1f)
            val sourceH = inkCanvasSize.height.toFloat().coerceAtLeast(1f)
            strokes.forEach { points ->
                if (points.size > 1) {
                    val p = AndroidPath()
                    p.moveTo(points.first().x / sourceW * bmpW, points.first().y / sourceH * bmpH)
                    points.drop(1).forEach { p.lineTo(it.x / sourceW * bmpW, it.y / sourceH * bmpH) }
                    canvas.drawPath(p, paint)
                }
            }
            val outTemp = File.createTempFile("signed_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.signPdf(
                    src, signature, signerName, selectedPage,
                    boxLeft, boxTop, boxWidth.coerceIn(0.08f, 0.9f), outTemp
                )
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(
                System.currentTimeMillis().toString(), "Signed_Document.pdf", "Sign PDF",
                uri.toString(), bytes, "Just now", signerName
            ))
            saving = false
        }
    }

    val signScrollState = rememberScrollState()
    Box(Modifier.fillMaxSize()) {
        Column(
        Modifier.fillMaxSize()
            .verticalScroll(signScrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Sign PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) {
            Text(if (pdfFile == null) "Upload File" else "Change PDF")
        }
        if (loadingPreview) CircularProgressIndicator()
        pdfPreview?.let { pageBitmap ->
            Text("1. Position signature on PDF — drag the box to move; drag handles to resize")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Page $selectedPage of $pageCount")
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { pdfZoom = 1f; pdfPanX = 0f; pdfPanY = 0f }) { Text("Reset Zoom") }
                TextButton(enabled = selectedPage > 1, onClick = {
                    selectedPage--; pdfFile?.let { loadPage(it, selectedPage - 1) }
                }) { Text("Previous") }
                TextButton(enabled = selectedPage < pageCount, onClick = {
                    selectedPage++; pdfFile?.let { loadPage(it, selectedPage - 1) }
                }) { Text("Next") }
            }
            Box(
                Modifier.fillMaxWidth().aspectRatio(pageBitmap.width.toFloat() / pageBitmap.height)
                    .onSizeChanged { pageBoxSize = it }
                    .clipToBounds()
                    .graphicsLayer {
                        scaleX = pdfZoom
                        scaleY = pdfZoom
                        translationX = pdfPanX
                        translationY = pdfPanY
                    }
                    .transformable(state = pdfTransformState)
            ) {
                Image(pageBitmap.asImageBitmap(), contentDescription = "PDF page", modifier = Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    val l = boxLeft * size.width; val t = boxTop * size.height
                    val w = boxWidth * size.width; val h = boxHeight * size.height
                    drawRect(Color(0x142563EB), androidx.compose.ui.geometry.Offset(l, t), androidx.compose.ui.geometry.Size(w, h))
                    drawRect(Color(0xFF2563EB), androidx.compose.ui.geometry.Offset(l, t), androidx.compose.ui.geometry.Size(w, h), style = Stroke(4f))
                    listOf(
                        androidx.compose.ui.geometry.Offset(l,t), androidx.compose.ui.geometry.Offset(l+w,t),
                        androidx.compose.ui.geometry.Offset(l,t+h), androidx.compose.ui.geometry.Offset(l+w,t+h),
                        androidx.compose.ui.geometry.Offset(l+w/2,t), androidx.compose.ui.geometry.Offset(l+w/2,t+h),
                        androidx.compose.ui.geometry.Offset(l,t+h/2), androidx.compose.ui.geometry.Offset(l+w,t+h/2)
                    ).forEach { pt ->
                        drawCircle(Color(0xFF2563EB), 12f, pt)
                        drawCircle(Color.White, 6f, pt)
                    }
                    // Live signature preview clipped to the movable placement box.
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(l, t, l+w, t+h)
                    (strokes + listOf(currentStroke)).forEach { pts ->
                        if (pts.size > 1) {
                            val p = Path()
                            p.moveTo(l + pts.first().x / inkCanvasSize.width.toFloat().coerceAtLeast(1f) * w,
                                t + pts.first().y / inkCanvasSize.height.toFloat().coerceAtLeast(1f) * h)
                            pts.drop(1).forEach { p.lineTo(
                                l + it.x / inkCanvasSize.width.toFloat().coerceAtLeast(1f) * w,
                                t + it.y / inkCanvasSize.height.toFloat().coerceAtLeast(1f) * h
                            ) }
                            drawPath(p, selectedInkColor, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                        }
                    }
                    drawContext.canvas.restore()
                }
                // Crop-style eight-handle move/resize interaction.
                var dragMode by remember { mutableStateOf("NONE") }
                Modifier
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().pointerInput(boxLeft, boxTop, boxWidth, boxHeight, pageBoxSize) {
                    detectDragGestures(
                        onDragStart = { pos ->
                            val w = pageBoxSize.width.toFloat().coerceAtLeast(1f)
                            val h = pageBoxSize.height.toFloat().coerceAtLeast(1f)
                            val l = boxLeft*w; val t = boxTop*h; val r = (boxLeft+boxWidth)*w; val b = (boxTop+boxHeight)*h
                            val tol = 44f
                            val nearL = kotlin.math.abs(pos.x-l)<tol; val nearR = kotlin.math.abs(pos.x-r)<tol
                            val nearT = kotlin.math.abs(pos.y-t)<tol; val nearB = kotlin.math.abs(pos.y-b)<tol
                            dragMode = when {
                                nearL && nearT -> "NW"; nearR && nearT -> "NE"
                                nearL && nearB -> "SW"; nearR && nearB -> "SE"
                                nearT && pos.x in l..r -> "N"; nearB && pos.x in l..r -> "S"
                                nearL && pos.y in t..b -> "W"; nearR && pos.y in t..b -> "E"
                                pos.x in l..r && pos.y in t..b -> "MOVE"
                                else -> "NONE"
                            }
                        },
                        onDrag = { change, delta ->
                            change.consume()
                            val dx = delta.x / pageBoxSize.width.toFloat().coerceAtLeast(1f)
                            val dy = delta.y / pageBoxSize.height.toFloat().coerceAtLeast(1f)
                            var l=boxLeft; var t=boxTop; var r=boxLeft+boxWidth; var b=boxTop+boxHeight
                            val minS=0.06f
                            when(dragMode) {
                                "MOVE" -> { boxLeft=(l+dx).coerceIn(0f,1f-boxWidth); boxTop=(t+dy).coerceIn(0f,1f-boxHeight); return@detectDragGestures }
                                "NW" -> { l=(l+dx).coerceIn(0f,r-minS); t=(t+dy).coerceIn(0f,b-minS) }
                                "NE" -> { r=(r+dx).coerceIn(l+minS,1f); t=(t+dy).coerceIn(0f,b-minS) }
                                "SW" -> { l=(l+dx).coerceIn(0f,r-minS); b=(b+dy).coerceIn(t+minS,1f) }
                                "SE" -> { r=(r+dx).coerceIn(l+minS,1f); b=(b+dy).coerceIn(t+minS,1f) }
                                "N" -> t=(t+dy).coerceIn(0f,b-minS)
                                "S" -> b=(b+dy).coerceIn(t+minS,1f)
                                "W" -> l=(l+dx).coerceIn(0f,r-minS)
                                "E" -> r=(r+dx).coerceIn(l+minS,1f)
                                else -> return@detectDragGestures
                            }
                            boxLeft=l; boxTop=t; boxWidth=r-l; boxHeight=b-t
                        }
                    )
                })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            inkColors.forEach { (label, color) ->
                FilterChip(selected = selectedInkColor == color, onClick = { selectedInkColor = color },
                    label = { Text(label) }, leadingIcon = { Box(Modifier.size(12.dp).background(color, androidx.compose.foundation.shape.CircleShape)) })
            }
        }
        OutlinedTextField(value = signerName, onValueChange = { signerName = it },
            label = { Text("Signer Name") }, modifier = Modifier.fillMaxWidth())
        Box(Modifier.fillMaxWidth().height(130.dp).onSizeChanged { inkCanvasSize = it }.background(Color.White).border(1.dp, MaterialTheme.colorScheme.outline)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { currentStroke = listOf(it) },
                    onDrag = { change, _ -> change.consume(); currentStroke = currentStroke + change.position },
                    onDragEnd = { if (currentStroke.isNotEmpty()) strokes = strokes + listOf(currentStroke); currentStroke = emptyList() }
                )
            }) {
            Canvas(Modifier.fillMaxSize()) {
                (strokes + listOf(currentStroke)).forEach { pts ->
                    if (pts.size > 1) {
                        val p = Path().apply { moveTo(pts.first().x, pts.first().y); pts.drop(1).forEach { lineTo(it.x,it.y) } }
                        drawPath(p, selectedInkColor, style = Stroke(width=5f, cap=StrokeCap.Round))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { strokes = emptyList(); currentStroke = emptyList() }) { Text("Clear Ink") }
            OutlinedButton(onClick = { boxLeft=0.22f; boxTop=0.68f; boxWidth=0.56f; boxHeight=0.16f }) { Text("Reset Area") }
        }
        Button(enabled = pdfFile != null && pdfPreview != null && strokes.isNotEmpty() && !saving,
            onClick = { saveLauncher.launch("Signed_Document.pdf") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (saving) "Saving PDF..." else "Sign & Save PDF")
        }
    }

    }

}

@Composable
fun PdfToWordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Converted_Document.docx") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "p2w_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("p2w_out_", ".docx", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertPdfToWord(src, outName.removeSuffix(".docx"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF to Word", uri.toString(), bytes, "Just now", "DOCX Export"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF to Word (.docx)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output Word Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save .DOCX") }
    }
}

@Composable
fun WordToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docxFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Word_Export.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { docxFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "w2p_", ".docx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = docxFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("w2p_out_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertWordToPdf(src, outName.removeSuffix(".pdf"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Word to PDF", uri.toString(), bytes, "Just now", "DOCX -> PDF"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Word (.docx) to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = docxFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save PDF") }
    }
}

@Composable
fun PdfPasswordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var userPwd by remember { mutableStateOf("") }
    var ownerPwd by remember { mutableStateOf("") }
    var watermark by remember { mutableStateOf("CONFIDENTIAL") }
    var allowPrint by remember { mutableStateOf(true) }
    var allowCopy by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "lock_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("locked_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.protectPdf(src, userPwd, ownerPwd.ifBlank { userPwd }, watermark, allowPrint, allowCopy, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Protected_Document.pdf", "PDF Password", uri.toString(), bytes, "Just now", "AES-256 Encrypted"))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Password Protection (AES-256)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = userPwd, onValueChange = { userPwd = it }, label = { Text("User Open Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ownerPwd, onValueChange = { ownerPwd = it }, label = { Text("Owner Permissions Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = watermark, onValueChange = { watermark = it }, label = { Text("Diagonal Watermark") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowPrint, onCheckedChange = { allowPrint = it }); Text("Allow Printing") }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowCopy, onCheckedChange = { allowCopy = it }); Text("Allow Copy") }
        Button(enabled = pdfFile != null && userPwd.isNotBlank(), onClick = { saveLauncher.launch("Protected_Document.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Encrypt & Save PDF") }
    }
}

@Composable
fun RecentUsedScreen(records: List<RecentDocumentRecord>, onClear: () -> Unit, onOpen: (RecentDocumentRecord) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Recent Used Files (${records.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (records.isNotEmpty()) { TextButton(onClick = onClear) { Text("Clear") } }
        }
        if (records.isEmpty()) {
            Text("Processed documents will appear here for one-tap access.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { item ->
                    ElevatedCard(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.displayName, fontWeight = FontWeight.SemiBold)
                            Text("${item.toolTitle} · ${item.summary} · ${item.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
