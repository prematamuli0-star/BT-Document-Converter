package com.btdocument.suite.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.btdocument.suite.model.RecentDocumentRecord
import com.btdocument.suite.model.EditorPage
import com.btdocument.suite.model.EditorImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pages by remember { mutableStateOf(listOf(EditorPage())) }
    var activePage by remember { mutableIntStateOf(0) }
    var editorMode by remember { mutableStateOf("PDF") }
    var outName by remember { mutableStateOf("My_Document") }
    var fontSize by remember { mutableIntStateOf(16) }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }
            if (bitmap != null) {
                val updated = pages.toMutableList()
                updated[activePage] = updated[activePage].copy(images = updated[activePage].images + EditorImage(bitmap))
                pages = updated
            }
        }
    }
    val openWordLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val importedText = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    org.apache.poi.xwpf.usermodel.XWPFDocument(input).use { doc ->
                        doc.paragraphs.joinToString("\\n") { it.text }
                    }
                }.orEmpty()
            }
            pages = listOf(EditorPage(text = importedText))
            activePage = 0
            editorMode = "Word"
            outName = uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Edited_Document"
        }
    }
    val pdfSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".pdf", context.cacheDir)
            val content = pages
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createPdfFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.pdf", "Text to PDF", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }
    val wordSaveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        if (uri != null) scope.launch {
            val output = File.createTempFile("editor_", ".docx", context.cacheDir)
            val content = pages
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.createDocxFromEditorPages(content, output)
                PdfDocumentEngine.writeFileToDestinationUri(context, output, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "$outName.docx", "Word Editor", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text("Document Editor", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = editorMode == "PDF", onClick = { editorMode = "PDF" }, label = { Text("PDF") })
            FilterChip(selected = editorMode == "Word", onClick = { editorMode = "Word" }, label = { Text("Word DOCX") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (editorMode == "Word") {
                OutlinedButton(onClick = { openWordLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Open DOCX") }
            }
            OutlinedButton(onClick = { imageLauncher.launch(arrayOf("image/png", "image/jpeg", "image/*")) }) { Text("Add Photo / PNG") }
            OutlinedButton(onClick = { pages = pages + EditorPage(); activePage = pages.lastIndex }) { Text("+ Add Page") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Page ${activePage + 1} of ${pages.size}")
            Spacer(Modifier.weight(1f))
            TextButton(enabled = activePage > 0, onClick = { activePage-- }) { Text("Previous") }
            TextButton(enabled = activePage < pages.lastIndex, onClick = { activePage++ }) { Text("Next") }
        }
        // A4 sheet preview: exact portrait A4 proportion (210 x 297 mm).
        val density = LocalDensity.current
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            val paperWidth = maxWidth
            val paperHeight = paperWidth * (297f / 210f)
            Card(Modifier.width(paperWidth).height(paperHeight), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(4.dp), shape = RoundedCornerShape(3.dp)) {
                BoxWithConstraints(Modifier.fillMaxSize().padding(12.dp)) {
                    val pw = maxWidth; val ph = maxHeight
                    Text("A4 • Page ${activePage + 1}", Modifier.align(Alignment.TopEnd), color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                    OutlinedTextField(
                        value = pages[activePage].text,
                        onValueChange = { value -> val u=pages.toMutableList(); u[activePage]=u[activePage].copy(text=value); pages=u },
                        placeholder = { Text("Start typing here…") },
                        modifier = Modifier.fillMaxSize().padding(top=18.dp),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize=fontSize.sp, color=Color.Black),
                        colors = OutlinedTextFieldDefaults.colors(focusedContainerColor=Color.Transparent, unfocusedContainerColor=Color.Transparent, focusedBorderColor=Color.Transparent, unfocusedBorderColor=Color.Transparent)
                    )
                    pages[activePage].images.forEachIndexed { imageIndex, item ->
                        Box(Modifier.offset(x=pw*item.x, y=ph*item.y).width(pw*item.width).height(ph*item.height)
                            .border(1.5.dp, Color(0xFF6750A4))
                            .pointerInput(activePage,imageIndex,pw,ph) { detectDragGestures { change, drag ->
                                change.consume(); val dx=with(density){drag.x.toDp().value}/pw.value.coerceAtLeast(1f); val dy=with(density){drag.y.toDp().value}/ph.value.coerceAtLeast(1f)
                                val u=pages.toMutableList(); val list=u[activePage].images.toMutableList(); val old=list[imageIndex]
                                list[imageIndex]=old.copy(x=(old.x+dx).coerceIn(0f,1f-old.width), y=(old.y+dy).coerceIn(0f,1f-old.height)); u[activePage]=u[activePage].copy(images=list); pages=u
                            } }) {
                            Image(item.bitmap.asImageBitmap(), "Inserted image", Modifier.fillMaxSize())
                            Box(Modifier.align(Alignment.BottomEnd).size(26.dp).background(Color(0xFF6750A4), RoundedCornerShape(topStart=6.dp))
                                .pointerInput(activePage,imageIndex,pw,ph) { detectDragGestures { change, drag ->
                                    change.consume(); val dx=with(density){drag.x.toDp().value}/pw.value.coerceAtLeast(1f); val dy=with(density){drag.y.toDp().value}/ph.value.coerceAtLeast(1f)
                                    val u=pages.toMutableList(); val list=u[activePage].images.toMutableList(); val old=list[imageIndex]
                                    list[imageIndex]=old.copy(width=(old.width+dx).coerceIn(0.12f,1f-old.x), height=(old.height+dy).coerceIn(0.08f,1f-old.y)); u[activePage]=u[activePage].copy(images=list); pages=u
                                } }, contentAlignment=Alignment.Center) { Icon(Icons.Default.OpenInFull,null,tint=Color.White,modifier=Modifier.size(15.dp)) }
                            Box(Modifier.align(Alignment.TopEnd).size(24.dp).background(Color(0xFFB3261E), RoundedCornerShape(bottomStart=6.dp))) {
                                IconButton(onClick={ val u=pages.toMutableList(); u[activePage]=u[activePage].copy(images=u[activePage].images.filterIndexed{i,_->i!=imageIndex}); pages=u }, modifier=Modifier.size(24.dp)) { Icon(Icons.Default.Close,"Remove image",tint=Color.White,modifier=Modifier.size(14.dp)) }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Font size")
            TextButton(onClick = { fontSize = (fontSize - 1).coerceAtLeast(10) }) { Text("A−") }
            Text("$fontSize")
            TextButton(onClick = { fontSize = (fontSize + 1).coerceAtMost(28) }) { Text("A+") }
        }
        OutlinedTextField(
            value = outName, onValueChange = { outName = it },
            label = { Text("File name") }, modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                val name = outName.ifBlank { "My_Document" }.let {
                    if (editorMode == "PDF") it.removeSuffix(".pdf").removeSuffix(".docx")
                    else it.removeSuffix(".docx").removeSuffix(".pdf")
                }
                if (editorMode == "PDF") pdfSaveLauncher.launch("$name.pdf")
                else wordSaveLauncher.launch("$name.docx")
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (editorMode == "PDF") "Export PDF" else "Save Word DOCX") }
    }
}

@Composable
fun ExcelToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var excelFile by remember { mutableStateOf<File?>(null) }
    var landscape by remember { mutableStateOf(true) }
    var outName by remember { mutableStateOf("Spreadsheet_Report.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { excelFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "xls_", ".xlsx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = excelFile
        if (uri != null && src != null) {
            scope.launch {
                val outTemp = File.createTempFile("xls_pdf_", ".pdf", context.cacheDir)
                val bytes = withContext(Dispatchers.IO) {
                    PdfDocumentEngine.convertExcelToPdf(src, outName.removeSuffix(".pdf"), landscape, outTemp)
                    PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
                }
                onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Excel to PDF", uri.toString(), bytes, "Just now", if (landscape) "Landscape" else "Portrait"))
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Excel to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }) {
            Text("Upload File")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
            FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
        }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = excelFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Export Spreadsheet to PDF") }
    }
}

@Composable
fun PdfSplitScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var totalPages by remember { mutableIntStateOf(0) }
    var rangeStr by remember { mutableStateOf("1") }
    var asZip by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val f = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "split_", ".pdf") }
            val (_, count) = withContext(Dispatchers.IO) { PdfDocumentEngine.renderPdfPageBitmap(f, 0, 0.5f) }
            pdfFile = f; totalPages = count
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(if (asZip) "application/zip" else "application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val pages = PdfDocumentEngine.parsePageRange(rangeStr, totalPages.coerceAtLeast(1))
            val outTemp = File.createTempFile("split_out_", if (asZip) ".zip" else ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.splitPdf(src, pages, asZip, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), if (asZip) "Split_Pages.zip" else "Split_Pages.pdf", "PDF Split", uri.toString(), bytes, "Just now", "${pages.size} pages"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Page Split", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = rangeStr, onValueChange = { rangeStr = it }, label = { Text("Page Range (e.g. 1-2, 4)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !asZip, onClick = { asZip = false }, label = { Text("Single PDF") })
            FilterChip(selected = asZip, onClick = { asZip = true }, label = { Text("ZIP of Pages") })
        }
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(if (asZip) "Split_Pages.zip" else "Split_Pages.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Extract & Save") }
    }
}

@Composable
fun PdfMergeScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf<List<Pair<String, File>>>(emptyList()) }
    var outName by remember { mutableStateOf("Merged_Document.pdf") }

    val addLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                uris.mapIndexed { idx, u -> "PDF #${files.size + idx + 1}" to PdfDocumentEngine.copyUriToTempFile(context, u, "merge_", ".pdf") }
            }
            files = files + loaded
        }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && files.isNotEmpty()) scope.launch {
            val outTemp = File.createTempFile("merged_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.mergePdfs(files.map { it.second }, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF Merge", uri.toString(), bytes, "Just now", "${files.size} files"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Merge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { addLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Merged Output Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = files.size >= 2, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Merge & Save PDF") }
    }
}

@Composable
fun PdfToWordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Converted_Document.docx") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "p2w_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("p2w_out_", ".docx", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertPdfToWord(src, outName.removeSuffix(".docx"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "PDF to Word", uri.toString(), bytes, "Just now", "DOCX Export"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF to Word (.docx)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output Word Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = pdfFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save .DOCX") }
    }
}

@Composable
fun WordToPdfScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docxFile by remember { mutableStateOf<File?>(null) }
    var outName by remember { mutableStateOf("Word_Export.pdf") }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { docxFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "w2p_", ".docx") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = docxFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("w2p_out_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.convertWordToPdf(src, outName.removeSuffix(".pdf"), outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), outName, "Word to PDF", uri.toString(), bytes, "Just now", "DOCX -> PDF"))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Word (.docx) to PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) }) { Text("Upload File") }
        OutlinedTextField(value = outName, onValueChange = { outName = it }, label = { Text("Output PDF Name") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = docxFile != null, onClick = { saveLauncher.launch(outName) }, modifier = Modifier.fillMaxWidth()) { Text("Convert & Save PDF") }
    }
}

@Composable
fun PdfPasswordScreen(onSaveRecent: (RecentDocumentRecord) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdfFile by remember { mutableStateOf<File?>(null) }
    var userPwd by remember { mutableStateOf("") }
    var ownerPwd by remember { mutableStateOf("") }
    var watermark by remember { mutableStateOf("CONFIDENTIAL") }
    var allowPrint by remember { mutableStateOf(true) }
    var allowCopy by remember { mutableStateOf(false) }

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { pdfFile = withContext(Dispatchers.IO) { PdfDocumentEngine.copyUriToTempFile(context, uri, "lock_", ".pdf") } }
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val src = pdfFile
        if (uri != null && src != null) scope.launch {
            val outTemp = File.createTempFile("locked_", ".pdf", context.cacheDir)
            val bytes = withContext(Dispatchers.IO) {
                PdfDocumentEngine.protectPdf(src, userPwd, ownerPwd.ifBlank { userPwd }, watermark, allowPrint, allowCopy, outTemp)
                PdfDocumentEngine.writeFileToDestinationUri(context, outTemp, uri)
            }
            onSaveRecent(RecentDocumentRecord(System.currentTimeMillis().toString(), "Protected_Document.pdf", "PDF Password", uri.toString(), bytes, "Just now", "AES-256 Encrypted"))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PDF Password Protection (AES-256)", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/pdf")) }) { Text("Upload File") }
        OutlinedTextField(value = userPwd, onValueChange = { userPwd = it }, label = { Text("User Open Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ownerPwd, onValueChange = { ownerPwd = it }, label = { Text("Owner Permissions Password") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = watermark, onValueChange = { watermark = it }, label = { Text("Diagonal Watermark") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowPrint, onCheckedChange = { allowPrint = it }); Text("Allow Printing") }
        Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = allowCopy, onCheckedChange = { allowCopy = it }); Text("Allow Copy") }
        Button(enabled = pdfFile != null && userPwd.isNotBlank(), onClick = { saveLauncher.launch("Protected_Document.pdf") }, modifier = Modifier.fillMaxWidth()) { Text("Encrypt & Save PDF") }
    }
}

@Composable
fun RecentUsedScreen(records: List<RecentDocumentRecord>, onClear: () -> Unit, onOpen: (RecentDocumentRecord) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Recent Used Files (${records.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (records.isNotEmpty()) { TextButton(onClick = onClear) { Text("Clear") } }
        }
        if (records.isEmpty()) {
            Text("Processed documents will appear here for one-tap access.", style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { item ->
                    ElevatedCard(onClick = { onOpen(item) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(item.displayName, fontWeight = FontWeight.SemiBold)
                            Text("${item.toolTitle} · ${item.summary} · ${item.sizeBytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
