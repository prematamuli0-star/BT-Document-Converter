package com.btdocument.suite

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.btdocument.suite.engine.PdfDocumentEngine
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

 data class DocumentTool(val id: String, val title: String, val subtitle: String, val icon: ImageVector)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { MaterialTheme { BTDocumentApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BTDocumentApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }
    var activeTool by remember { mutableStateOf<DocumentTool?>(null) }
    var message by remember { mutableStateOf("") }
    var showTextDialog by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var textTitle by remember { mutableStateOf("My Document") }
    var textBody by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var pendingOutput by remember { mutableStateOf<File?>(null) }
    var pendingMime by remember { mutableStateOf("application/pdf") }
    var recent by remember { mutableStateOf(listOf<String>()) }
    var cropSource by remember { mutableStateOf<File?>(null) }
    var cropPreview by remember { mutableStateOf<Bitmap?>(null) }

    val tools = remember { listOf(
        DocumentTool("text_pdf", "Text to PDF", "Convert notes & plain text", Icons.Default.Description),
        DocumentTool("excel_pdf", "Excel to PDF", "Convert .xlsx spreadsheets", Icons.Default.TableChart),
        DocumentTool("pdf_crop", "PDF Photo Crop", "Trim page margins", Icons.Default.Crop),
        DocumentTool("pdf_split", "PDF Page Split", "Save first page as a PDF", Icons.Default.CallSplit),
        DocumentTool("pdf_merge", "PDF Merge", "Combine PDF files", Icons.Default.MergeType),
        DocumentTool("sign_pdf", "Sign PDF", "Signature tool", Icons.Default.Draw),
        DocumentTool("pdf_word", "PDF to Word", "Export editable .docx", Icons.Default.Article),
        DocumentTool("word_pdf", "Word to PDF", "Convert .docx to PDF", Icons.Default.PictureAsPdf),
        DocumentTool("pdf_lock", "PDF Password", "Protect a PDF with password", Icons.Default.Lock)
    ) }

    fun saveResult(file: File, mime: String = "application/pdf") {
        pendingOutput = file
        pendingMime = mime
        message = "Created: ${file.name}. Use Save As to choose where to store it."
    }

    val singlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val tool = activeTool
        if (uri != null && tool != null) {
            scope.launch {
                try {
                    if (tool.id == "pdf_crop") {
                        val pair = withContext(Dispatchers.IO) {
                            val input = File(context.cacheDir, "crop_source_${System.currentTimeMillis()}.pdf")
                            context.contentResolver.openInputStream(uri)?.use { src -> input.outputStream().use { src.copyTo(it) } } ?: error("Cannot read selected PDF")
                            val pfd = ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY)
                            val renderer = PdfRenderer(pfd)
                            val page = renderer.openPage(0)
                            val scale = (1200f / page.width).coerceAtMost(3f)
                            val bmp = Bitmap.createBitmap((page.width * scale).toInt(), (page.height * scale).toInt(), Bitmap.Config.ARGB_8888)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            page.close(); renderer.close(); pfd.close()
                            input to bmp
                        }
                        cropSource = pair.first
                        cropPreview = pair.second
                        return@launch
                    }
                    val result = withContext(Dispatchers.IO) {
                        val input = File(context.cacheDir, "input_${System.currentTimeMillis()}.pdf")
                        context.contentResolver.openInputStream(uri)?.use { src -> input.outputStream().use { src.copyTo(it) } }
                            ?: error("Cannot read selected file")
                        val output = File(context.cacheDir, "BT_${tool.id}_${System.currentTimeMillis()}.pdf")
                        when (tool.id) {
                            "pdf_split" -> PdfDocumentEngine.splitPdfPage(input, 1, output)
                            "pdf_lock" -> PdfDocumentEngine.protectPdf(input, password, password + "_owner", true, output)
                            else -> error("This tool is not available in this build yet")
                        }
                        input.delete()
                        output
                    }
                    recent = listOf(result.name) + recent
                    saveResult(result)
                } catch (e: Exception) { message = "Could not process file: ${e.message}" }
            }
        }
    }

    val multiplePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.size >= 2) scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val files = uris.mapIndexed { index, uri ->
                        val f = File(context.cacheDir, "merge_${index}_${System.currentTimeMillis()}.pdf")
                        context.contentResolver.openInputStream(uri)?.use { src -> f.outputStream().use { src.copyTo(it) } } ?: error("Cannot read PDF")
                        f
                    }
                    val out = File(context.cacheDir, "BT_Merged_${System.currentTimeMillis()}.pdf")
                    PdfDocumentEngine.mergePdfs(files, out)
                    files.forEach { it.delete() }
                    out
                }
                recent = listOf(result.name) + recent
                saveResult(result)
            } catch (e: Exception) { message = "Merge failed: ${e.message}" }
        } else if (uris.isNotEmpty()) message = "Select at least two PDF files to merge."
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val file = pendingOutput
        if (uri != null && file != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                message = "Saved successfully."
                file.delete()
                pendingOutput = null
            } catch (e: Exception) { message = "Save failed: ${e.message}" }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("BT Document", fontWeight = FontWeight.Bold) }) },
        bottomBar = { NavigationBar {
            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Apps, null) }, label = { Text("All Tools") })
            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Recent Used") })
        } },
        snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
    ) { padding ->
        if (selectedTab == 0) {
            LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(padding).fillMaxSize()) {
                items(tools) { tool ->
                    ElevatedCard(onClick = {
                        activeTool = tool
                        when (tool.id) {
                            "text_pdf" -> showTextDialog = true
                            "pdf_merge" -> multiplePicker.launch(arrayOf("application/pdf"))
                            "pdf_lock" -> showPasswordDialog = true
                            "pdf_crop", "pdf_split" -> singlePicker.launch(arrayOf("application/pdf"))
                            else -> message = "${tool.title} is not implemented in this native build yet. The AI Studio preview does not automatically transfer its processing code into the APK."
                        }
                    }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Icon(tool.icon, contentDescription = tool.title, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(10.dp))
                            Text(tool.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text(tool.subtitle, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        } else {
            Column(Modifier.padding(padding).padding(16.dp)) {
                Text("Recent Used", style = MaterialTheme.typography.titleLarge)
                if (recent.isEmpty()) Text("No documents processed yet.") else recent.forEach { Text("• $it", Modifier.padding(vertical = 6.dp)) }
            }
        }
    }

    if (cropSource != null && cropPreview != null) {
        CropEditorDialog(
            bitmap = cropPreview!!,
            onDismiss = { cropSource?.delete(); cropSource = null; cropPreview = null },
            onRevert = { },
            onCrop = { left, top, width, height ->
                val source = cropSource
                if (source != null) scope.launch {
                    try {
                        val output = withContext(Dispatchers.IO) {
                            val out = File(context.cacheDir, "BT_Cropped_${System.currentTimeMillis()}.pdf")
                            PdfDocumentEngine.cropPdf(source, out, left, top, width, height)
                            out
                        }
                        source.delete(); cropSource = null; cropPreview = null
                        recent = listOf(output.name) + recent
                        saveResult(output)
                    } catch (e: Exception) { message = "Crop failed: ${e.message}"; cropSource?.delete(); cropSource = null; cropPreview = null }
                }
            }
        )
    }

    if (showTextDialog) AlertDialog(
        onDismissRequest = { showTextDialog = false },
        title = { Text("Text to PDF") },
        text = { Column {
            OutlinedTextField(textTitle, { textTitle = it }, label = { Text("Document title") })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(textBody, { textBody = it }, label = { Text("Enter text") }, minLines = 4)
        } },
        confirmButton = { TextButton(onClick = {
            showTextDialog = false
            scope.launch { try {
                val file = withContext(Dispatchers.IO) {
                    val out = File(context.cacheDir, "BT_Text_${System.currentTimeMillis()}.pdf")
                    PdfDocumentEngine.createPdfFromText(textTitle, textBody, out)
                    out
                }
                recent = listOf(file.name) + recent
                saveResult(file)
            } catch (e: Exception) { message = "PDF creation failed: ${e.message}" } }
        }) { Text("Create PDF") } },
        dismissButton = { TextButton(onClick = { showTextDialog = false }) { Text("Cancel") } }
    )

    if (showPasswordDialog) AlertDialog(
        onDismissRequest = { showPasswordDialog = false },
        title = { Text("Protect PDF") },
        text = { OutlinedTextField(password, { password = it }, label = { Text("Set password") }) },
        confirmButton = { TextButton(onClick = { showPasswordDialog = false; singlePicker.launch(arrayOf("application/pdf")) }) { Text("Choose PDF") } },
        dismissButton = { TextButton(onClick = { showPasswordDialog = false }) { Text("Cancel") } }
    )

    if (pendingOutput != null) AlertDialog(
        onDismissRequest = { pendingOutput = null },
        title = { Text("Save cropped PDF") },
        text = { Text(message + "\nYou can change the file name in the next Save As screen. The original PDF remains unchanged.") },
        confirmButton = { TextButton(onClick = { val f = pendingOutput; if (f != null) saveLauncher.launch(f.name); pendingOutput = null }) { Text("Save As") } },
        dismissButton = { TextButton(onClick = { pendingOutput?.delete(); pendingOutput = null; message = "" }) { Text("Close") } }
    )
    if (message.isNotBlank() && pendingOutput == null) AlertDialog(onDismissRequest = { message = "" }, title = { Text("BT Document") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { message = "" }) { Text("OK") } })
}
