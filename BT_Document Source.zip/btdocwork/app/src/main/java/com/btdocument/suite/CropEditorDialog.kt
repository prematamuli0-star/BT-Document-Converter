package com.btdocument.suite

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.abs

@Composable
fun CropEditorDialog(
    bitmap: Bitmap,
    onDismiss: () -> Unit,
    onRevert: () -> Unit,
    onCrop: (Float, Float, Float, Float) -> Unit
) {
    var crop by remember(bitmap) { mutableStateOf(Rect(.08f, .08f, .92f, .92f)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Crop PDF page") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text("Drag the crop box corners to select the area. The same crop is applied to every page.", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Canvas(Modifier.fillMaxWidth().height(390.dp).pointerInput(crop) {
                    var corner = 0
                    detectDragGestures(
                        onDragStart = { pos ->
                            val px = pos.x / size.width.coerceAtLeast(1).toFloat()
                            val py = pos.y / size.height.coerceAtLeast(1).toFloat()
                            val distances = listOf(
                                (px-crop.left)*(px-crop.left)+(py-crop.top)*(py-crop.top),
                                (px-crop.right)*(px-crop.right)+(py-crop.top)*(py-crop.top),
                                (px-crop.left)*(px-crop.left)+(py-crop.bottom)*(py-crop.bottom),
                                (px-crop.right)*(px-crop.right)+(py-crop.bottom)*(py-crop.bottom)
                            )
                            corner = distances.indices.minBy { distances[it] }
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            val dx = drag.x / size.width.coerceAtLeast(1).toFloat()
                            val dy = drag.y / size.height.coerceAtLeast(1).toFloat()
                            crop = when (corner) {
                                0 -> Rect((crop.left+dx).coerceIn(0f,crop.right-.08f), (crop.top+dy).coerceIn(0f,crop.bottom-.08f), crop.right, crop.bottom)
                                1 -> Rect(crop.left, (crop.top+dy).coerceIn(0f,crop.bottom-.08f), (crop.right+dx).coerceIn(crop.left+.08f,1f), crop.bottom)
                                2 -> Rect((crop.left+dx).coerceIn(0f,crop.right-.08f), crop.top, crop.right, (crop.bottom+dy).coerceIn(crop.top+.08f,1f))
                                else -> Rect(crop.left, crop.top, (crop.right+dx).coerceIn(crop.left+.08f,1f), (crop.bottom+dy).coerceIn(crop.top+.08f,1f))
                            }
                        }
                    )
                }) {
                    val image = bitmap.asImageBitmap()
                    drawImage(image, dstSize = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt()))
                    val r = Rect(crop.left * size.width, crop.top * size.height, crop.right * size.width, crop.bottom * size.height)
                    val shade = androidx.compose.ui.graphics.Color.Black.copy(alpha = .48f)
                    drawRect(shade, Offset.Zero, androidx.compose.ui.geometry.Size(size.width, r.top))
                    drawRect(shade, Offset(0f, r.bottom), androidx.compose.ui.geometry.Size(size.width, size.height-r.bottom))
                    drawRect(shade, Offset(0f, r.top), androidx.compose.ui.geometry.Size(r.left, r.height))
                    drawRect(shade, Offset(r.right, r.top), androidx.compose.ui.geometry.Size(size.width-r.right, r.height))
                    drawRect(androidx.compose.ui.graphics.Color.White, topLeft = Offset(r.left,r.top), size = r.size, style = Stroke(3.dp.toPx()))
                    val thirdX = r.width / 3f; val thirdY = r.height / 3f
                    for (i in 1..2) {
                        drawLine(androidx.compose.ui.graphics.Color.White.copy(alpha=.7f), Offset(r.left+thirdX*i,r.top), Offset(r.left+thirdX*i,r.bottom), 1.dp.toPx())
                        drawLine(androidx.compose.ui.graphics.Color.White.copy(alpha=.7f), Offset(r.left,r.top+thirdY*i), Offset(r.right,r.top+thirdY*i), 1.dp.toPx())
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCrop(crop.left, crop.top, crop.width, crop.height) }) { Text("Crop & Save As") } },
        dismissButton = { Row { TextButton(onClick = { crop = Rect(.08f,.08f,.92f,.92f) }) { Text("Revert") }; TextButton(onClick = onDismiss) { Text("Cancel") } } }
    )
}
