# BT Document v2.4.0 - Native Android

This source package wires native click actions for the following currently implemented flows:
- Text to PDF
- PDF Crop (fixed 5% trim on each edge)
- PDF Page Split (exports page 1)
- PDF Merge (select two or more PDFs)
- PDF Password Protection
- Recent Used list for generated files during the current app session

The following tiles remain visible but are not implemented in this native source yet: Excel to PDF, Sign PDF, PDF to Word, and Word to PDF. Their AI Studio preview functionality is not automatically included in a native Android APK. Do not describe these four as working until implemented and tested.

## Build
Use JDK 17 and Gradle 8.9, then run `gradle assembleDebug` from the project root. GitHub Actions can extract this source ZIP and build the debug APK.

## Notes
- Output is saved through Android's system Save As picker.
- This source has not been compiled in this environment because Gradle/Android SDK are unavailable here. Run GitHub Actions to verify compilation before installing.


## PDF Crop update
- Opens a preview of the first PDF page and provides a draggable crop frame with corner adjustment and grid guides.
- Revert resets the crop frame. Crop applies the selected page-area ratios to every page.
- The cropped result is created as a separate PDF; the original file is left unchanged.
- Android's Save As document picker lets the user rename the output and choose the destination.
- The crop preview currently displays page 1 as the selection guide; the selected crop is applied consistently to all pages.
