# BT Document ProGuard rules
