# BT Document Converter

Android app built with Kotlin, Jetpack Compose and PDFBox-Android. The existing blue UI is retained.

## Current offline tools
- Image to PDF (multiple images)
- Text to PDF
- XLSX to PDF (first worksheet; basic text layout, no Excel formatting/formulas/charts)
- Merge PDF
- Extract one page
- Split PDF by page list/range (for example `1-3,5`)
- Remove selected pages (for example `2,4-6`)
- Rotate all pages by 90 degrees
- Crop all pages using margins in PDF points
- Add text watermark
- Add page numbers
- Optimize/rewrite PDF (rewriting does not guarantee smaller file size)

## Important limitations
This build does not yet include reliable PDF-to-Word, Word-to-PDF, PDF-to-Excel, Excel-to-Word, PowerPoint conversion, OCR, PDF repair, PDF unlock/protection, or cloud backup. These require additional document engines, password handling, or a backend service. They are intentionally not presented as working buttons. Legacy `.xls` is not supported; use `.xlsx`.

## Build
Requires JDK 17, Android SDK platform 35, and Gradle 8.9. Run `gradle assembleDebug` and `gradle bundleRelease`. Release AAB signing must be configured before Play Store upload.
