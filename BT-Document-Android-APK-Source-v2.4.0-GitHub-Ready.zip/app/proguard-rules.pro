# BT Document release build rules
